package com.emailservice.consumer;

import com.emailservice.config.AppConstants;
import com.emailservice.pojo.Email;
import com.emailservice.pojo.UserNotification;
import com.emailservice.service.EmailService;

import lombok.extern.slf4j.Slf4j;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Slf4j
@Service public class KafkaConsumer {

    @Autowired
    private EmailService emailService;

    @KafkaListener(topics = AppConstants.TOPIC_NAME, groupId = AppConstants.GROUP_ID)
    public void consume(String message) {
        try {
            UserNotification userNotification = new ObjectMapper().readValue(message, UserNotification.class);
            if (userNotification.getEvent().equals("signup")) {
                sendSignupEmail(userNotification.getEmail());
            } else if (userNotification.getEvent().equals("password-reset")) {
                sendPasswordResetConfirmationEmail(userNotification.getEmail());
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        log.info(String.format("Message Received  -> %s", message));
    }

    private void sendSignupEmail(String to) {
        sendEmail(to, "New signup", "Congratulation, your account has been set up.");
    }
    private void sendPasswordResetConfirmationEmail(String to) {
        sendEmail(to, "Password reset successful", "Password has been reset successfully.");
    }

    private void sendEmail(String to, String subject, String body){
        emailService.sendEmail(new Email(to, subject, body));
    }
}
