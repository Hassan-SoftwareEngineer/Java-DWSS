package com.emailservice.config;

public class AppConstants {
    public static final String TOPIC_NAME = "user";
    public static final String GROUP_ID = "user_group";
}