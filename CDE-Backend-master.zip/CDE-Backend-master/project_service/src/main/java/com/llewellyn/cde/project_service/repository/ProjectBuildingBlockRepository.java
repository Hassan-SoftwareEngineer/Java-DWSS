package com.llewellyn.cde.project_service.repository;

import java.util.UUID;

import com.llewellyn.cde.project_service.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.project_service.model.ProjectBuildingBlock;

public interface ProjectBuildingBlockRepository extends JpaRepository<ProjectBuildingBlock, UUID> {

    void deleteAllByProject(Project project);

}
