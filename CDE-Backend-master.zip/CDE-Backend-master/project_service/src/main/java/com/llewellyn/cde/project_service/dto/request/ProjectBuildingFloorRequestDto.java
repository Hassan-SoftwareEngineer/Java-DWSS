package com.llewellyn.cde.project_service.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectBuildingFloorRequestDto {

    private String floorCode;
    private String floorName;

}
