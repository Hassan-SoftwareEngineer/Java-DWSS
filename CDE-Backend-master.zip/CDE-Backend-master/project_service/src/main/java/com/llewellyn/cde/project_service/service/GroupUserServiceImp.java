package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.GroupUserDto;
import com.llewellyn.cde.project_service.model.GroupUser;
import com.llewellyn.cde.project_service.model.ProjectGroup;
import com.llewellyn.cde.project_service.repository.GroupUserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class GroupUserServiceImp implements GroupUserService {

    @Autowired
    private GroupUserRepository groupUserRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public GroupUserDto createNewGroupUser(ProjectGroup projectGroup, GroupUserDto groupUserDto) {
        // TODO Auto-generated method stub
        log.info("Create New Group User");

        GroupUser groupUser = dtoToGroupUser(groupUserDto);
        groupUser.setProjectGroup(projectGroup);
        GroupUser newGroupUser = groupUserRepository.save(groupUser);
        return groupUserToDto(newGroupUser);
    }

    @Override
    public List<GroupUserDto> getAllGroupUsetDtoByProjectGroup(ProjectGroup projectGroup) {
        // TODO Auto-generated method stub
        log.info("Get All Group Users DTO");

        List<GroupUser> groupUsers = groupUserRepository.findAllByProjectGroup(projectGroup);
        return groupUsers.stream().map(this::groupUserToDto).collect(Collectors.toList());
    }

    @Override
    public GroupUser getOneGroupUser(UUID group_user_id) {
        // TODO Auto-generated method stub
        log.info("Get One Group User with ID {}", group_user_id);

        Optional<GroupUser> optionalGroupUser = groupUserRepository.findById(group_user_id);
        if (!optionalGroupUser.isPresent()) {

        }
        return optionalGroupUser.get();
    }

    @Override
    public Boolean deleteGroupUserByUserId(UUID user_id) {
        // TODO Auto-generated method stub
        log.info("Delete All Group User with User ID {}", user_id);

        long deleteResult = groupUserRepository.deleteByUserId(user_id);

        return (deleteResult >= 0);
    }

    @Override
    public Boolean deleteGroupUser(UUID group_user_id) {
        // TODO Auto-generated method stub
        log.info("Delete One Group User with ID {}", group_user_id);

        GroupUser groupUser = getOneGroupUser(group_user_id);
        groupUserRepository.delete(groupUser);
        return true;
    }

    public GroupUser dtoToGroupUser(GroupUserDto groupUserDto) {
        GroupUser groupUser = modelMapper.map(groupUserDto, GroupUser.class);
        return groupUser;
    }

    public GroupUserDto groupUserToDto(GroupUser groupUser) {
        GroupUserDto groupUserDto = modelMapper.map(groupUser, GroupUserDto.class);
        return groupUserDto;
    }

}
