package com.llewellyn.cde.project_service.feign;

import com.llewellyn.cde.project_service.feign.pojo.PermissionDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.UUID;

public class AccessFeignClient {
    @FeignClient("access-service")
    public interface AccessClient {
        @GetMapping("/api/v1/access/userprojectrole/permission/user/{userId}/project/{projectId}")
        List<PermissionDto> getProjectPermissions(@PathVariable("userId") UUID userId, @PathVariable("projectId") UUID projectId);
    }

}
