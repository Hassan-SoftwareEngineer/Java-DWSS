package com.llewellyn.cde.project_service.model;


import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "cde_project_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "project")
@EqualsAndHashCode(exclude = "project")
public class ProjectDetails extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    private UUID id;

    private String projectDesc;
    private String buildingLat;
    private String buildingLng;
    @Column(name = "PO")
    private String po;
    @Column(name = "QD")
    private String qd;
    @Column(name = "RD")
    private String rd;
    private String geoAddCode;
    private String remarks;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "project_header_id", referencedColumnName = "id")
    private Project project;
}
