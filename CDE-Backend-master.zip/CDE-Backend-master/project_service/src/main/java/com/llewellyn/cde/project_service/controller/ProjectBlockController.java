package com.llewellyn.cde.project_service.controller;

import java.util.UUID;

import javax.validation.Valid;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.llewellyn.cde.project_service.dto.request.ProjectBuildingBlockRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectBuildingBlockResponseDto;
import com.llewellyn.cde.project_service.service.ProjectBlockServiceImp;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class ProjectBlockController {

    @Autowired
    private ProjectBlockServiceImp projectBlockServiceImp;

    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project/{project_id}/block")
    public ResponseEntity<?> createNewBlock(
            @PathVariable UUID project_id,
            @Valid @RequestBody ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);

        ProjectBuildingBlockResponseDto projectBuildingBlockResponseDto = projectBlockServiceImp
                .createNewBuildingBlockNFloors(project_id, projectBuildingBlockRequestDto);

        return ResponseEntity.ok(projectBuildingBlockResponseDto);
    }

    @PutMapping("/project/{project_id}/block/{block_id}")
    public ResponseEntity<?> updateBlock(
            @PathVariable UUID project_id,
            @PathVariable UUID block_id,
            @Valid @RequestBody ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);

        ProjectBuildingBlockResponseDto projectBuildingBlockResponseDto = projectBlockServiceImp
                .updateBlockInformation(block_id, projectBuildingBlockRequestDto);

        return ResponseEntity.ok(projectBuildingBlockResponseDto);
    }

}
