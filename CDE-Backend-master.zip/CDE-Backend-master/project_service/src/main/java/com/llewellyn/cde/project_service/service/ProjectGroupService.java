package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.ProjectGroupDto;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectGroup;

import java.util.List;
import java.util.UUID;

public interface ProjectGroupService {

    ProjectGroupDto createNewProjectGroup(Project project, ProjectGroupDto projectGroupDto);

    List<ProjectGroupDto> getAllProjectGroupDtoByProject(Project project);

    ProjectGroupDto getProjectGroupDto(UUID project_group_id);

    ProjectGroup getProjectGroup(UUID project_group_id);

    Boolean deleteProjectGroup(UUID project_group_id);

    Boolean isProjectAssignedToGroup(Project project);
}
