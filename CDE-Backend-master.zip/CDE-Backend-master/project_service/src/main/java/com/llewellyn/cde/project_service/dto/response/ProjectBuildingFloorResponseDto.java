package com.llewellyn.cde.project_service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectBuildingFloorResponseDto {

    private String floorCode;
    private String floorName;

}
