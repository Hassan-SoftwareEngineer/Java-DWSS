package com.llewellyn.cde.project_service.auditor;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<String> {
    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @Override
    public Optional<String> getCurrentAuditor() {
        return Optional.of(requestValuesContainer.getRequestValues().get("username"));
    }
}