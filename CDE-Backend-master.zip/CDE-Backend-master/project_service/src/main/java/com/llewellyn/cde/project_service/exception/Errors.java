package com.llewellyn.cde.project_service.exception;

import com.llewellyn.cde.commons.exception.ErrorPrinter;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

public enum Errors implements ErrorPrinter {

    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "000", null, "internal server error {0}"),

    INTERNAL_SERVER_ERROR_WITH_DESC(HttpStatus.INTERNAL_SERVER_ERROR, "000", null, "{0}"),

    INVALID_REQUEST_PARAM(HttpStatus.BAD_REQUEST, "001", "400",
            "invalid/missing mandatory request parameter"),

    INVALID_PROJECT(HttpStatus.BAD_REQUEST, "002", "400",
            "Project ID is not valid. "),
    PROJECT_DETAILS_NOT_FOUND(HttpStatus.NOT_FOUND, "002", "400",
            "Project details not found.. ");

    private HttpStatus httpStatus;
    private String description;
    private String externalErrorCode;
    private String errorCode;

    private Errors(HttpStatus httpStatus, String errorCode, String externalErrorCode,
                   String description) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.externalErrorCode = externalErrorCode;
        this.description = description;
    }

    public static Errors fromString(String text) {
        for (Errors e : Errors.values()) {
            if (StringUtils.isNotBlank(e.getExternalErrorCode())) {
                if (e.externalErrorCode.equalsIgnoreCase(text)) {
                    return e;
                }
            }
        }
        return null;
    }

    @Override
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getExternalErrorCode() {
        return externalErrorCode;
    }
}