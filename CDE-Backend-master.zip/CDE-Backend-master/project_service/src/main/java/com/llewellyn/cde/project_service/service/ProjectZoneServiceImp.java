package com.llewellyn.cde.project_service.service;

import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.project_service.dto.request.ProjectZoneRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectZoneResponseDto;
import com.llewellyn.cde.project_service.exception.Errors;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectZone;
import com.llewellyn.cde.project_service.repository.ProjectRepository;
import com.llewellyn.cde.project_service.repository.ProjectZoneRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ProjectZoneServiceImp implements ProjectZoneService {

    @Autowired
    private ProjectZoneRepository projectZoneRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ProjectZoneResponseDto createNewZone(UUID project_id, ProjectZoneRequestDto projectZoneRequestDto) {
        // TODO Auto-generated method stub
        log.info("Create New Zone with Project ID {}", project_id.toString());

        Optional<Project> optionalProject = projectRepository.findById(project_id);
        if (!optionalProject.isPresent()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }

        ProjectZone newProjectZone = this.dtoToProjectZone(projectZoneRequestDto);
        newProjectZone.setProject(optionalProject.get());

        newProjectZone = projectZoneRepository.save(newProjectZone);

        return this.projectZoneToDto(newProjectZone);
    }

    @Override
    public ProjectZoneResponseDto updateZone(UUID zone_id, ProjectZoneRequestDto projectZoneRequestDto) {
        // TODO Auto-generated method stub
        log.info("Update Zone with Zone ID {}", zone_id.toString());

        Optional<ProjectZone> projectZoneOptional = projectZoneRepository.findById(zone_id);
        ProjectZone projectZone = projectZoneOptional.get();
        projectZone.setZoneCode(projectZoneRequestDto.getZoneCode());
        projectZone.setZoneName(projectZoneRequestDto.getZoneName());

        projectZone = projectZoneRepository.save(projectZone);

        return this.projectZoneToDto(projectZone);
    }

    private ProjectZone dtoToProjectZone(ProjectZoneRequestDto projectZoneRequestDto) {
        ProjectZone projectZone = modelMapper.map(projectZoneRequestDto, ProjectZone.class);
        return projectZone;
    }

    private ProjectZoneResponseDto projectZoneToDto(ProjectZone projectZone) {
        ProjectZoneResponseDto projectZoneResponseDto = modelMapper.map(projectZone,
                ProjectZoneResponseDto.class);
        return projectZoneResponseDto;
    }

}
