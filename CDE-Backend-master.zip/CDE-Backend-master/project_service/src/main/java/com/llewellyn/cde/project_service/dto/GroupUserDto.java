package com.llewellyn.cde.project_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class GroupUserDto {
    private UUID id;
    private UUID userId;
}
