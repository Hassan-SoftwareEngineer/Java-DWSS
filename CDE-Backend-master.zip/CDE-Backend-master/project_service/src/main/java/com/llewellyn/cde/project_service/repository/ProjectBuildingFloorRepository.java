package com.llewellyn.cde.project_service.repository;

import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectBuildingBlock;
import com.llewellyn.cde.project_service.model.ProjectBuildingFloor;
import com.llewellyn.cde.project_service.model.ProjectExtends;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ProjectBuildingFloorRepository extends JpaRepository<ProjectBuildingFloor, UUID> {
    void deleteAllByBlock(ProjectBuildingBlock block);
}
