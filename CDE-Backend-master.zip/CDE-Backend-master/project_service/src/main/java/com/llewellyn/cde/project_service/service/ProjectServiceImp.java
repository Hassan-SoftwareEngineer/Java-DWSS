package com.llewellyn.cde.project_service.service;

import com.google.inject.internal.ErrorsException;
import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.project_service.Util.NullChecker;
import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import com.llewellyn.cde.project_service.dto.*;
import com.llewellyn.cde.project_service.exception.Errors;
import com.llewellyn.cde.project_service.feign.AccessFeignClient.AccessClient;
import com.llewellyn.cde.project_service.feign.pojo.PermissionDto;
import com.llewellyn.cde.project_service.model.*;
import com.llewellyn.cde.project_service.repository.ProjectDetailRepository;
import com.llewellyn.cde.project_service.repository.ProjectExtendsRepository;
import com.llewellyn.cde.project_service.repository.ProjectRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class ProjectServiceImp implements ProjectService {

    @Autowired
    private ProjectRepository projectRepository;


    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AccessClient accessClient;

    @Autowired
    private ProjectDetailRepository projectDetailRepository;

    @Autowired
    private ProjectExtendsRepository projectExtendsRepository;

    @Autowired
    private RequestValuesContainer requestValuesContainer;


    @Override
    public ProjectDto createProject(ProjectDto projectDto) {
        // TODO Auto-generated method stub
        log.info("Create New Project");

        Project project = dtoToProject(projectDto);
        project.setCreatedBy(requestValuesContainer.getRequestValues().get("username"));

        if (Objects.nonNull(projectDto.getProjectDetails()) && !NullChecker.allNull(projectDto.getProjectDetails())) {
            ProjectDetails projectDetails = dtoToProjectDetails(projectDto.getProjectDetails());
            project.setProjectDetails(projectDetails);
        }

        addProjectInfo(projectDto, project);

        Project newProject = projectRepository.save(project);
        ProjectDto newProjectDto = projectToDto(newProject);
        addExtendsFieldsToProjectDto(newProjectDto, newProject.getProjectExtends());
        return newProjectDto;
    }


    private void addProjectInfo(ProjectDto projectDto, Project project) {
        if (!CollectionUtils.isEmpty(projectDto.getProjectExtends())) {
            addExtendsFieldsToProject(project, projectDto.getProjectExtends());
        }

        if (!CollectionUtils.isEmpty(projectDto.getProjectZones())) {
            addZoneInProject(project, projectDto.getProjectZones());
        }

        if (!CollectionUtils.isEmpty(projectDto.getProjectBuildingBlocks())) {
            addBuildingInProject(project, projectDto.getProjectBuildingBlocks());
        }
    }


    private void addExtendsFieldsToProjectDto(ProjectDto projectDto, List<ProjectExtends> lstProjectExtends) {
        if (Objects.nonNull(lstProjectExtends)) {
            projectDto.setProjectExtends(lstProjectExtends.stream().collect(Collectors.toMap(ProjectExtends::getColumn, ProjectExtends::getValue)));
        }
    }

    private void addExtendsFieldsToProject(Project project, Map<String, String> projectExtendsMap) {
        List<ProjectExtends> lstProjectExtends = projectExtendsMap.entrySet().stream().map(pe -> new ProjectExtends(null, pe.getKey(), pe.getValue(), project)).collect(Collectors.toList());
        project.setProjectExtends(lstProjectExtends);
    }

    private void addBuildingInProject(Project project, List<ProjectBuildingBlockDto> lstBuildingBlockDto) {
        List<ProjectBuildingBlock> lstProjectBuildingBlock = lstBuildingBlockDto.stream().map(projectBuildingBlockDto -> new ProjectBuildingBlock(null, projectBuildingBlockDto.getBlockCode(), projectBuildingBlockDto.getBlockName(), project, null)).collect(Collectors.toList());
        project.setProjectBuildingBlocks(lstProjectBuildingBlock);
    }

    private void addZoneInProject(Project project, List<ProjectZonesDto> lstBuildingBlockDto) {
        List<ProjectZone> lstProjectZones = lstBuildingBlockDto.stream().map(projectZonesDto -> new ProjectZone(null, projectZonesDto.getZoneCode(), projectZonesDto.getZoneName(), project)).collect(Collectors.toList());
        project.setProjectZones(lstProjectZones);
    }

    @Override
    public List<ProjectDto> getAllProjectsDto() {
        // TODO Auto-generated method stub
        log.info("Get All Projects DTO");

        List<Project> projects = projectRepository.findAll();

        return projects.stream().map(this::projectToDto).collect(Collectors.toList());
    }

    @Override
    public Map<String, Object> getOneProjectDto(UUID project_id) {

        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        Optional<Project> optionalProject = projectRepository.findById(project_id);
        if (optionalProject.isEmpty()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        List<PermissionDto> permissionDtos = accessClient.getProjectPermissions(userId, project_id);


        Map<String, Object> mapResponse = new HashMap<>();
        ProjectDto projectDto = projectToDto(optionalProject.get());

        Optional<ProjectDetails> optionalProjectDetails = projectDetailRepository.getProjectDetailsByProject(optionalProject.get());
        ProjectDetails projectDetails = null;
        if (optionalProjectDetails.isPresent()) {
            projectDetails = optionalProjectDetails.get();
            projectDto.setProjectDetails(this.modelMapper.map(projectDetails, ProjectDetailsDto.class));
        }
        List<ProjectExtends> lstProjectExtends = projectExtendsRepository.findProjectExtendsByProject(optionalProject.get());
        mapResponse.put("project", projectDto);
        if (lstProjectExtends != null && !lstProjectExtends.isEmpty()) {
            projectDto.setProjectExtends(lstProjectExtends.stream()
                    .collect(Collectors.toMap(ProjectExtends::getColumn, ProjectExtends::getValue)));
        }
        if (permissionDtos != null && !permissionDtos.isEmpty()) {
            mapResponse.put("permissions", permissionDtos);
        }

        return mapResponse;
    }

    @Override
    public Project getOneProject(UUID project_id) {
        log.info("Get One Project with ID {}", project_id);

        Optional<Project> optionalProject = projectRepository.findById(project_id);
        if (!optionalProject.isPresent()) {

        }
        return optionalProject.get();
    }

    @Override
    public ProjectDto updateProject(UUID project_id, ProjectDto projectDto) {
        log.info("Update Project with ID {}", project_id);

        Optional<Project> optionalProject = projectRepository.findById(project_id);
        if (optionalProject.isEmpty()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        Project project = optionalProject.get();
        projectExtendsRepository.deleteAllByProject(project);
        ProjectDetails projectDetails = assignProjectDetailsToProject(project, projectDto);

        project = dtoToProject(projectDto);
        addNewProjectExtendsToProject(projectDto, project);
        project.setId(project_id);

        Project updatedProject = projectRepository.save(project);
        ProjectDetails projectDetails1 = projectDetailRepository.save(projectDetails);
        ProjectDetailsDto dto = projectDetailsToDto(projectDetails1);
        ProjectDto projectDto2 = this.projectToDto(updatedProject);
        projectDto2.setProjectExtends(projectDto.getProjectExtends());
        projectDto2.setProjectDetails(dto);
        return projectDto2;
    }

    private void addNewProjectExtendsToProject(ProjectDto projectDto, Project project) {
        Map<String, String> mapProjectExtends = projectDto.getProjectExtends();
        addExtendsFieldsToProject(project, mapProjectExtends);
    }

    private ProjectDetails assignProjectDetailsToProject(Project project, ProjectDto projectDto) {
        ProjectDetails projectDetails = new ProjectDetails();
        ProjectDetailsDto projectDetailsDto = projectDto.getProjectDetails();

        Optional<ProjectDetails> optionalProjectDetails = projectDetailRepository.getProjectDetailsByProject(project);
        UUID projectDetailsId = null;
        if (optionalProjectDetails.isPresent()) {
            projectDetails = optionalProjectDetails.get();
            projectDetailsId = projectDetails.getId();
        }
        projectDetails = this.modelMapper.map(projectDetailsDto, ProjectDetails.class);
        projectDetails.setProject(project);
        projectDetails.setId(projectDetailsId);
        return projectDetails;
    }

    @Override
    public Boolean deleteProject(UUID project_id) {
        log.info("Delete Project with ID {}", project_id);

        Project project = getOneProject(project_id);

        projectRepository.delete(project);
        return true;
    }

    @Override
    public List<ProjectDto> getProjectsOfUser(String userId) {
        List<String> lstProjectIds = projectRepository.findProjectAssignedToUser(userId);
        List<ProjectDto> lstProjectDto = new ArrayList<>();
        if (!CollectionUtils.isEmpty(lstProjectIds)) {
            lstProjectIds.forEach(projectId -> {
                Optional<Project> optionalProject = projectRepository.findById(UUID.fromString(projectId));
                ProjectDto projectDto = optionalProject.isPresent() ? modelMapper.map(optionalProject.get(), ProjectDto.class) : null;
                lstProjectDto.add(projectDto);
            });
        }
        log.info("lstProjectUser {}", lstProjectDto);
        return lstProjectDto;
    }

    private Project dtoToProject(ProjectDto projectDto) {
        Project project = modelMapper.map(projectDto, Project.class);
        return project;
    }

    private ProjectDetails dtoToProjectDetails(ProjectDetailsDto projectDetailsDto) {
        return modelMapper.map(projectDetailsDto, ProjectDetails.class);
    }

    private ProjectExtends dtoToProjectExtends(ProjectExtendsDto projectExtendsDto) {
        return modelMapper.map(projectExtendsDto, ProjectExtends.class);
    }

    public ProjectDto projectToDto(Project project) {
        ProjectDto projectDto = modelMapper.map(project, ProjectDto.class);
        return projectDto;
    }


    private ProjectDetailsDto projectDetailsToDto(ProjectDetails projectDetails) {
        return modelMapper.map(projectDetails, ProjectDetailsDto.class);
    }

    private ProjectExtendsDto projectExtendsToDto(ProjectExtends projectExtends) {
        return modelMapper.map(projectExtends, ProjectExtendsDto.class);
    }

}
