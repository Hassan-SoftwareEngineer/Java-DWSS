package com.llewellyn.cde.project_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectDetailsDto {

    private UUID id;
    private String projectDesc;
    private String buildingLat;
    private String buildingLng;
    private String po;
    private String qd;
    private String rd;
    private String geoAddCode;
    private String remarks;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private ProjectDto project;
}
