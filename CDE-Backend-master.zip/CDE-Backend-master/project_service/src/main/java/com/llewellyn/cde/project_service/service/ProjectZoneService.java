package com.llewellyn.cde.project_service.service;

import java.util.UUID;

import com.llewellyn.cde.project_service.dto.request.ProjectZoneRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectZoneResponseDto;

public interface ProjectZoneService {

    ProjectZoneResponseDto createNewZone(UUID project_id, ProjectZoneRequestDto projectZoneRequestDto);

    ProjectZoneResponseDto updateZone(UUID zone_id, ProjectZoneRequestDto projectZoneRequestDto);

}
