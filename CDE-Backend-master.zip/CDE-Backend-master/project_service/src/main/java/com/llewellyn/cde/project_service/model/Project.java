package com.llewellyn.cde.project_service.model;

import lombok.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "cde_project_header")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "projectUsers")
@EqualsAndHashCode(exclude = "projectUsers")
public class Project extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    private UUID id;
    private String name;
    private String code;
    private String type;
    private String address;
    private String area;
    private String country;
    private Boolean status;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "project_details_id", referencedColumnName = "id")
    private ProjectDetails projectDetails;

    @OneToMany(mappedBy = "project", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<ProjectExtends> projectExtends;

    @OneToMany(mappedBy = "project", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<ProjectBuildingBlock> projectBuildingBlocks;

    @OneToMany(mappedBy = "project", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<ProjectZone> projectZones;


    public void addBuildingBlock(ProjectBuildingBlock projectBuildingBlock) {
        projectBuildingBlocks.add(projectBuildingBlock);
        projectBuildingBlock.setProject(this);
    }

    public void removeBuildingBlock(ProjectBuildingBlock projectBuildingBlock) {
        projectBuildingBlocks.remove(projectBuildingBlock);
        projectBuildingBlock.setProject(null);
    }
}
