package com.llewellyn.cde.project_service.repository;

import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectDetails;
import com.llewellyn.cde.project_service.model.ProjectGroup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ProjectDetailRepository extends JpaRepository<ProjectDetails, UUID> {
    Optional<ProjectDetails> getProjectDetailsByProject(Project project);
}
