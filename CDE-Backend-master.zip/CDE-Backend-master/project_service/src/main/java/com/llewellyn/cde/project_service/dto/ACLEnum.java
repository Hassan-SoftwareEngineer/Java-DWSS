package com.llewellyn.cde.project_service.dto;

public enum ACLEnum {
    OPEN, PRIVATE, CUSTOM
}
