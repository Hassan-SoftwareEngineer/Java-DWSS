package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.GroupUserDto;
import com.llewellyn.cde.project_service.model.GroupUser;
import com.llewellyn.cde.project_service.model.ProjectGroup;

import java.util.List;
import java.util.UUID;

public interface GroupUserService {

    GroupUserDto createNewGroupUser(ProjectGroup projectGroup, GroupUserDto groupUserDto);

    List<GroupUserDto> getAllGroupUsetDtoByProjectGroup(ProjectGroup projectGroup);

    GroupUser getOneGroupUser(UUID group_user_id);

    Boolean deleteGroupUserByUserId(UUID user_id);

    Boolean deleteGroupUser(UUID group_user_id);

}
