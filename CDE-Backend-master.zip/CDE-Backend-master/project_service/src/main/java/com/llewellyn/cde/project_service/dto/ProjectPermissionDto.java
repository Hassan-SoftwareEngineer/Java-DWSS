package com.llewellyn.cde.project_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.llewellyn.cde.project_service.feign.pojo.PermissionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class ProjectPermissionDto {
    private ProjectDto project;
    private List<PermissionDto> projectPermissions;
}
