package com.llewellyn.cde.project_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.llewellyn.cde.project_service.model.Project;
import lombok.Data;

import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectExtendsDto {
    private UUID id;
    private String column;
    private String value;
    private Project project;
}
