package com.llewellyn.cde.project_service.controller;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import com.llewellyn.cde.project_service.dto.GroupUserDto;
import com.llewellyn.cde.project_service.model.ProjectGroup;
import com.llewellyn.cde.project_service.service.GroupUserServiceImp;
import com.llewellyn.cde.project_service.service.ProjectGroupServiceImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class GroupUserController {

    @Autowired
    private GroupUserServiceImp groupUserServiceImp;

    @Autowired
    private ProjectGroupServiceImp projectGroupServiceImp;
    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project/{project_id}/group/{project_group_id}/groupuser")
    public ResponseEntity<?> createNewGroupUser(@PathVariable UUID project_id,
                                                           @PathVariable UUID project_group_id,
                                                           @RequestBody GroupUserDto groupUserDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);

        ProjectGroup projectGroup = projectGroupServiceImp.getProjectGroup(project_group_id);

        GroupUserDto newGroupUser = groupUserServiceImp.createNewGroupUser(projectGroup, groupUserDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("project/{project_id}/group/{project_group_id}/groupuser/{id}")
                .buildAndExpand(project_id, project_group_id, newGroupUser.getUserId()).toUri();

        return ResponseEntity.created(locationUri).body(newGroupUser);
    }

    @GetMapping("/project/{project_id}/group/{project_group_id}/groupusers")
    public ResponseEntity<List<GroupUserDto>> getProjectGroupByProject(@PathVariable UUID project_id,
                                                                       @PathVariable UUID project_group_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectGroup projectGroup = projectGroupServiceImp.getProjectGroup(project_group_id);

        List<GroupUserDto> groupUsersDto = groupUserServiceImp.getAllGroupUsetDtoByProjectGroup(projectGroup);

        return ResponseEntity.ok(groupUsersDto);
    }

    @DeleteMapping("/project/{project_id}/group/{project_group_id}/groupuser/{group_user_id}")
    public ResponseEntity<?> deleteGroupUser(@PathVariable UUID project_id,
                                                  @PathVariable UUID project_group_id,
                                                  @PathVariable UUID group_user_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = groupUserServiceImp.deleteGroupUser(group_user_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/project/groupuser/user/{user_id}")
    public ResponseEntity<?> deleteGroupUsersByUserId(@PathVariable UUID user_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = groupUserServiceImp.deleteGroupUserByUserId(user_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }
}
