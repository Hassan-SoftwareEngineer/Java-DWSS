package com.llewellyn.cde.project_service.repository;

import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectExtends;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ProjectExtendsRepository extends JpaRepository<ProjectExtends, UUID> {
    void deleteAllByProject(Project project);
    List<ProjectExtends> findProjectExtendsByProject(Project project);
}
