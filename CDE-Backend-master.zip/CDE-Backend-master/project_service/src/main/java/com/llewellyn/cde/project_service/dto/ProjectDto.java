package com.llewellyn.cde.project_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.llewellyn.cde.project_service.feign.pojo.PermissionDto;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectDto {

    private UUID id;
    @NotBlank
    private String name;
    @NotBlank
    private String code;
    @NotBlank
    private String type;
    @NotBlank
    private String address;
    @NotBlank
    private String area;
    @NotBlank
    private String country;
    @NotBlank
    private String city;
    Map<String, String> projectExtends;
    private ProjectDetailsDto projectDetails;
    private List<ProjectBuildingBlockDto> projectBuildingBlocks;
    private List<ProjectZonesDto> projectZones;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private List<PermissionDto> projectPermissions;
}
