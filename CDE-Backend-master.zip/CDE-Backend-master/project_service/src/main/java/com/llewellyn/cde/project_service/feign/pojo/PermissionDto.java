package com.llewellyn.cde.project_service.feign.pojo;

import lombok.Data;

@Data
public class PermissionDto {

    private String functionKey;
    private String permissionType;

}
