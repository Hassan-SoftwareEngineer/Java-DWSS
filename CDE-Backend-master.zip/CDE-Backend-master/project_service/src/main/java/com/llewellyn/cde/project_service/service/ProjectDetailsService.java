package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.ProjectDetailsDto;

import java.util.UUID;

public interface ProjectDetailsService {
    ProjectDetailsDto addProjectDetails(ProjectDetailsDto projectDetailsDto, UUID projectId);
    ProjectDetailsDto updateProjectDetails(ProjectDetailsDto projectDetailsDto);
    void deleteProjectDetails(ProjectDetailsDto projectDetailsDto);
    ProjectDetailsDto getProjectDetails(UUID projectDetailId);
}
