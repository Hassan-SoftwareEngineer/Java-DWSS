package com.llewellyn.cde.project_service.repository;

import com.llewellyn.cde.project_service.model.GroupUser;
import com.llewellyn.cde.project_service.model.ProjectGroup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface GroupUserRepository extends JpaRepository<GroupUser, UUID> {

    List<GroupUser> findAllByProjectGroup(ProjectGroup projectGroup);

    Long deleteByUserId(UUID user_id);
}
