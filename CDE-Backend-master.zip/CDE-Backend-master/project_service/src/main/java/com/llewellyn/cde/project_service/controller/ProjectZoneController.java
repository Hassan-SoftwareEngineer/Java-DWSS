package com.llewellyn.cde.project_service.controller;

import java.util.UUID;

import javax.validation.Valid;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.llewellyn.cde.project_service.dto.request.ProjectZoneRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectZoneResponseDto;
import com.llewellyn.cde.project_service.service.ProjectZoneServiceImp;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class ProjectZoneController {

    @Autowired
    private ProjectZoneServiceImp projectZoneServiceImp;

    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project/{project_id}/zone")
    public ResponseEntity<?> createNewZone(
            @PathVariable UUID project_id,
            @Valid @RequestBody ProjectZoneRequestDto projectZoneRequestDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);
        ProjectZoneResponseDto projectZoneResponseDto = projectZoneServiceImp
                .createNewZone(project_id, projectZoneRequestDto);

        return ResponseEntity.ok(projectZoneResponseDto);
    }

    @PutMapping("/project/{project_id}/zone/{zone_id}")
    public ResponseEntity<?> updateZone(
            @PathVariable UUID project_id,
            @PathVariable UUID zone_id,
            @Valid @RequestBody ProjectZoneRequestDto projectZoneRequestDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);

        ProjectZoneResponseDto projectZoneResponseDto = projectZoneServiceImp
                .updateZone(zone_id, projectZoneRequestDto);

        return ResponseEntity.ok(projectZoneResponseDto);
    }

}
