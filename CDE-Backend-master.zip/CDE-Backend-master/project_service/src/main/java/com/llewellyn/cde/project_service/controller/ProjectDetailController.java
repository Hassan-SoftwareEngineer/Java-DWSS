package com.llewellyn.cde.project_service.controller;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import com.llewellyn.cde.project_service.dto.ProjectDetailsDto;
import com.llewellyn.cde.project_service.dto.request.ProjectZoneRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectZoneResponseDto;
import com.llewellyn.cde.project_service.service.ProjectDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class ProjectDetailController {

    @Autowired
    private ProjectDetailsService projectDetailsService;
    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project/{projectId}/projectdetail")
    public ResponseEntity<?> createNewProjectDetail(
            @PathVariable UUID projectId,
            @Valid @RequestBody ProjectDetailsDto projectDetailsDto, @RequestHeader String username) {
        requestValuesContainer.getRequestValues().put("username", username);
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectDetailsDto projectDetailsDto1 = projectDetailsService
                .addProjectDetails(projectDetailsDto, projectId);

        return ResponseEntity.ok(projectDetailsDto1);
    }

    @PutMapping("/project/{project_id}/projectdetail/{project_detail_id}")
    public ResponseEntity<?> updateProjectDetail(
            @PathVariable UUID project_id,
            @PathVariable UUID project_detail_id,
            @Valid @RequestBody ProjectDetailsDto projectDetailsDto, @RequestHeader String username) {
        requestValuesContainer.getRequestValues().put("username", username);
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        projectDetailsDto.setId(project_detail_id);
        ProjectDetailsDto pddto = projectDetailsService
                .updateProjectDetails(projectDetailsDto);

        return ResponseEntity.ok(pddto);
    }
}
