package com.llewellyn.cde.project_service.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.project_service.dto.request.ProjectBuildingBlockRequestDto;
import com.llewellyn.cde.project_service.dto.request.ProjectBuildingFloorRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectBuildingBlockResponseDto;
import com.llewellyn.cde.project_service.exception.Errors;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectBuildingBlock;
import com.llewellyn.cde.project_service.model.ProjectBuildingFloor;
import com.llewellyn.cde.project_service.repository.ProjectBuildingBlockRepository;
import com.llewellyn.cde.project_service.repository.ProjectRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class ProjectBlockServiceImp implements ProjectBlockService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectBuildingBlockRepository projectBuildingBlockRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ProjectBuildingBlockResponseDto createNewBuildingBlockNFloors(UUID project_id,
            ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto) {
        // TODO Auto-generated method stub
        log.info("Create New Building Block with Project ID {}", project_id.toString());

        Optional<Project> optionalProject = projectRepository.findById(project_id);
        if (!optionalProject.isPresent()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }

        Project project = optionalProject.get();
        ProjectBuildingBlock projectBuildingBlock = dtoToProjectBuildingBlock(projectBuildingBlockRequestDto);

        if (!CollectionUtils.isEmpty(projectBuildingBlockRequestDto.getFloors())) {
            addFloorInBlock(projectBuildingBlock, projectBuildingBlockRequestDto.getFloors());
        }

        project.addBuildingBlock(projectBuildingBlock);

        return this.buildingBlockToDto(projectBuildingBlock);
    }

    @Override
    public ProjectBuildingBlockResponseDto updateBlockInformation(UUID block_id,
            ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto) {
        // TODO Auto-generated method stub
        log.info("Update Building Block with Block ID {}", block_id.toString());

        Optional<ProjectBuildingBlock> projectBuildingBlockOptional = projectBuildingBlockRepository.findById(block_id);
        if (!projectBuildingBlockOptional.isPresent()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }

        ProjectBuildingBlock projectBuildingBlock = projectBuildingBlockOptional.get();
        List<ProjectBuildingFloor> lsProjectBuildingFloors = projectBuildingBlock.getProjectBuildingFloors();
        int lstfloorSize = lsProjectBuildingFloors.size();

        for (int x = 0; x < lstfloorSize; x++) {
            log.info("Delete Floor with ID " + lsProjectBuildingFloors.get(0).getId());
            projectBuildingBlock.removeBuildingFloor(lsProjectBuildingFloors.get(0));
        }

        log.info("projectBuildingBlock {}", projectBuildingBlock.toString());
        projectBuildingBlock.setBlockCode(projectBuildingBlockRequestDto.getBlockCode());
        projectBuildingBlock.setBlockName(projectBuildingBlockRequestDto.getBlockName());

        if (!CollectionUtils.isEmpty(projectBuildingBlockRequestDto.getFloors())) {
            for (int i = 0; i < projectBuildingBlockRequestDto.getFloors().size(); i++) {
                log.info("Add {}", i);
                ProjectBuildingFloorRequestDto projectBuildingFloorRequestDto = projectBuildingBlockRequestDto
                        .getFloors().get(i);
                ProjectBuildingFloor projectBuildingFloor = new ProjectBuildingFloor(null,
                        projectBuildingFloorRequestDto.getFloorCode(), projectBuildingFloorRequestDto.getFloorName(),
                        null);
                projectBuildingBlock.addBuildingFloor(projectBuildingFloor);
            }
        }
        log.info("projectBuildingBlock {}", projectBuildingBlock.toString());

        projectBuildingBlockRepository.save(projectBuildingBlock);

        return this.buildingBlockToDto(projectBuildingBlock);
    }

    private ProjectBuildingBlock dtoToProjectBuildingBlock(ProjectBuildingBlockRequestDto buildingBlockDto) {
        ProjectBuildingBlock buildingBlock = modelMapper.map(buildingBlockDto, ProjectBuildingBlock.class);
        return buildingBlock;
    }

    private ProjectBuildingBlockResponseDto buildingBlockToDto(ProjectBuildingBlock projectBuildingBlock) {
        ProjectBuildingBlockResponseDto buildingBlockDto = modelMapper.map(projectBuildingBlock,
                ProjectBuildingBlockResponseDto.class);
        return buildingBlockDto;
    }

    private void addFloorInBlock(ProjectBuildingBlock block, List<ProjectBuildingFloorRequestDto> blockFloorDto) {
        List<ProjectBuildingFloor> buildingFloor = blockFloorDto
                .stream().map(projectBuildingFloorDto -> new ProjectBuildingFloor(null,
                        projectBuildingFloorDto.getFloorCode(), projectBuildingFloorDto.getFloorName(), block))
                .collect(Collectors.toList());
        block.setProjectBuildingFloors(buildingFloor);
    }

}
