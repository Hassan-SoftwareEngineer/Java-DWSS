package com.llewellyn.cde.project_service.controller;

import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import com.llewellyn.cde.project_service.dto.ProjectDto;
import com.llewellyn.cde.project_service.service.ProjectService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class ProjectController {

    @Autowired
    private ProjectService projectServiceImp;
    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project")
    public ResponseEntity<?> createNewProject(@Valid @RequestBody ProjectDto projectDto, @RequestHeader String username, @RequestHeader String userId) {
        requestValuesContainer.getRequestValues().put("username", username);
        requestValuesContainer.getRequestValues().put("userId", userId);
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectDto newProject = projectServiceImp.createProject(projectDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest().path("project/{id}")
                .buildAndExpand(newProject.getId()).toUri();

        return ResponseEntity.created(locationUri).body(newProject);
    }

    @GetMapping("/project")
    public ResponseEntity<List<ProjectDto>> getAllProjects() {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        List<ProjectDto> projects = projectServiceImp.getAllProjectsDto();

        return ResponseEntity.ok(projects);
    }

    @GetMapping("/project/{project_id}")
    public ResponseEntity<?> getOneUser(@PathVariable UUID project_id, @RequestHeader String userId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("userId", userId);

        Map<String, Object> projectDto = projectServiceImp.getOneProjectDto(project_id);

        return ResponseEntity.ok(projectDto);
    }

    @PutMapping("/project/{project_id}")
    public ResponseEntity<ProjectDto> updateProject(@PathVariable UUID project_id, @RequestBody ProjectDto projectDto, @RequestHeader String username) {
        requestValuesContainer.getRequestValues().put("username", username);
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectDto updatedProject = projectServiceImp.updateProject(project_id, projectDto);

        return ResponseEntity.ok(updatedProject);
    }

    @DeleteMapping("/project/{project_id}")
    public ResponseEntity<?> deleteProject(@PathVariable UUID project_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = projectServiceImp.deleteProject(project_id);

        Map<String, Object> response = new HashMap<>();
//        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/project/user/{userId}")
    public ResponseEntity<?> getProjectsForUser(@PathVariable String userId) {
        List<ProjectDto> lstProjectUserDto = projectServiceImp.getProjectsOfUser(userId);

        return ResponseEntity.ok(new UserProjectsResponse(lstProjectUserDto));
    }

    @Data
    @AllArgsConstructor
    class UserProjectsResponse {
        private List<ProjectDto> projects;
    }

}
