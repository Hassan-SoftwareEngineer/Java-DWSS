package com.llewellyn.cde.project_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.llewellyn.cde.project_service.model.Project;
import lombok.Data;

import java.util.UUID;

@Data
public class ProjectZonesDto {
    private UUID id;

    private String zoneCode;
    private String zoneName;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Project project;
}
