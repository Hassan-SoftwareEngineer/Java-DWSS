package com.llewellyn.cde.project_service.service;

import java.util.UUID;

import com.llewellyn.cde.project_service.dto.request.ProjectBuildingBlockRequestDto;
import com.llewellyn.cde.project_service.dto.response.ProjectBuildingBlockResponseDto;

public interface ProjectBlockService {

    ProjectBuildingBlockResponseDto createNewBuildingBlockNFloors(UUID project_id,
            ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto);

    ProjectBuildingBlockResponseDto updateBlockInformation(UUID block_id,
            ProjectBuildingBlockRequestDto projectBuildingBlockRequestDto);

}
