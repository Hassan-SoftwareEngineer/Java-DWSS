package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.ProjectDto;
import com.llewellyn.cde.project_service.dto.ProjectPermissionDto;
import com.llewellyn.cde.project_service.model.Project;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface ProjectService {

    ProjectDto createProject(ProjectDto projectDto);

    List<ProjectDto> getAllProjectsDto();

    Map<String, Object> getOneProjectDto(UUID project_id);

    Project getOneProject(UUID project_id);

    ProjectDto updateProject(UUID project_id, ProjectDto projectDto);

    Boolean deleteProject(UUID project_id);

    List<ProjectDto> getProjectsOfUser(String userId);
}
