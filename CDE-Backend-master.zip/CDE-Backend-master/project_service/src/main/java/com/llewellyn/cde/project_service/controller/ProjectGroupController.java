package com.llewellyn.cde.project_service.controller;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.project_service.config.RequestValuesContainer;
import com.llewellyn.cde.project_service.dto.ProjectGroupDto;
import com.llewellyn.cde.project_service.exception.Errors;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.service.ProjectGroupService;
import com.llewellyn.cde.project_service.service.ProjectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.*;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class ProjectGroupController {

    @Autowired
    private ProjectGroupService projectGroupServiceImp;

    @Autowired
    private ProjectService projectServiceImp;

    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @PostMapping("/project/{projectId}/group")
    public ResponseEntity<?> createNewProjectGroup(@PathVariable UUID projectId,
                                                                 @RequestBody ProjectGroupDto projectGroupDto, @RequestHeader String username) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("username", username);

        Project project = projectServiceImp.getOneProject(projectId);

        if (Objects.isNull(project)) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }

        ProjectGroupDto newProjectGroup = projectGroupServiceImp.createNewProjectGroup(project, projectGroupDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest().path("project/{project_id}/group/{id}")
                .buildAndExpand(projectId, newProjectGroup.getProjectGroupId()).toUri();

        return ResponseEntity.created(locationUri).body(newProjectGroup);
    }

    @GetMapping("/project/{project_id}/groups")
    public ResponseEntity<List<ProjectGroupDto>> getProjectGroupsByProject(@PathVariable UUID project_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        Project project = projectServiceImp.getOneProject(project_id);

        List<ProjectGroupDto> projectGroupsDto = projectGroupServiceImp.getAllProjectGroupDtoByProject(project);

        return ResponseEntity.ok(projectGroupsDto);
    }

    @GetMapping("/project/{project_id}/group/{project_group_id}")
    public ResponseEntity<?> getProjectGroupsByProjectGroupID(@PathVariable UUID project_id,
                                                                            @PathVariable UUID project_group_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectGroupDto projectGroupDto = projectGroupServiceImp.getProjectGroupDto(project_group_id);

        return ResponseEntity.ok(projectGroupDto);
    }

    @DeleteMapping("/project/{project_id}/group/{project_group_id}")
    public ResponseEntity<?> deleteProjectGroup(@PathVariable UUID project_id,
                                                     @PathVariable UUID project_group_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = projectGroupServiceImp.deleteProjectGroup(project_group_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }
}
