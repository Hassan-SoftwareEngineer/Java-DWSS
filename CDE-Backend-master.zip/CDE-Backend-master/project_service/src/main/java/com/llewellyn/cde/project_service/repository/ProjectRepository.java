package com.llewellyn.cde.project_service.repository;

import com.llewellyn.cde.project_service.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface ProjectRepository extends JpaRepository<Project, UUID> {

    @Query(value = "select distinct(zp.id) from cde_project_header zp\n" +
            "left join cde_project_group cpg on zp.id = cpg.project_id\n" +
            "left join cde_group_user cgu on cpg.id = cgu.project_group_id\n" +
            "where cgu.user_id=:user_id", nativeQuery = true)
    List<String> findProjectAssignedToUser(@Param("user_id") String userId);

}
