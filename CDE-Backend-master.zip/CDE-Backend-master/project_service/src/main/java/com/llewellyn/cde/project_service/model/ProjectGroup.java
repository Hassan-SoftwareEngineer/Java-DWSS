package com.llewellyn.cde.project_service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "cde_project_group")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectGroup extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "id")
    private UUID projectGroupId;
    private String projectGroupName;
    private String projectGroupDescription;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Project project;


    @OneToMany(mappedBy = "projectGroup", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<GroupUser> groupUsers = new ArrayList<>();

    public void addGroupUser(GroupUser groupUser) {
        groupUsers.add(groupUser);
        groupUser.setProjectGroup(this);
    }

    public void removeGroupUser(GroupUser groupUser) {
        groupUsers.remove(groupUser);
        groupUser.setProjectGroup(null);
    }
}
