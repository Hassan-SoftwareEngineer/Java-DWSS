package com.llewellyn.cde.project_service.dto;

import com.llewellyn.cde.project_service.model.Project;
import lombok.Data;

import java.util.UUID;


@Data
public class ProjectUserDto {
    private UUID id;
    private String userId;
    private Project project;

}
