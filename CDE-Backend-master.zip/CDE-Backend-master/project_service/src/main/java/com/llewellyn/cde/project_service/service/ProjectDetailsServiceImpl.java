package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.project_service.dto.ProjectDetailsDto;
import com.llewellyn.cde.project_service.exception.Errors;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectDetails;
import com.llewellyn.cde.project_service.repository.ProjectDetailRepository;
import com.llewellyn.cde.project_service.repository.ProjectRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class ProjectDetailsServiceImpl implements ProjectDetailsService {
    @Autowired
    private ProjectDetailRepository projectDetailsRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public ProjectDetailsDto addProjectDetails(ProjectDetailsDto projectDetailsDto, UUID projectId) {
        Optional<Project> optionalProject = projectRepository.findById(projectId);
        if (optionalProject.isEmpty()) {
            throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        Optional<ProjectDetails> optionalProjectDetails = projectDetailsRepository.getProjectDetailsByProject(optionalProject.get());
        if (optionalProjectDetails.isPresent()) {
            throw new CommonErrorException("Project details already exists for this project, there can be only 1 project detail for every project");
        }
        Project project = optionalProject.get();
        ProjectDetails projectDetails = this.modelMapper.map(projectDetailsDto, ProjectDetails.class);
        projectDetails.setProject(project);
        return modelMapper.map(projectDetailsRepository.save(projectDetails), ProjectDetailsDto.class);
    }

    @Override
    public ProjectDetailsDto updateProjectDetails(ProjectDetailsDto projectDetailsDto) {
        Optional<ProjectDetails> optionalProjectDetails = projectDetailsRepository.findById(projectDetailsDto.getId());
        if (optionalProjectDetails.isEmpty()) {
            throw new CommonErrorException(Errors.PROJECT_DETAILS_NOT_FOUND);
        }
        ProjectDetails projectDetails = this.modelMapper.map(projectDetailsDto, ProjectDetails.class);
        projectDetails.setId(projectDetails.getId());
        return this.modelMapper.map(projectDetailsRepository.save(projectDetails), ProjectDetailsDto.class);
    }

    @Override
    public void deleteProjectDetails(ProjectDetailsDto projectDetailsDto) {
        projectDetailsRepository.deleteById(projectDetailsDto.getId());
    }

    @Override
    public ProjectDetailsDto getProjectDetails(UUID projectDetailId) {
        Optional<ProjectDetails> optionalProjectDetails = projectDetailsRepository.findById(projectDetailId);
        if (optionalProjectDetails.isEmpty()) {
            throw new CommonErrorException(Errors.PROJECT_DETAILS_NOT_FOUND);
        }
        return this.modelMapper.map(optionalProjectDetails.get(), ProjectDetailsDto.class);
    }
}
