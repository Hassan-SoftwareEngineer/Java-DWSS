package com.llewellyn.cde.project_service.service;

import com.llewellyn.cde.project_service.dto.ProjectGroupDto;
import com.llewellyn.cde.project_service.model.GroupUser;
import com.llewellyn.cde.project_service.model.Project;
import com.llewellyn.cde.project_service.model.ProjectGroup;
import com.llewellyn.cde.project_service.repository.ProjectGroupRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class ProjectGroupServiceImp implements ProjectGroupService {

    @Autowired
    private ProjectGroupRepository projectGroupRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ProjectGroupDto createNewProjectGroup(Project project, ProjectGroupDto projectGroupDto) {
        // TODO Auto-generated method stub
        log.info("Create New Project Group");

        ProjectGroup projectGroup = dtoToProjectGroup(projectGroupDto);
        projectGroup.setProject(project);
        ProjectGroup newProjectGroup = projectGroupRepository.save(projectGroup);
        return projectGroupToDto(newProjectGroup);
    }

    @Override
    public List<ProjectGroupDto> getAllProjectGroupDtoByProject(Project project) {
        // TODO Auto-generated method stub
        log.info("Get All Project Groups DTO");

        List<ProjectGroup> projectGroups = projectGroupRepository.findAllByProject(project);

        return projectGroups.stream().map(this::projectGroupToDto).collect(Collectors.toList());
    }

    @Override
    public ProjectGroupDto getProjectGroupDto(UUID project_group_id) {
        // TODO Auto-generated method stub
        log.info("Get One Project Group DTO with ID {}", project_group_id);

        Optional<ProjectGroup> optionalProjectGroup = projectGroupRepository.findById(project_group_id);
        if (!optionalProjectGroup.isPresent()) {

        }
        ProjectGroupDto projectGroupDto = projectGroupToDto(optionalProjectGroup.get());
        return projectGroupDto;
    }

    @Override
    public ProjectGroup getProjectGroup(UUID project_group_id) {
        // TODO Auto-generated method stub
        log.info("Get One Project Group with ID {}", project_group_id);

        Optional<ProjectGroup> optionalProjectGroup = projectGroupRepository.findById(project_group_id);
        if (!optionalProjectGroup.isPresent()) {

        }
        return optionalProjectGroup.get();
    }

    @Override
    public Boolean deleteProjectGroup(UUID project_group_id) {
        // TODO Auto-generated method stub
        log.info("Delete One Project Group with ID {}", project_group_id);

        ProjectGroup projectGroup = getProjectGroup(project_group_id);

        for (int i = projectGroup.getGroupUsers().size() - 1; i >= 0; i--) {
            log.info("Remove Group User with ID {}", projectGroup.getGroupUsers().get(i).getUserId());
            GroupUser groupUser = projectGroup.getGroupUsers().get(i);
            projectGroup.removeGroupUser(groupUser);
        }

        projectGroupRepository.delete(projectGroup);
        return true;
    }

    @Override
    public Boolean isProjectAssignedToGroup(Project project) {

        return projectGroupRepository.findProjectGroupByProject(project).isPresent();

    }

    public ProjectGroup dtoToProjectGroup(ProjectGroupDto projectGroupDto) {
        ProjectGroup projectGroup = modelMapper.map(projectGroupDto, ProjectGroup.class);
        return projectGroup;
    }

    public ProjectGroupDto projectGroupToDto(ProjectGroup projectGroup) {
        ProjectGroupDto projectGroupDto = modelMapper.map(projectGroup, ProjectGroupDto.class);
        return projectGroupDto;
    }

}
