package com.llewellyn.cde.project_service.repository;

import java.util.UUID;

import com.llewellyn.cde.project_service.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.project_service.model.ProjectZone;

public interface ProjectZoneRepository extends JpaRepository<ProjectZone, UUID> {
    void deleteAllByProject(Project project);
}
