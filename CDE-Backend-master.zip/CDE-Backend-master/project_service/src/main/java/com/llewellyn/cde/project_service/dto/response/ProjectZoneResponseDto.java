package com.llewellyn.cde.project_service.dto.response;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectZoneResponseDto {

    private UUID id;
    private String zoneCode;
    private String zoneName;

}
