package com.llewellyn.cde.project_service.dto;

public enum DeletedEnum {
    ZERO(0), ONE(1);
    private final int value;

    DeletedEnum(final int newValue) {
        value = newValue;
    }

    public int getValue() {
        return value;
    }
}
