package com.llewellyn.cde.project_service.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "cde_building_block")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "project")
@EqualsAndHashCode(exclude = "project")
public class ProjectBuildingBlock extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    private UUID id;

    private String blockCode;
    private String blockName;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "project_id", nullable = false)
    private Project project;

    @OneToMany(mappedBy = "block", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProjectBuildingFloor> projectBuildingFloors;

    public void addBuildingFloor(ProjectBuildingFloor projectBuildingFloor) {
        projectBuildingFloors.add(projectBuildingFloor);
        projectBuildingFloor.setBlock(this);
    }

    public void removeBuildingFloor(ProjectBuildingFloor projectBuildingFloor) {
        projectBuildingFloors.remove(projectBuildingFloor);
        projectBuildingFloor.setBlock(null);
    }

}
