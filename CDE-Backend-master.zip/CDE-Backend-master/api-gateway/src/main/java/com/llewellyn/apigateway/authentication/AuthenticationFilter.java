package com.llewellyn.apigateway.authentication;

import com.auth0.jwt.interfaces.Claim;
import com.llewellyn.apigateway.exception.Errors;
import com.llewellyn.apigateway.model.User;
import com.llewellyn.apigateway.repository.UserRepository;
import com.llewellyn.cde.commons.exception.CommonErrorException;
import io.jsonwebtoken.Claims;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Optional;
import java.util.UUID;

@RefreshScope
@Component
public class AuthenticationFilter implements GatewayFilter {

    @Autowired
    private RouterValidator routerValidator;
    @Autowired
    private NewJwtUtil jwtUtil;
    @Autowired
    private JWTUtil jwtUtil2;
    @Autowired
    private UserRepository userRepository;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();

        if (routerValidator.isSecured.test(request)) {
            if (this.isAuthMissing(request))
                return this.onError(exchange, "Authorization header is missing in request", HttpStatus.UNAUTHORIZED);

            final String token = this.getAuthHeader(request);
            Claim claim = null;
            try {
                claim = jwtUtil2.validateTokenAndRetrieveSubject(token.split("Bearer")[1].trim());
            } catch (Exception ex) {
                throw new CommonErrorException(Errors.INVALID_TOKEN);
            }


            if (claim.isNull()) {
                return this.onError(exchange, "Authorization header is invalid", HttpStatus.UNAUTHORIZED);
            }

            this.populateRequestWithHeaders(exchange, claim);
        }
        return chain.filter(exchange);
    }

    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        throw new CommonErrorException(Errors.INVALID_TOKEN);
    }

    private String getAuthHeader(ServerHttpRequest request) {
        return request.getHeaders().getOrEmpty("Authorization").get(0);
    }

    private boolean isAuthMissing(ServerHttpRequest request) {
        return !request.getHeaders().containsKey("Authorization");
    }

    private void populateRequestWithHeaders(ServerWebExchange exchange, Claim claim) {
        Optional<User> optionalUser = userRepository.findUserByUsername(String.valueOf(claim.asString()));
        UUID userId = null;
        if (optionalUser.isPresent()) {
            userId = optionalUser.get().getId();
        }
        exchange.getRequest().mutate()
                .header("username", String.valueOf(claim.asString()))
                .header("userId", userId.toString())
                .build();
    }
}
