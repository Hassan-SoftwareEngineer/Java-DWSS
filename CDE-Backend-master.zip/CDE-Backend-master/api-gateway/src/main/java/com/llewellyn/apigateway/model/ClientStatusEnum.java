package com.llewellyn.apigateway.model;

public enum ClientStatusEnum {
    ONLINE, AWAY, BUSY, OFFLINE
}
