package com.llewellyn.apigateway.model;

public enum GenderEnum {
    m, f
}
