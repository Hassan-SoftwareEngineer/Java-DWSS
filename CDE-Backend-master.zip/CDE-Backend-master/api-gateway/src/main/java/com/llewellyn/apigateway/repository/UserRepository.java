package com.llewellyn.apigateway.repository;

import com.llewellyn.apigateway.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID>{

    Optional<User> findUserByEmailAndPassword(String email, String password);
    Optional<User> findUserByUsername(String username);
    
}
