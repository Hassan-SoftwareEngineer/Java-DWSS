package com.llewellyn.apigateway.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "user_header")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "id")
    private UUID id;

    @Email
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    private String username;
    private String firstname;
    private String lastname;
    private String password;
    private Date dob;
    @Enumerated(EnumType.STRING)
    private GenderEnum gender;
    private Boolean isActive;
    private Integer fails;
    private Instant locked;
    private boolean isPasswordChanged;
    private String mobile;
    private String directReport;
}
