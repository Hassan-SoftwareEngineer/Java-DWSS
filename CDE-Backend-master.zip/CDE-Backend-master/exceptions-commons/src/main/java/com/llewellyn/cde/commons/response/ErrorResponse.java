
package com.llewellyn.cde.commons.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *MAIN ERROR BODY OF THE SERVICE
 *
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "error_code", "description", "correlation_id", "external_error_code",
        "additional_properties" })
public class ErrorResponse {

    public ErrorResponse(String errorCode, String description, String correlationId,
            String externalErrorCode) {
        super();
        this.errorCode = errorCode;
        this.description = description;
        this.correlationId = correlationId;
        this.externalErrorCode = externalErrorCode;
    }

    public ErrorResponse(String errorCode, String description, String correlationId,
            String externalErrorCode, Map<String, Object> additionalProperties) {
        this(errorCode, description, correlationId, externalErrorCode);
        this.additionalProperties = additionalProperties;
    }

    @JsonProperty("error_code")
    private String errorCode;
    @JsonProperty("description")
    private String description;
    @JsonProperty("correlation_id")
    private String correlationId;
    @JsonProperty("external_error_code")
    private String externalErrorCode;
    @JsonProperty("additional_properties")
    private Map<String, Object> additionalProperties;

    public ErrorResponse() {
    }

    /**
     * 
     * @return The errorCode
     */
    @JsonProperty("error_code")
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * 
     * @param errorCode
     *            The error_code
     */
    @JsonProperty("error_code")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * 
     * @return The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *            The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * 
     * @return The correlationId
     */
    @JsonProperty("correlation_id")
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * 
     * @param correlationId
     *            The correlation_id
     */
    @JsonProperty("correlation_id")
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    /**
     * 
     * @return The externalErrorCode
     */
    @JsonProperty("external_error_code")
    public String getExternalErrorCode() {
        return externalErrorCode;
    }

    /**
     * 
     * @param externalErrorCode
     *            The external_error_code
     */
    @JsonProperty("external_error_code")
    public void setExternalErrorCode(String externalErrorCode) {
        this.externalErrorCode = externalErrorCode;
    }

    @JsonProperty("additional_properties")
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public static class ErrorResponseBuilder {
        private String errorCode;
        private String description;
        private String correlationId;
        private String externalErrorCode;
        private Map<String, Object> additionalProperties;

        public ErrorResponseBuilder(String spanId) {
            this.correlationId = spanId;
        }

        public ErrorResponseBuilder errorCode(String errorCode) {
            this.errorCode = errorCode;
            return this;
        }

        public ErrorResponseBuilder description(String description) {
            this.description = description;
            return this;
        }

        public ErrorResponseBuilder correlationId(String correlationId) {
            this.correlationId = correlationId;
            return this;
        }

        public ErrorResponseBuilder externalErrorCode(String externalErrorCode) {
            this.externalErrorCode = externalErrorCode;
            return this;
        }

        public ErrorResponseBuilder additionalProperties(Map<String, Object> additionalProperties) {
            this.additionalProperties = additionalProperties;
            return this;
        }

        public ErrorResponse build() {
            return new ErrorResponse(errorCode, description, correlationId, externalErrorCode,
                    additionalProperties);
        }

    }

    @Override
    public String toString() {
        return "ErrorResponse [errorCode=" + errorCode + ", description=" + description
                + ", correlationId=" + correlationId + ", externalErrorCode=" + externalErrorCode
                + ", additionalProperties=" + additionalProperties + "]";
    }

}
