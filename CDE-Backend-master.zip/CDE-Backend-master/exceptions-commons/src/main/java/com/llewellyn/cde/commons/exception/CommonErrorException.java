package com.llewellyn.cde.commons.exception;

import java.text.MessageFormat;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

/**
 * 
 *         encapsulates error enum to handle exceptions and recognized errors
 *         according to the expected json response return by the service
 */
public class CommonErrorException extends RuntimeException {

    private static final long serialVersionUID = 212203429789803673L;

    private ErrorPrinter errorEnum;

    private HttpStatus httpStatus;
    private String description;
    private String externalErrorCode;
    private String errorCode;
    private Map<String, Object> additionalProperties;

    public CommonErrorException() {
    }

    public CommonErrorException(ErrorPrinter errorEnum) {

        super(errorEnum.getDescription());

        setErrorEnum(errorEnum);
    }

    public CommonErrorException(ErrorPrinter errorEnum, HttpStatus httpStatus, String errorCode,
                                String externalErrorCode, String description) {

        this(errorEnum, httpStatus, errorCode, externalErrorCode, description, null);
    }

    public CommonErrorException(ErrorPrinter errorEnum, HttpStatus httpStatus, String errorCode,
                                String externalErrorCode, String description, Throwable cause) {

        super(description, cause);

        setErrorEnum(errorEnum);
        setHttpStatus(httpStatus);
        setErrorCode(errorCode);
        setExternalErrorCode(externalErrorCode);
        setDescription(description);
    }

    public CommonErrorException(String message) {
        super(message);
        setDescription(message);
    }

    public CommonErrorException(Throwable cause) {
        super(cause);
        setHttpStatusCode(cause);
    }

    public CommonErrorException(String message, Throwable cause) {
        super(message, cause);
        setHttpStatusCode(cause);
        setDescription(message);
    }

    public CommonErrorException(String message, Throwable cause, boolean enableSuppression,
                                boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        setHttpStatusCode(cause);
        setDescription(message);
    }

    public CommonErrorException(String message, Throwable cause, ErrorPrinter errorEnum) {
        super(message, cause);
        setHttpStatusCode(cause);
        setErrorEnum(errorEnum);
        setDescription(message);
    }

    public ErrorPrinter getErrorEnum() {
        return errorEnum;
    }

    public void setErrorEnum(ErrorPrinter errorEnum) {
        this.errorEnum = errorEnum;

        if (errorEnum != null) {
            setHttpStatus(errorEnum.getHttpStatus());
            setErrorCode(errorEnum.getErrorCode());
            setExternalErrorCode(errorEnum.getExternalErrorCode());
            setDescription(errorEnum.getDescription());
        }
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExternalErrorCode() {
        return externalErrorCode;
    }

    public void setExternalErrorCode(String externalErrorCode) {
        this.externalErrorCode = externalErrorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }

    public CommonErrorException(final ErrorPrinter type, Object... values) {

        this(type, type.getHttpStatus(), type.getErrorCode(),
                type.getExternalErrorCode() != null
                        ? MessageFormat.format(type.getExternalErrorCode(), values)
                        : null,
                type.getDescription() != null ? MessageFormat.format(type.getDescription(), values)
                        : null,
                values != null && values.length > 0
                        && values[values.length - 1] instanceof Throwable
                                ? (Throwable) values[values.length - 1]
                                : null);

    }

    private void setHttpStatusCode(Throwable cause) {
        if (cause instanceof HttpStatusCodeException) {
            HttpStatusCodeException restE = (HttpStatusCodeException) cause;
            setHttpStatus(restE.getStatusCode());
        }
    }
}
