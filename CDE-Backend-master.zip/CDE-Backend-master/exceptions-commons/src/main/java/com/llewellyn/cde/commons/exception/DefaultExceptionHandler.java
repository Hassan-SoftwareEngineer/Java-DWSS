package com.llewellyn.cde.commons.exception;

import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.sleuth.SpanAccessor;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.llewellyn.cde.commons.response.ErrorResponse;

/**
 *
 *
 *         Any exception will be handled here to return the default error
 *         response of the service {@link ErrorResponse}
 */
@RestControllerAdvice
@ComponentScan(basePackages = "com.llewellyn")
@RequestMapping(produces = "application/json")
public class DefaultExceptionHandler {

    private static final String INVALID_MISSING_REQUIRED_ATTRIBUTES = "invalid/missing required attributes: ";
    private static final String SERVICE_RETURNED_ERROR = "service returned error: {}";
    private static final int ERROR_CODE_LENGTH = 3;
    private static final String ERROR_FIELD_SEPERATOR = ", ";

    @Value("${service.identifier:90}")
    private String serviceIdentifier;

    private String INTERNAL_SERVER_ERROR;
    private String REQUEST_VALIDATION_ERROR;
    private static final Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

//    @Autowired
//    private SpanAccessor spanAccessor;

    @PostConstruct
    public void init() {
        INTERNAL_SERVER_ERROR = serviceIdentifier + "000";
        REQUEST_VALIDATION_ERROR = serviceIdentifier + "001";
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorResponse validationExceptions(MethodArgumentNotValidException ex) {
        List<FieldError> constraintViolations = ex.getBindingResult().getFieldErrors();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(INVALID_MISSING_REQUIRED_ATTRIBUTES);
        for (FieldError constraintViolation : constraintViolations) {
            stringBuilder.append(constraintViolation.getField()).append(ERROR_FIELD_SEPERATOR);
        }
        stringBuilder.delete(stringBuilder.lastIndexOf(ERROR_FIELD_SEPERATOR),
                stringBuilder.length());
        ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                .description(stringBuilder.toString())
                .errorCode(REQUEST_VALIDATION_ERROR)
                .build();
        traceError(SERVICE_RETURNED_ERROR, errorResponse, ex);
        return errorResponse;
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorResponse validationConstraintViolationException(ConstraintViolationException ex) {
        Set<ConstraintViolation<?>> constraintViolations = ex.getConstraintViolations();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(INVALID_MISSING_REQUIRED_ATTRIBUTES);
        for (ConstraintViolation<?> constraintViolation : constraintViolations) {
            stringBuilder.append(getFieldName(constraintViolation)).append(ERROR_FIELD_SEPERATOR);
        }
        stringBuilder.delete(stringBuilder.lastIndexOf(ERROR_FIELD_SEPERATOR),
                stringBuilder.length());
        ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                .description(stringBuilder.toString())
                .errorCode(REQUEST_VALIDATION_ERROR)
                .build();
        traceError(SERVICE_RETURNED_ERROR, errorResponse, ex);
        return errorResponse;
    }

    @ExceptionHandler({ ServletRequestBindingException.class,
            HttpMessageNotReadableException.class })
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ErrorResponse controllerExceptions(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                .description(ex.getMessage())
                .errorCode(REQUEST_VALIDATION_ERROR)
                .build();
        traceError(SERVICE_RETURNED_ERROR, errorResponse, ex);
        return errorResponse;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse unhandledErrors(Exception ex) {

        ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                .description(ex.getMessage())
                .errorCode(INTERNAL_SERVER_ERROR)
                .build();
        traceError(errorResponse.toString(), ex);
        return errorResponse;
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<?> httpRequestMethodNotSupported(
            HttpRequestMethodNotSupportedException ex)
            throws HttpRequestMethodNotSupportedException {
        logger.warn(ex.getMessage(), ex);
        throw ex;
    }

    @ExceptionHandler(CommonErrorException.class)
    public ResponseEntity<ErrorResponse> handleErrorEnum(CommonErrorException ex) {
        traceError(ex.getMessage(), ex);

        HttpStatus httpStatus = ex.getHttpStatus() != null ? ex.getHttpStatus()
                : HttpStatus.INTERNAL_SERVER_ERROR;

        if (ex.getErrorEnum() == null) {
            ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                    .description(ex.getMessage())
                    .errorCode(INTERNAL_SERVER_ERROR)
                    .build();
            ResponseEntity<ErrorResponse> response = new ResponseEntity<ErrorResponse>(
                    errorResponse, httpStatus);
            traceError(errorResponse.toString(), ex);
            return response;
        } else {

            ErrorResponse errorResponse = new ErrorResponse.ErrorResponseBuilder(getTraceId())
                    .description(ex.getDescription())
                    .errorCode(getFullErrorCode(ex.getErrorCode()))
                    .externalErrorCode(ex.getExternalErrorCode())
                    .additionalProperties(ex.getAdditionalProperties())
                    .build();
            ResponseEntity<ErrorResponse> response = new ResponseEntity<ErrorResponse>(
                    errorResponse, ex.getHttpStatus());
            traceError(errorResponse.toString(), ex);
            return response;
        }

    }

    private void traceError(Object errorMsg, Object... args) {
        if (logger.isErrorEnabled()) {
            logger.error(errorMsg.toString(), args);
        }
    }

    private String getTraceId() {
        return "spanAccessor.getCurrentSpan().traceIdString()";
    }

    private String getFieldName(ConstraintViolation<?> constraintViolation) {
        String fieldName = null;
        if (constraintViolation != null && constraintViolation.getPropertyPath() != null) {
            String[] results = constraintViolation.getPropertyPath().toString().split("\\.");
            if (results.length > 0) {
                fieldName = results[results.length - 1];
            } else {
                fieldName = constraintViolation.getPropertyPath().toString();
            }
        }
        return fieldName;
    }

    private String getFullErrorCode(String exceptionErrorCode) {

        String fullErrorCode = null;
        if (exceptionErrorCode != null && exceptionErrorCode.length() > ERROR_CODE_LENGTH) {
            fullErrorCode = exceptionErrorCode;
        } else {
            fullErrorCode = serviceIdentifier + exceptionErrorCode;
        }
        return fullErrorCode;

    }

}
