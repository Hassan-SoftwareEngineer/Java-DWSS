package com.llewellyn.cde.otpservice.feign;

import org.springframework.stereotype.Component;

@Component
public class TwilioFeignFallback implements TwilioFeignClient {

    @Override
    public SMSDeliveryResponse sendOTPSMS(SMSDeliveryRequest smsDeliveryRequest) {
        return null;
    }
}
