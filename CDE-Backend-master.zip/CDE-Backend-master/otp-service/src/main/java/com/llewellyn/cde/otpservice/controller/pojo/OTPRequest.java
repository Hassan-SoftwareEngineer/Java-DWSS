package com.llewellyn.cde.otpservice.controller.pojo;

import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@Data
@ToString
public class OTPRequest {

    @NotBlank
    private String userId;
    @NotBlank
    private String mobile;
    private String transactionCode;

}
