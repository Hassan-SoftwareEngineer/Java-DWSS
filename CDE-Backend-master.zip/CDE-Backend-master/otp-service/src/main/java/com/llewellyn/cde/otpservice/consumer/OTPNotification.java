package com.llewellyn.cde.otpservice.consumer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OTPNotification {
    private String userId;
    private String mobile;
    private String transactionCode;
}
