package com.llewellyn.cde.otpservice.controller.pojo;


import lombok.Data;

@Data
public class OTPValidationRequest {
    private String transactionCode;
    private String otpCode;
    private String userId;
}
