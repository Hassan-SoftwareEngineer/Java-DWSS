package com.llewellyn.cde.otpservice.service;

import com.llewellyn.cde.otpservice.controller.pojo.OTPRequest;
import com.llewellyn.cde.otpservice.controller.pojo.OTPValidationRequest;

public interface OTPService {

    String generateOTP(OTPRequest otpRequest);

    boolean isOtpValid(OTPValidationRequest otpValidationRequest);
}
