package com.llewellyn.cde.otpservice.consumer;

import com.llewellyn.cde.otpservice.config.AppConstants;
import com.llewellyn.cde.otpservice.controller.pojo.OTPRequest;
import com.llewellyn.cde.otpservice.service.OTPService;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Slf4j
@Service public class KafkaConsumer {

    @Autowired
    private OTPService otpService;

    @KafkaListener(topics = AppConstants.TOPIC_NAME, groupId = AppConstants.GROUP_ID)
    public void consume(String message) {
        try {
            OTPNotification otpNotification = new ObjectMapper().readValue(message, OTPNotification.class);
            OTPRequest otpRequest = new OTPRequest();
            otpRequest.setMobile(otpNotification.getMobile());
            otpRequest.setUserId(otpNotification.getUserId());
            otpRequest.setTransactionCode(otpNotification.getTransactionCode());
            otpService.generateOTP(otpRequest);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        log.info(String.format("Message Received  -> %s", message));
    }
}
