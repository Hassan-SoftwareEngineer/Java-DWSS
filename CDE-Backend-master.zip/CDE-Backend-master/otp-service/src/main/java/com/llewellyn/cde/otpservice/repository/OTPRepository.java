package com.llewellyn.cde.otpservice.repository;

import com.llewellyn.cde.otpservice.model.OTPEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface OTPRepository extends CrudRepository<OTPEntity, UUID> {

    Optional<OTPEntity> findOTPEntityByTransactionCodeAndOtpCodeAndIsCodeVerified(String transactionCode, String otpCode, Boolean isCodeVerified);

    @Query(value = "select * from otp oe\n" +
            " where LEFT(oe.otp_generation_timestamp, 10) = LEFT(NOW(),10)" +
            " and mobile=:mobile", nativeQuery = true)
    Optional<OTPEntity> findOTPEntityByTodayDateTimeStamp(@Param("mobile") String mobile);

}
