package com.llewellyn.cde.otpservice.feign;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
public class SMSDeliveryResponse {

    @JsonProperty("sms_request_id")
    private String smsTransactionId;
}
