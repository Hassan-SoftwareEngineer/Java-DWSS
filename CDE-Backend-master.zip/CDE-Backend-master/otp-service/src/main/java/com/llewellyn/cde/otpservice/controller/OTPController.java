package com.llewellyn.cde.otpservice.controller;

import com.llewellyn.cde.otpservice.controller.pojo.OTPRequest;
import com.llewellyn.cde.otpservice.controller.pojo.OTPValidationRequest;
import com.llewellyn.cde.otpservice.service.OTPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Collections;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class OTPController {


    private final OTPService otpService;

    public OTPController(OTPService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/generate-otp")
    public ResponseEntity<?> generateOTP(@Valid @RequestBody OTPRequest otpRequest) {
        return ResponseEntity.ok(otpService.generateOTP(otpRequest));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verify(@Valid @RequestBody OTPValidationRequest otpValidationRequest) {
        boolean isValidOTP = otpService.isOtpValid(otpValidationRequest);
        return ResponseEntity.ok(Collections.singletonMap("isValidOTP", isValidOTP));
    }
}
