package com.llewellyn.cde.otpservice.config;

public class AppConstants {
    public static final String TOPIC_NAME = "otp";
    public static final String GROUP_ID = "otp_group";
}