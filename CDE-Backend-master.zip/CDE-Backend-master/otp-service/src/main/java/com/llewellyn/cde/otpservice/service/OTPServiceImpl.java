package com.llewellyn.cde.otpservice.service;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.otpservice.controller.pojo.OTPRequest;
import com.llewellyn.cde.otpservice.controller.pojo.OTPValidationRequest;
import com.llewellyn.cde.otpservice.feign.SMSDeliveryRequest;
import com.llewellyn.cde.otpservice.feign.SMSDeliveryResponse;
import com.llewellyn.cde.otpservice.feign.TwilioFeignClient;
import com.llewellyn.cde.otpservice.model.OTPEntity;
import com.llewellyn.cde.otpservice.repository.OTPRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;

@Service
@Slf4j
public class OTPServiceImpl implements OTPService {

    private final OTPRepository otpRepository;
    private final TwilioFeignClient twilioFeignClient;

    @Value("${otp.daily-limit:3}")
    private Integer otpDailyLimit;

    public OTPServiceImpl(OTPRepository otpRepository, TwilioFeignClient twilioFeignClient) {
        this.otpRepository = otpRepository;
        this.twilioFeignClient = twilioFeignClient;
    }

    public static String getRandomNumberString() {
        Random rnd = new Random();
        int number = rnd.nextInt(999999);
        return String.format("%06d", number);
    }

    @Override
    @Async
    public String generateOTP(OTPRequest otpRequest) {
        OTPEntity otpEntity;
        otpEntity = getOTPEntityForMobileOnCurrentDate(otpRequest.getMobile());
        if (Objects.isNull(otpEntity)) {
            otpEntity = new OTPEntity();
        }
        if (Objects.nonNull(otpEntity.getOtpRetries()) && otpEntity.getOtpRetries().equals(otpDailyLimit)) {
            throw new CommonErrorException("Daily OTP limit has been exceeded");
        }


        Integer otpRetries = otpEntity.getOtpRetries();
        otpRetries = Objects.nonNull(otpRetries) ? otpRetries + 1 : Integer.valueOf(1);

        String transactionCode = otpRequest.getTransactionCode();
        String otpCode = getRandomNumberString();
        otpEntity.setMobile(otpRequest.getMobile());
        otpEntity.setUserId(otpRequest.getUserId());
        otpEntity.setOtpCode(otpCode);
        otpEntity.setTransactionCode(transactionCode);
        otpEntity.setIsCodeVerified(Boolean.FALSE);
        otpEntity.setOtpGenerationTimestamp(Instant.now());
        otpEntity.setOtpRetries(otpRetries);
        otpRepository.save(otpEntity);
        SMSDeliveryResponse response = twilioFeignClient.sendOTPSMS(generateSMSDeliveryRequest(otpRequest.getMobile(), otpCode));
        log.info("Response is " + response);
        return transactionCode;
    }

    private SMSDeliveryRequest generateSMSDeliveryRequest(String msisdn, String otpCode) {
        SMSDeliveryRequest request = new SMSDeliveryRequest();
        request.setMsisdn(msisdn);
        request.setText("Your OTP to reset password is " + otpCode);
        return request;
    }


    private OTPEntity getOTPEntityForMobileOnCurrentDate(String mobile) {
        Optional<OTPEntity> otpEntity = otpRepository.findOTPEntityByTodayDateTimeStamp(mobile);
        if (!otpEntity.isPresent()) {
            return null;
        } else {
            return otpEntity.get();
        }
    }

    @Override
    public boolean isOtpValid(OTPValidationRequest otpValidationRequest) {
        Optional<OTPEntity> optionalOtpEntity = otpRepository.findOTPEntityByTransactionCodeAndOtpCodeAndIsCodeVerified(otpValidationRequest.getTransactionCode(), otpValidationRequest.getOtpCode(), Boolean.FALSE);
        boolean isValidOtp = false;
        if (optionalOtpEntity.isPresent()) {
            isValidOtp = true;
            OTPEntity otpEntity = optionalOtpEntity.get();
            otpEntity.setIsCodeVerified(Boolean.TRUE);
            otpRepository.save(otpEntity);
        }
        return isValidOtp;
    }

    private String generateTransactionCode() {
        int n = 6;
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {
            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());
            sb.append(AlphaNumericString
                    .charAt(index));
        }
        return sb.toString();
    }
}
