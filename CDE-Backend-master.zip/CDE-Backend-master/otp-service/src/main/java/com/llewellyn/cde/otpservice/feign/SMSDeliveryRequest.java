package com.llewellyn.cde.otpservice.feign;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@JsonAutoDetect
@Data
@ToString
public class SMSDeliveryRequest {

    @NotBlank
    private String msisdn;
    @NotBlank
    private String text;
}
