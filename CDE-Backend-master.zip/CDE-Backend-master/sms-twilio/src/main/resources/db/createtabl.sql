CREATE TABLE IF NOT EXISTS `sms_requests` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `msisdn` varchar(45) DEFAULT NULL,
  `user_id` varchar(60) DEFAULT NULL,
  `text` TEXT DEFAULT NULL,
  `language` CHAR(3) DEFAULT NULL,
  `request_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('SUCCESS','ERROR') DEFAULT NULL,
  `correlation_id` varchar(64) DEFAULT NULL,
  `request_trx_id` varchar(64) DEFAULT NULL,
  `request_log_id` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `msisdn_index` (`msisdn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `log_external_requests` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `msisdn` varchar(45) DEFAULT NULL,
    `request_payload` TEXT DEFAULT NULL,
    `response_payload` TEXT DEFAULT NULL,
    `request_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `url` varchar(256) DEFAULT NULL,
    `http_response_code` char(3) DEFAULT NULL,
    `request_trx_id` varchar(64) DEFAULT NULL,
    `correlation_id` varchar(64) DEFAULT NULL,
    `response_headers` varchar(600) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `msisdn_index` (`msisdn`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `log_external_requests` MODIFY COLUMN `response_headers` TEXT DEFAULT NULL;