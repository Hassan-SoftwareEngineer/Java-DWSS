package com.llewellyn.cde.twilio.model;

public enum ProcessedStatus {
    SUCCESS, ERROR;
}
