package com.llewellyn.cde.twilio.client.interceptor;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.AbstractClientHttpResponse;
import org.springframework.http.client.ClientHttpResponse;

public class ReadableBodyResponse extends AbstractClientHttpResponse {

    private static final Logger logger = LoggerFactory.getLogger(ReadableBodyResponse.class);
    private final ClientHttpResponse httpResponse;
    private InputStream body;

    ReadableBodyResponse(ClientHttpResponse httpResponse) {
        this.httpResponse = httpResponse;
        try {
            logger.debug("wrapping response to be able to get response body multiple times: "
                    + httpResponse != null
                            ? (httpResponse.getStatusText() + ", " + httpResponse.getRawStatusCode()
                                    + ", is body available?:"
                                    + (httpResponse.getBody().available() > 0))
                            : "response is null!!!");
        } catch (Exception e) {
            logger.warn(e.getMessage());
        }
    }

    @Override
    public int getRawStatusCode() throws IOException {
        return this.httpResponse.getRawStatusCode();
    }

    @Override
    public String getStatusText() throws IOException {
        return this.httpResponse.getStatusText();
    }

    @Override
    public HttpHeaders getHeaders() {
        return this.httpResponse.getHeaders();
    }

    @Override
    public InputStream getBody() throws IOException {
        InputStream inputStream = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (body != null) {
            inputStream = body;
        } else {
            inputStream = this.httpResponse.getBody();
        }
        try {
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) > -1) {
                baos.write(buffer, 0, len);
            }
            baos.flush();
            body = new ByteArrayInputStream(baos.toByteArray());
            return new ByteArrayInputStream(baos.toByteArray());
        } finally {
            baos.close();
        }
    }

    @Override
    public void close() {
        try {
            try {
                if (this.httpResponse.getBody() != null) {
                    this.httpResponse.getBody().close();
                }
                if (this.body != null) {
                    this.body.close();
                }
            } finally {
                if (this.httpResponse instanceof Closeable) {
                    ((Closeable) this.httpResponse).close();
                }
            }
        } catch (IOException ex) {
            logger.error("Error when trying to close response: " + ex.getMessage());
        }
    }

}
