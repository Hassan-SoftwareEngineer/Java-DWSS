package com.llewellyn.cde.twilio.client.interceptor;

import java.io.IOException;
import java.util.Stack;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;

public class RequestResponsePropagate {

    private final Stack<RequestResponse> requestResponseSet = new Stack<>();
    private static final Logger logger = LoggerFactory.getLogger(RequestResponsePropagate.class);

    public static class RequestResponse {
        private String request = null;
        private String url = null;
        private String response = null;
        private String responseCode = null;
        private String responseHeaders = null;

        public RequestResponse(final HttpRequest request, final byte[] requestBody,
                final ClientHttpResponse clientHttpResponse) {
            try {
                this.request = new String(requestBody, "UTF-8");
                this.url = request.getURI().toString();
                this.responseCode = clientHttpResponse.getStatusCode().toString();
                this.response = IOUtils.toString(clientHttpResponse.getBody(), "UTF8");
                this.responseHeaders = clientHttpResponse.getHeaders().toString();
            } catch (Exception e) {
                logger.warn("error occured when trying to get request or/and response: "
                        + e.getMessage());
            }
        }

        public String getRequest() {
            return request;
        }

        public void setRequest(String request) {
            this.request = request;
        }

        public String getUrl() {
            return url;
        }

        public String getResponse() {
            return response;
        }

        public String getResponseCode() {
            return responseCode;
        }

        public String getResponseHeaders() {
            return responseHeaders;
        }

    }

    public RequestResponsePropagate() {

    }

    public RequestResponsePropagate(final HttpRequest request, final byte[] requestBody,
            final ClientHttpResponse response) throws IOException {
        add(request, requestBody, response);
    }

    public void add(final HttpRequest request, final byte[] requestBody,
            final ClientHttpResponse response) throws IOException {
        requestResponseSet.add(new RequestResponse(request, requestBody, response));
    }

    public RequestResponse next() {
        return requestResponseSet.pop();
    }

    public boolean hasNext() {
        return !requestResponseSet.isEmpty();
    }

}
