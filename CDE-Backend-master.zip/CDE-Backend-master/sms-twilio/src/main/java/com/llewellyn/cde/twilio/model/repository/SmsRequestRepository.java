package com.llewellyn.cde.twilio.model.repository;

import org.springframework.data.repository.CrudRepository;

import com.llewellyn.cde.twilio.model.SmsRequest;

public interface SmsRequestRepository extends CrudRepository<SmsRequest, Integer> {

}
