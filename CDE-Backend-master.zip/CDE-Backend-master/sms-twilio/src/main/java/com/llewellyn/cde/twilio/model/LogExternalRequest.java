package com.llewellyn.cde.twilio.model;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "log_external_requests")
@Data
@ToString
public class LogExternalRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "msisdn")
    private String msisdn;
    @Lob
    @Column(name = "request_payload")
    private String requestPayload;
    @Lob
    @Column(name = "response_payload")
    private String responsePayload;
    @Column(name = "request_date", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestDate;
    @Column(name = "url")
    private String url;
    @Column(name = "http_response_code")
    private String httpResponseCode;
    @Column(name = "response_headers")
    private String responseHeaders;

    public LogExternalRequest() {
        super();
    }

    public LogExternalRequest(String msisdn, String url) {
        super();
        this.msisdn = msisdn;
        this.url = url;
    }

}
