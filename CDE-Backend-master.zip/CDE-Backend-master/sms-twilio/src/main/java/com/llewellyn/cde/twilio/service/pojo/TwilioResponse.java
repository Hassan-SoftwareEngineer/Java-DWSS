
package com.llewellyn.cde.twilio.service.pojo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonAutoDetect
public class TwilioResponse {

    @JsonProperty("sid")
    private String sid;
    @JsonProperty("date_created")
    private Date dateCreated;
    @JsonProperty("date_updated")
    private Date dateUpdated;
    @JsonProperty("date_sent")
    private Date dateSent;
    @JsonProperty("account_sid")
    private String accountSid;
    @JsonProperty("to")
    private String to;
    @JsonProperty("from")
    private String from;
    @JsonProperty("messaging_service_sid")
    private Integer messagingServiceSid;
    @JsonProperty("body")
    private String body;
    @JsonProperty("status")
    private String status;
    @JsonProperty("num_segments")
    private Integer numSegments;
    @JsonProperty("num_media")
    private Integer numMedia;
    @JsonProperty("direction")
    private String direction;
    @JsonProperty("api_version")
    private String apiVersion;
    @JsonProperty("price")
    private String price;
    @JsonProperty("price_unit")
    private String priceUnit;
    @JsonProperty("error_code")
    private String errorCode;
    @JsonProperty("error_message")
    private String errorMessage;
    @JsonProperty("uri")
    private String uri;
    @JsonProperty("subresource_uris")
    private SubresourceUris subresourceUris;

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    public Date getDateSent() {
        return dateSent;
    }

    public void setDateSent(Date dateSent) {
        this.dateSent = dateSent;
    }

    public String getAccountSid() {
        return accountSid;
    }

    public void setAccountSid(String accountSid) {
        this.accountSid = accountSid;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public Integer getMessagingServiceSid() {
        return messagingServiceSid;
    }

    public void setMessagingServiceSid(Integer messagingServiceSid) {
        this.messagingServiceSid = messagingServiceSid;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getNumSegments() {
        return numSegments;
    }

    public void setNumSegments(Integer numSegments) {
        this.numSegments = numSegments;
    }

    public Integer getNumMedia() {
        return numMedia;
    }

    public void setNumMedia(Integer numMedia) {
        this.numMedia = numMedia;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(String priceUnit) {
        this.priceUnit = priceUnit;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public SubresourceUris getSubresourceUris() {
        return subresourceUris;
    }

    public void setSubresourceUris(SubresourceUris subresourceUris) {
        this.subresourceUris = subresourceUris;
    }

    @Override
    public String toString() {
        return "TwilioResponse [sid=" + sid + ", dateCreated=" + dateCreated + ", dateUpdated="
                + dateUpdated + ", dateSent=" + dateSent + ", accountSid=" + accountSid + ", to="
                + to + ", from=" + from + ", messagingServiceSid=" + messagingServiceSid + ", body="
                + body + ", status=" + status + ", numSegments=" + numSegments + ", numMedia="
                + numMedia + ", direction=" + direction + ", apiVersion=" + apiVersion + ", price="
                + price + ", priceUnit=" + priceUnit + ", errorCode=" + errorCode
                + ", errorMessage=" + errorMessage + ", uri=" + uri + ", subresourceUris="
                + subresourceUris + "]";
    }

}
