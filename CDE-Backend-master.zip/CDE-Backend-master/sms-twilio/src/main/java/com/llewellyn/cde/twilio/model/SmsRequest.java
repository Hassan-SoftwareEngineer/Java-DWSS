package com.llewellyn.cde.twilio.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "sms_requests")
@Data
public class SmsRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "msisdn")
    private String msisdn;
    @Column(name = "user_id")
    private String userId;
    @Lob
    @Column(name = "text")
    private String text;
    @Column(name = "language")
    private String language;
    @Column(name = "request_date", insertable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestDate;
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private ProcessedStatus status;
    @Column(name = "request_trx_id")
    private String requestTrxId;
    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "request_log_id")
    private LogExternalRequest logExternalRequest;

    public SmsRequest() {
        super();
    }

    public SmsRequest(String msisdn, String text) {
        super();
        this.msisdn = msisdn;
        this.text = text;
    }
}
