package com.llewellyn.cde.twilio.service;

import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryRequest;
import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryResponse;

public interface TwilioGatewayService {

    public SmsDeliveryResponse send(SmsDeliveryRequest request);

}
