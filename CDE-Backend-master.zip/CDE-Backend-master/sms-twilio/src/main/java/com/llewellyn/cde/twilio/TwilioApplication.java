package com.llewellyn.cde.twilio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.llewellyn.cde.twilio.configuration.TwilioServiceConfigurations;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(scanBasePackages = { "com.llewellyn" })
@EnableEurekaClient
@EnableSwagger2
@EnableConfigurationProperties(TwilioServiceConfigurations.class)
public class TwilioApplication {

    public static void main(String[] args) {
        SpringApplication.run(TwilioApplication.class, args);
    }

}
