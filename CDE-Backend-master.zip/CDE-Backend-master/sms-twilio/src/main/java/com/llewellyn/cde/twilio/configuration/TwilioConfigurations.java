package com.llewellyn.cde.twilio.configuration;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.llewellyn.cde.twilio.client.interceptor.RequestInterceptor;

@Configuration
public class TwilioConfigurations {

    private static final Logger logger = LoggerFactory.getLogger(TwilioConfigurations.class);
    private static final String BASIC = "Basic ";

    @Autowired
    private TwilioServiceConfigurations config;

    @Bean("twilioClient")
    public RestTemplate getClient(
            @Qualifier("twilioClientSmsMessage") ClientHttpRequestFactory clientHttpRequestFactory) {

        logger.debug("instantiating rest template...");

        RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory);
        List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();
        messageConverters.add(new StringHttpMessageConverter(Charset.forName("UTF-8")));
        messageConverters.add(new FormHttpMessageConverter());
        restTemplate.setMessageConverters(messageConverters);

        restTemplate.getInterceptors().add(new RequestInterceptor());

        return restTemplate;
    }

    @Bean("twilioClientHeaders")
    public HttpHeaders createHeaders() {
        return new HttpHeaders() {
            {
                String auth = new StringBuilder(config.getKey()).append(":")
                        .append(config.getPassword()).toString();
                byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("UTF-8")));
                String authHeader = new StringBuilder().append(BASIC)
                        .append(new String(encodedAuth)).toString();
                set("Authorization", authHeader);
                setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            }
        };
    }

    @Bean("twilioClientSmsMessage")
    public ClientHttpRequestFactory clientHttpSmsMessage() {

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

        logger.debug("setting request factory timeout to [{}] milliseconds.", config.getTimeout());

        requestFactory.setReadTimeout(config.getTimeout());
        requestFactory.setConnectTimeout(config.getTimeout());

        return requestFactory;
    }

    @Bean("twilio_sms_url")
    public String getSmsUrl() throws MalformedURLException {
        if (config.getPort() == null) {
            return new URL(config.getProtocol(), config.getHost(), config.getSms().getPath())
                    .toString();
        } else {
            return new URL(config.getProtocol(), config.getHost(), config.getPort(),
                    config.getSms().getPath()).toString();
        }
    }
}
