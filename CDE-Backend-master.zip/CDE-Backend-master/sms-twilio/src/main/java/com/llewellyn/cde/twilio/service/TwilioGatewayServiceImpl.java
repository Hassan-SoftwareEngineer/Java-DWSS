package com.llewellyn.cde.twilio.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryRequest;
import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryResponse;
import com.llewellyn.cde.twilio.exception.ErrorEnum;
import com.llewellyn.cde.twilio.model.ProcessedStatus;
import com.llewellyn.cde.twilio.model.SmsRequest;
import com.llewellyn.cde.twilio.model.service.TwilioModelService;
import com.llewellyn.cde.twilio.service.client.TwilioGatewayClientService;
import com.llewellyn.cde.twilio.service.pojo.TwilioResponse;

@Service(value = "twilioGatewayService")
public class TwilioGatewayServiceImpl implements TwilioGatewayService {

    private static Logger logger = LoggerFactory.getLogger(TwilioGatewayServiceImpl.class);

    @Autowired
    private TwilioModelService modelService;

    @Autowired
    @Qualifier("twilio_sms_url")
    private String url;

    @Autowired
    @Qualifier("twilioGatewayClientService")
    private TwilioGatewayClientService client;

    @Override
    public SmsDeliveryResponse send(SmsDeliveryRequest request) {

        SmsRequest smsRequest = modelService.buildAndCreateSmsRequest(request, url);
        ProcessedStatus status = ProcessedStatus.ERROR;

        String smsTransactionId = null;
        try {

            TwilioResponse response = client.sendMessage(request.getMsisdn(), request.getText());

            smsTransactionId = response.getSid();
            status = ProcessedStatus.SUCCESS;

        } catch (ResourceAccessException e) {
            logger.error("could not perform charge request", e);
            throw new CommonErrorException(ErrorEnum.TIMEOUT);
        } catch (CommonErrorException e) {
            logger.error("could not perform charge request", e);
            throw e;
        } catch (Exception e) {
            logger.error("could not perform charge request", e);
            throw new CommonErrorException(ErrorEnum.INTERNAL_SERVER_ERROR, null, null);
        } finally {
            modelService.updateChargeRequest(smsRequest, status, url);
        }

        return new SmsDeliveryResponse(smsTransactionId);

    }

}
