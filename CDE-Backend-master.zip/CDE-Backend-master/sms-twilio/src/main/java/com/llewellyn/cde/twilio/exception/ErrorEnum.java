/*
 * 
 */
package com.llewellyn.cde.twilio.exception;

import org.springframework.http.HttpStatus;

import com.llewellyn.cde.commons.exception.ErrorPrinter;

public enum ErrorEnum implements ErrorPrinter {

    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR,
            ErrorEnumConstants.INTERNAL_SERVER_ERROR_CODE,
            ErrorEnumConstants.INTERNAL_SERVER_EXT_ERROR_CODE,
            ErrorEnumConstants.INTERNAL_SERVER_ERROR_DESC),

    INVALID_REQUEST_PARAM(HttpStatus.BAD_REQUEST,
            ErrorEnumConstants.MANDATORY_REQUEST_PARAM_ERROR_CODE,
            ErrorEnumConstants.MANDATORY_REQUEST_PARAM_EXT_ERROR_CODE,
            ErrorEnumConstants.MANDATORY_REQUEST_PARAM_DESC),

    EXTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, ErrorEnumConstants.EXTERNAL_ERROR_ERROR_CODE,
            ErrorEnumConstants.EXTERNAL_ERROR_EXT_ERROR_CODE,
            ErrorEnumConstants.EXTERNAL_ERROR_DESC),

    TIMEOUT(HttpStatus.GATEWAY_TIMEOUT, ErrorEnumConstants.TIMEOUT_ERROR_CODE,
            ErrorEnumConstants.TIMEOUT_EXT_ERROR_CODE, ErrorEnumConstants.TIMEOUT_DESC);

    private HttpStatus httpStatus;
    private String description;
    private String externalErrorCode;
    private String errorCode;

    /**
     * Instantiates a new error enum.
     *
     * @param httpStatus
     *            the http status
     * @param errorCode
     *            the error code
     * @param externalErrorCode
     *            the external error code
     * @param description
     *            the description
     */
    private ErrorEnum(HttpStatus httpStatus, String errorCode, String externalErrorCode,
            String description) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.externalErrorCode = externalErrorCode;
        this.description = description;
    }

    @Override
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getExternalErrorCode() {
        return externalErrorCode;
    }
}