package com.llewellyn.cde.twilio.service.client;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.twilio.configuration.TwilioServiceConfigurations;
import com.llewellyn.cde.twilio.exception.ErrorEnum;
import com.llewellyn.cde.twilio.service.pojo.TwilioResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

@RefreshScope
@Service(value = "twilioGatewayClientService")
public class TwilioGatewayClientServiceImpl implements TwilioGatewayClientService {

    private static final Logger logger = LoggerFactory
            .getLogger(TwilioGatewayClientServiceImpl.class);

    private static final String CODE = "code";
    private static final String MESSAGE = "message";

    @Autowired
    private TwilioServiceConfigurations config;

    @Autowired
    @Qualifier("twilioClient")
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("twilioClientHeaders")
    private HttpHeaders headers;

    @Autowired
    @Qualifier("twilio_sms_url")
    private String url;

    @Override
    public TwilioResponse sendMessage(final String msisdn, final String message) {

        final MultiValueMap<String, String> entityMap = new LinkedMultiValueMap<>();
        entityMap.add("From", config.getSms().getSenderAddress());
        entityMap.add("To", "+" + msisdn);
        entityMap.add("Body", message);

        ResponseEntity<TwilioResponse> resultEntity = null;
        try {
            resultEntity = restTemplate.exchange(url, HttpMethod.POST, getHttpEntity(entityMap),
                    TwilioResponse.class);
        } catch (HttpStatusCodeException httpStatusCodeException) {
            handleException(httpStatusCodeException);
        }

        TwilioResponse result = resultEntity.getBody();

        checkResponseCode(result);

        return result;
    }

    private HttpEntity<MultiValueMap<String, String>> getHttpEntity(
            MultiValueMap<String, String> request) {
        return new HttpEntity<MultiValueMap<String, String>>(request, headers);
    }

    private void checkResponseCode(TwilioResponse twilioResponse) {

        logger.debug("errorCode is [{}] and errorMessage is [{}].", twilioResponse.getErrorCode(),
                twilioResponse.getErrorMessage());

        if (twilioResponse.getErrorCode() != null) {
            throw new CommonErrorException(ErrorEnum.EXTERNAL_ERROR, twilioResponse.getErrorCode(),
                    twilioResponse.getErrorMessage());
        }
    }

    private void handleException(RestClientResponseException e) {

        logger.debug("respponse is [{}].", e.getResponseBodyAsString());

        try {
            JSONObject response = new JSONObject(e.getResponseBodyAsString());

            throw new CommonErrorException(ErrorEnum.EXTERNAL_ERROR, response.getString(CODE),
                    response.getString(MESSAGE));

        } catch (JSONException e1) {
            logger.error("Cannot get the reason", e1);
            throw new CommonErrorException(ErrorEnum.INTERNAL_SERVER_ERROR, null, null);
        }

    }

}
