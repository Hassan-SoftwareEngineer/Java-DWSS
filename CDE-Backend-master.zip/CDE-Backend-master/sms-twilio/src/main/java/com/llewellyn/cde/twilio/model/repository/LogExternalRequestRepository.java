package com.llewellyn.cde.twilio.model.repository;

import org.springframework.data.repository.CrudRepository;

import com.llewellyn.cde.twilio.model.LogExternalRequest;

public interface LogExternalRequestRepository extends CrudRepository<LogExternalRequest, Integer> {

}
