package com.llewellyn.cde.twilio.controller.rest;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryRequest;
import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryResponse;
import com.llewellyn.cde.twilio.service.TwilioGatewayService;

@RestController
@RequestMapping("/v1.0/twilio/sms-request")
@Slf4j
public class TwilioApiGatewayRestController {


    @Autowired
    @Qualifier("twilioGatewayService")
    private TwilioGatewayService service;

    @PostMapping()
    public SmsDeliveryResponse sendSmsThroughTwilio(
            @Valid @RequestBody final SmsDeliveryRequest request) {
        log.info("received sms-request : {}", request);

        final SmsDeliveryResponse response = service.send(request);

        log.info("responding with sms-request : {}", response);
        return response;
    }

}
