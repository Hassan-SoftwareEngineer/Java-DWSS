package com.llewellyn.cde.twilio.service.client;

import com.llewellyn.cde.twilio.service.pojo.TwilioResponse;

public interface TwilioGatewayClientService {

    public TwilioResponse sendMessage(final String msisdn, final String message);

}
