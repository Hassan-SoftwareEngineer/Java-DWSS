package com.llewellyn.cde.twilio.service.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect
public class TwilioRequest {

    private String from;
    private String text;
    private String to;

    public TwilioRequest(String from, String to, String text) {
        super();
        this.from = from;
        this.text = text;
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "InfobipRequest [from=" + from + ", text=" + text + ", to=" + to + "]";
    }

}
