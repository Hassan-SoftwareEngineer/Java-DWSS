/*
 * 
 */
package com.llewellyn.cde.twilio.exception;

public interface ErrorEnumConstants {

    final String INTERNAL_SERVER_ERROR_DESC = "internal server error";
    final String INTERNAL_SERVER_ERROR_CODE = "000";
    final String INTERNAL_SERVER_EXT_ERROR_CODE = null;

    final String MANDATORY_REQUEST_PARAM_DESC = "invalid/missing mandatory request parameter: {0}";
    final String MANDATORY_REQUEST_PARAM_ERROR_CODE = "001";
    final String MANDATORY_REQUEST_PARAM_EXT_ERROR_CODE = null;

    final String EXTERNAL_ERROR_DESC = "{1}";
    final String EXTERNAL_ERROR_ERROR_CODE = "004";
    final String EXTERNAL_ERROR_EXT_ERROR_CODE = "{0}";

    final String TIMEOUT_DESC = "requesting to twilio timed out";
    final String TIMEOUT_ERROR_CODE = "010";
    final String TIMEOUT_EXT_ERROR_CODE = null;

}
