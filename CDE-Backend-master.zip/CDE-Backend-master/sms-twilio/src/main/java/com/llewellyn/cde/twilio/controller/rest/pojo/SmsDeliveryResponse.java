package com.llewellyn.cde.twilio.controller.rest.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@JsonAutoDetect
@Data
@ToString
public class SmsDeliveryResponse {

    @JsonProperty("sms_request_id")
    private String smsTransactionId;

    public SmsDeliveryResponse(String smsTransactionId) {
        super();
        this.smsTransactionId = smsTransactionId;
    }

}
