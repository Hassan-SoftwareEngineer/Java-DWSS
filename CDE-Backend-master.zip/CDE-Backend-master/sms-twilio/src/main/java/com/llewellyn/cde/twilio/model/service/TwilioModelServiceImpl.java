package com.llewellyn.cde.twilio.model.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.llewellyn.cde.twilio.client.interceptor.RequestResponseHolder;
import com.llewellyn.cde.twilio.client.interceptor.RequestResponsePropagate.RequestResponse;
import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryRequest;
import com.llewellyn.cde.twilio.model.LogExternalRequest;
import com.llewellyn.cde.twilio.model.ProcessedStatus;
import com.llewellyn.cde.twilio.model.SmsRequest;
import com.llewellyn.cde.twilio.model.repository.LogExternalRequestRepository;
import com.llewellyn.cde.twilio.model.repository.SmsRequestRepository;

@Service
public class TwilioModelServiceImpl implements TwilioModelService {

    private static final Logger logger = LoggerFactory.getLogger(TwilioModelServiceImpl.class);

    @Autowired
    private SmsRequestRepository smsRequestRepository;

    @Autowired
    private LogExternalRequestRepository logExternalRequestRepository;

    @Override
    public SmsRequest buildAndCreateSmsRequest(SmsDeliveryRequest request, String url) {

        LogExternalRequest logExternalRequest = new LogExternalRequest(request.getMsisdn(), url);

        logExternalRequest = logExternalRequestRepository.save(logExternalRequest);

        SmsRequest smsrequest = new SmsRequest(request.getMsisdn(),
                request.getText());

        smsrequest.setLogExternalRequest(logExternalRequest);

        smsrequest = smsRequestRepository.save(smsrequest);

        return smsrequest;
    }

    @Override
    public void updateChargeRequest(SmsRequest smsRequest, ProcessedStatus status, String url) {

        smsRequest.setStatus(status);
        smsRequestRepository.save(smsRequest);

        LogExternalRequest updatedRequest = smsRequest.getLogExternalRequest();

        if (RequestResponseHolder.hasNextRequestResponse()) {
            RequestResponse current = RequestResponseHolder.getNextRequestResponse();

            updatedRequest.setRequestPayload(RequestResponseHolder.getRequest(current));
            updatedRequest.setResponsePayload(RequestResponseHolder.getResponse(current));
            updatedRequest.setHttpResponseCode(RequestResponseHolder.getResponseCode(current));
            updatedRequest.setResponseHeaders(RequestResponseHolder.getResponseHeaders(current));
            logExternalRequestRepository.save(updatedRequest);
            logger.info("Call to {} with payload {}", url, updatedRequest.getRequestPayload());
            logger.info("Response {} and status {}", updatedRequest.getResponsePayload(),
                    updatedRequest.getHttpResponseCode());

            logExternalRequestRepository.save(updatedRequest);
        }

    }

}
