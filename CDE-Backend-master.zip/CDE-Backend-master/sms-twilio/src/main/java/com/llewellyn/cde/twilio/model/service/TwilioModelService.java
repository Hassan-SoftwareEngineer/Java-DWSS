package com.llewellyn.cde.twilio.model.service;

import com.llewellyn.cde.twilio.controller.rest.pojo.SmsDeliveryRequest;
import com.llewellyn.cde.twilio.model.ProcessedStatus;
import com.llewellyn.cde.twilio.model.SmsRequest;

public interface TwilioModelService {

    public SmsRequest buildAndCreateSmsRequest(SmsDeliveryRequest request, String url);

    void updateChargeRequest(SmsRequest smsRequest, ProcessedStatus status, String url);

}
