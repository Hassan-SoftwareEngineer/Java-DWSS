package com.llewellyn.cde.twilio.service.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonAutoDetect
public class SubresourceUris {

    @JsonProperty("media")
    private String media;

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

    @Override
    public String toString() {
        return "SubresourceUris [media=" + media + "]";
    }

}
