package com.llewellyn.cde.twilio.controller.rest.pojo;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@JsonAutoDetect
@Data
@ToString
public class SmsDeliveryRequest {

    @NotBlank
    private String msisdn;
    @NotBlank
    private String text;

    public SmsDeliveryRequest() {

    }

}
