package com.llewellyn.cde.twilio.client.interceptor;

import java.io.IOException;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;

import com.llewellyn.cde.twilio.client.interceptor.RequestResponsePropagate.RequestResponse;

public class RequestResponseHolder {

    private static ThreadLocal<RequestResponsePropagate> threadLocal = new ThreadLocal<RequestResponsePropagate>() {
        @Override
        protected RequestResponsePropagate initialValue() {
            return new RequestResponsePropagate();
        }
    };

    private RequestResponseHolder() {
    }

    public static RequestResponsePropagate getRequestResponse() {
        return threadLocal.get();
    }

    public static void propagateRequestResponse(HttpRequest request, byte[] body,
            ClientHttpResponse response) throws IOException {
        threadLocal.get().add(request, body, response);
    }

    public static void removeRequestResponse() {
        threadLocal.remove();
    }

    public static RequestResponse getNextRequestResponse() {
        return threadLocal.get().next();
    }

    public static boolean hasNextRequestResponse() {
        if (threadLocal.get() != null) {
            return threadLocal.get().hasNext();
        }
        return false;
    }

    public static String getUrl(RequestResponse obj) {
        return obj.getUrl();
    }

    public static String getRequest(RequestResponse obj) {
        return obj.getRequest();
    }

    public static String getResponse(RequestResponse obj) {
        return obj.getResponse();
    }

    public static String getResponseCode(RequestResponse obj) {
        return obj.getResponseCode();
    }

    public static String getResponseHeaders(RequestResponse obj) {
        return obj.getResponseHeaders();
    }

}
