package com.llewellyn.cde.user_service.feign.pojo;

import com.llewellyn.cde.user_service.dto.ProjectDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserProjectResponse {
    private List<ProjectDto> projects;
}
