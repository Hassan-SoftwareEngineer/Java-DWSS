package com.llewellyn.cde.user_service.controller.pojo;

import lombok.Data;

@Data
public class ResetPasswordRequest {
    private String userId;
    private String password;
    private String confirmPassword;
}
