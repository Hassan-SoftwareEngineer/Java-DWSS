package com.llewellyn.cde.user_service.service;

import com.llewellyn.cde.user_service.controller.pojo.LoginRequest;
import com.llewellyn.cde.user_service.controller.pojo.ResetPasswordRequest;
import com.llewellyn.cde.user_service.controller.pojo.VerifyOTPRequest;
import com.llewellyn.cde.user_service.dto.UserDto;
import com.llewellyn.cde.user_service.feign.pojo.AccessPermission;
import com.llewellyn.cde.user_service.feign.pojo.UserProjectResponse;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface UserService {
    UserDto creatUser(UserDto user);

    List<UserDto> getAllUsers();

    UserDto getOneUser(UUID user_id);

    UserDto updateUser(UUID user_id, UserDto updatedUser, boolean isUpdateFromLoginFlow);

    UserDetails loginUser(LoginRequest loginRequest);

    UserDto findUserByEmail(String email);

    boolean verifyOTP(VerifyOTPRequest verifyOTPRequest);

    UserDto findUserByUsername(String username);

    UserDetails loginUserWithJWT(LoginRequest loginRequest);

    Map<String, String> generateOtp(String username, String email);

    String resetPassword(ResetPasswordRequest resetPasswordRequest);

    UserProjectResponse getUserProjects(String userId);

    AccessPermission getPermissionsForUser(UUID userId);

    void updateUserDirectReport(UUID userId, String directReportUserId);

}
