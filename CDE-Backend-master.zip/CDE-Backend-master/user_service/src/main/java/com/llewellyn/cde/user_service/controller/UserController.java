package com.llewellyn.cde.user_service.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.user_service.authentication.JWTUtil;
import com.llewellyn.cde.user_service.controller.pojo.GenerateOTPRequest;
import com.llewellyn.cde.user_service.controller.pojo.LoginRequest;
import com.llewellyn.cde.user_service.controller.pojo.ResetPasswordRequest;
import com.llewellyn.cde.user_service.controller.pojo.VerifyOTPRequest;
import com.llewellyn.cde.user_service.dto.ProjectDto;
import com.llewellyn.cde.user_service.dto.UserDto;
import com.llewellyn.cde.user_service.feign.pojo.AccessPermission;
import com.llewellyn.cde.user_service.feign.pojo.PermissionDto;
import com.llewellyn.cde.user_service.feign.pojo.UserProjectResponse;
import com.llewellyn.cde.user_service.kafka.KafkaProducer;
import com.llewellyn.cde.user_service.service.UserService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

@RestController
@Slf4j
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userServiceImp;
    @Autowired
    private JWTUtil jwtUtil;
    @Autowired
    private KafkaProducer kafkaProducer;

    @PostMapping("/auth/login")
    public ResponseEntity<?> loginJWTUser(@Valid @RequestBody LoginRequest loginRequest) {
        UserWithJwt userWithJwt = null;
        UserDto userDto = null;
        boolean throwExceptionAndDontUpdateFailAttempts = false;
        boolean userAuthSuccessful = false;
        Integer fails = 0;
        try {
            userDto = userServiceImp.findUserByUsername(loginRequest.getUsername());
            throwExceptionAndDontUpdateFailAttempts = isAccountLocked(userDto);
            if (throwExceptionAndDontUpdateFailAttempts) {
                throw new CommonErrorException("Your account has been disabled due to wrong password attempts, please ask admin to unlock your account");
            }
            userServiceImp.loginUserWithJWT(loginRequest);
            userAuthSuccessful = true;
            fails = userDto.getFails();
            if (!userDto.isPasswordChanged()) {
                throw new CommonErrorException("Please change your password.");
            }
            UserProjectResponse userProjectResponse = userServiceImp.getUserProjects(userDto.getId().toString());
            AccessPermission accessPermission = userServiceImp.getPermissionsForUser(userDto.getId());
            String token = jwtUtil.generateToken(loginRequest.getUsername());
            userWithJwt = new UserWithJwt(token, userDto, userProjectResponse.getProjects(), accessPermission.getPermissions());
            userDto.setFails(0);
        } catch (BadCredentialsException ex) {
            if (!throwExceptionAndDontUpdateFailAttempts && !userAuthSuccessful) {
                fails = userDto.getFails();
                if (Objects.isNull(fails)) {
                    fails = 0;
                }
                Instant locked = null;
                if (fails == 6) {
                    locked = Instant.now().plus(1, ChronoUnit.HOURS);
                } else if (fails > 10) {
                    locked = Instant.now().plus(999, ChronoUnit.DAYS);
                }
                fails += 1;
                userDto.setLocked(locked);
                userDto.setFails(fails);
                throw new BadCredentialsException("Invalid password.");
            }
        } finally {
            if ((!throwExceptionAndDontUpdateFailAttempts && !userAuthSuccessful) || !Objects.isNull(fails) && fails > 0)
                userServiceImp.updateUser(userDto.getId(), userDto, true);
        }
        return new ResponseEntity<>(userWithJwt, HttpStatus.OK);
    }

    private boolean isFailsAndLockedEmpty(UserDto userDto) {
        return (userDto.getFails() == null || userDto.getFails() == 0) && userDto.getLocked() == null;
    }


    private boolean isAccountLocked(UserDto userDto) {
        boolean isAccountLocked = false;
        if (userDto != null) {
            Instant locked = userDto.getLocked();
            if (locked != null && locked.isAfter(Instant.now())) {
                isAccountLocked = true;
            }
        }
        return isAccountLocked;
    }

    @PostMapping("/auth/user")
    public ResponseEntity<UserDto> createNewUser(@Valid @RequestBody UserDto userDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        UserDto newUser = userServiceImp.creatUser(userDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest().path("user/{id}")
                .buildAndExpand(newUser.getId()).toUri();

        return ResponseEntity.created(locationUri).body(newUser);
    }


    @PutMapping("/v1/users/assign/{userId}/directreport/{directReportUserId}")
    public ResponseEntity<?> assignDirectReportToUser(@PathVariable UUID userId, @PathVariable String directReportUserId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        userServiceImp.updateUserDirectReport(userId, directReportUserId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/v1/users")
    public ResponseEntity<List<UserDto>> getAllUsers() {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        List<UserDto> users = userServiceImp.getAllUsers();

        return ResponseEntity.ok(users);
    }

    @GetMapping("/v1/user/{user_id}")
    public ResponseEntity<UserDto> getOneUser(@PathVariable UUID user_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        UserDto userDto = userServiceImp.getOneUser(user_id);

        return ResponseEntity.ok(userDto);
    }

    @PutMapping("/v1/user/{user_id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable UUID user_id, @RequestBody UserDto projectDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        UserDto updatedUser = userServiceImp.updateUser(user_id, projectDto, false);

        return ResponseEntity.ok(updatedUser);
    }

    @PostMapping("/auth/generate-otp")
    public ResponseEntity<?> generateOTP(@Valid @RequestBody GenerateOTPRequest generateOTPRequest) {
        log.info("Generate OTP Request {} ", generateOTPRequest);
        Map<String, String> otpResponseMap = userServiceImp.generateOtp(generateOTPRequest.getUsername(), generateOTPRequest.getEmail());
        return ResponseEntity.ok(otpResponseMap);
    }


    @PostMapping("/auth/verify-otp")
    public ResponseEntity<?> verifyOTPRequest(@Valid @RequestBody VerifyOTPRequest verifyOTPRequest) {
        log.info("Verify OTP Request {} ", verifyOTPRequest);
        boolean isValidOTP = userServiceImp.verifyOTP(verifyOTPRequest);
        if (isValidOTP) {
            return ResponseEntity.ok(Collections.singletonMap("isValidOTP", isValidOTP));
        } else {
            return ResponseEntity.badRequest().body(Collections.singletonMap("isValidOTP", isValidOTP));
        }

    }

    @PostMapping("/auth/reset-password")
    public ResponseEntity<?> resetPassword(@Valid @RequestBody ResetPasswordRequest resetPasswordRequest) {
        log.info("Generate Reset password Request {} ", resetPasswordRequest);
        String response = userServiceImp.resetPassword(resetPasswordRequest);
        return ResponseEntity.ok(Collections.singletonMap("message", response));
    }

    @Data
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    class UserWithJwt {
        private String token;
        private UserDto user;
        private List<ProjectDto> projects;
        private List<PermissionDto> permissions;
    }
}
