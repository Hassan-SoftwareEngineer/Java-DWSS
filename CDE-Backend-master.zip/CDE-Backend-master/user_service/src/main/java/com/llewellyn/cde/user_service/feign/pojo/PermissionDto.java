package com.llewellyn.cde.user_service.feign.pojo;

import lombok.Data;

@Data
public class PermissionDto {

    private String functionKey;
    private String permissionType;

}
