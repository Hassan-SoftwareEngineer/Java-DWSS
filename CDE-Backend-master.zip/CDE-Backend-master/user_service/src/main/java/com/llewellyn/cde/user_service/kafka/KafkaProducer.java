package com.llewellyn.cde.user_service.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llewellyn.cde.user_service.config.AppConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducer {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendMessage(Object notification) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        String message = objectMapper.writeValueAsString(notification);
        if (notification instanceof UserNotification) {
            kafkaTemplate.send(AppConstants.USER_TOPIC_NAME, message);
        } else if (notification instanceof OTPNotification) {
            kafkaTemplate.send(AppConstants.OTP_TOPIC_NAME, message);
        }
    }
}