package com.llewellyn.cde.user_service.controller.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
public class GenerateOTPRequest {
    @NotBlank
    private String username;
    @NotBlank
    private String email;
}
