package com.llewellyn.cde.user_service.repository;

import com.llewellyn.cde.user_service.model.User;
import com.llewellyn.cde.user_service.model.UserDetailsEntity;
import com.llewellyn.cde.user_service.model.UserSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

public interface UserSettingsRepository extends JpaRepository<UserSettings, UUID> {
    Optional<UserSettings> getUserSettingsByUserHeader(User user);
    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "delete from user_settings where user_id=:userId")
    void deleteUserByUserId(@Param("userId") String userId);
}
