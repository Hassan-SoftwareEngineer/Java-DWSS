package com.llewellyn.cde.user_service.dto;

public enum ClientStatusEnum {
    ONLINE, AWAY, BUSY, OFFLINE
}
