package com.llewellyn.cde.user_service.feign;

import com.llewellyn.cde.user_service.config.AccessServiceFallback;
import com.llewellyn.cde.user_service.feign.pojo.AccessPermission;
import com.llewellyn.cde.user_service.feign.pojo.PermissionDto;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.UUID;

public class AccessServiceFeignClient {
    @FeignClient(name = "access-service", value = "access-service", fallback = AccessServiceFallback.class)
    public interface AccessClient {
        @GetMapping("/api/v1/access/userprojectrole/permission/user/{userId}")
        List<PermissionDto> getUserRolePermissions(@PathVariable("userId") UUID userId);
    }

}
