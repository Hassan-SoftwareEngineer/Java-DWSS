package com.llewellyn.cde.user_service.config;

import com.llewellyn.cde.user_service.feign.AccessServiceFeignClient;
import com.llewellyn.cde.user_service.feign.pojo.AccessPermission;
import com.llewellyn.cde.user_service.feign.pojo.PermissionDto;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class AccessServiceFallback implements AccessServiceFeignClient.AccessClient {

    @Override
    public List<PermissionDto> getUserRolePermissions(UUID userId) {
        return new ArrayList<>();
    }
}
