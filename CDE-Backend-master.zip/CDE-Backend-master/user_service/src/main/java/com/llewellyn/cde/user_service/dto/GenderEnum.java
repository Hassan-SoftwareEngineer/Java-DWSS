package com.llewellyn.cde.user_service.dto;

public enum GenderEnum {
    m, f
}
