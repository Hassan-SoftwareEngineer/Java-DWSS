package com.llewellyn.cde.user_service.model;

import com.llewellyn.cde.user_service.dto.ClientStatusEnum;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "user_details")
@ToString(exclude = "user")
@EqualsAndHashCode(exclude = "user")
public class UserDetailsEntity extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "id")
    private UUID id;

    private String dept;
    private String company;
    private String role;
    private String nickname;
    private String chineseName;
    private String account;
    private String commiter;
    private String avatar;
    private String skype;
    private String qq;
    private String LandLine;
    private String weixin;
    private String dingding;
    private String slack;
    private String whatsapp;
    private String address;
    private String zipcode;
    private Date joinDate;
    private int visits;
    private String ip;
    private int last;
    private ClientStatusEnum clientStatus;
    private String ldap;
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

}
