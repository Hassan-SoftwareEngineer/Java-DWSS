package com.llewellyn.cde.user_service.config;

import com.llewellyn.cde.user_service.controller.pojo.VerifyOTPRequest;
import com.llewellyn.cde.user_service.feign.OTPFeignClient;
import com.llewellyn.cde.user_service.feign.pojo.OTPRequest;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class OTPServiceFallback implements OTPFeignClient.OTPClient {

    @Override
    public String generateOTP(OTPRequest otpRequest) {
        return null;
    }

    @Override
    public Map<String, String> verifyOtp(VerifyOTPRequest otpRequest) {
        return null;
    }
}
