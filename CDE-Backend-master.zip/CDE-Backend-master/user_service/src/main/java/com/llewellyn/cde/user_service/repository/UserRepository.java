package com.llewellyn.cde.user_service.repository;

import com.llewellyn.cde.user_service.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {

    Optional<User> findUserByEmailAndPassword(String email, String password);

    Optional<User> findUserByEmail(String email);

    Optional<User> findUserByUsername(String username);

    Optional<User> findUserByUsernameAndEmail(String username, String email);

    @Modifying(clearAutomatically = true)
    @Query("update User user set user.directReport =:directReportUserId where user.id =:userId")
    void updateUserDirectReport(@Param("directReportUserId") String directReportUserId, @Param("userId") UUID userId);


}
