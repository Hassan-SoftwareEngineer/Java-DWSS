package com.llewellyn.cde.user_service.dto;

public enum ACLEnum {
    OPEN, PRIVATE, CUSTOM
}
