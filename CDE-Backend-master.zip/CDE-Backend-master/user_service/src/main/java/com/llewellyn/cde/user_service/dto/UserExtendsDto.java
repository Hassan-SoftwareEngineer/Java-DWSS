package com.llewellyn.cde.user_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.security.core.userdetails.User;

import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserExtendsDto {
    private UUID id;
    private String column;
    private String value;
    private User user;
}
