package com.llewellyn.cde.user_service.feign;

import com.llewellyn.cde.user_service.config.OTPServiceFallback;
import com.llewellyn.cde.user_service.controller.pojo.VerifyOTPRequest;
import com.llewellyn.cde.user_service.feign.pojo.OTPRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

public class OTPFeignClient {
    @FeignClient(name = "otp-service", value = "otp-service", fallback = OTPServiceFallback.class)
    public interface OTPClient {
        @PostMapping("api/v1/generate-otp")
        String generateOTP(@RequestBody OTPRequest otpRequest);

        @PostMapping("api/v1/verify-otp")
        Map<String, String> verifyOtp(@RequestBody VerifyOTPRequest otpRequest);
    }

}
