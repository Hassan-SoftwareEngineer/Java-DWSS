package com.llewellyn.cde.user_service.model;

import com.llewellyn.cde.user_service.dto.GenderEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "user_header")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User extends BaseEntity {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "id")
    private UUID id;

    @Email
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    private String username;
    private String firstname;
    private String lastname;
    private String password;
    private Date dob;
    @Enumerated(EnumType.STRING)
    private GenderEnum gender;
    private Boolean isActive;
    private Integer fails;
    private Instant locked;
    private boolean isPasswordChanged;
    private String mobile;
    private String directReport;
    @OneToOne(fetch = FetchType.LAZY,
             cascade =  CascadeType.ALL,
             mappedBy = "user")
    private UserDetailsEntity userDetails;

    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "userHeader")
    private UserSettings userSettings;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<UserExtends> userExtends;

}
