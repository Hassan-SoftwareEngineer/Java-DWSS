package com.llewellyn.cde.user_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.llewellyn.cde.user_service.model.User;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(exclude = "userHeader")
@EqualsAndHashCode(exclude = "userHeader")
public class UserSettingsDto {

    private UUID id;
    private String locale;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private User userHeader;
}
