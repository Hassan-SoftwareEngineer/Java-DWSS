package com.llewellyn.cde.user_service.config;

import com.llewellyn.cde.user_service.dto.ProjectDto;
import com.llewellyn.cde.user_service.feign.ProjectFeignClient;
import com.llewellyn.cde.user_service.feign.pojo.UserProjectResponse;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class ProjectServiceFallback implements ProjectFeignClient.ProjectClient {

    @Override
    public UserProjectResponse getUserProjects(String userId) {
        return new UserProjectResponse();
    }
}
