package com.llewellyn.cde.user_service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.llewellyn.cde.user_service.model.User;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Date;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString(exclude = "user")
@EqualsAndHashCode(exclude = "user")
public class UserDetailsDto {


    private UUID id;

    private String dept;
    private String company;
    private String role;
    private String nickname;
    private String chineseName;
    private String account;
    private String commiter;
    private String avatar;
    private String skype;
    private String qq;
    private String LandLine;
    private String weixin;
    private String dingding;
    private String slack;
    private String whatsapp;
    private String address;
    private String zipcode;
    private Date joinDate;
    private int visits;
    private String ip;
    private int last;
    private ClientStatusEnum clientStatus;
    private String ldap;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private User user;
}
