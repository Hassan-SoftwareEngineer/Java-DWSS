package com.llewellyn.cde.user_service.config;

public class AppConstants {
    public static final String USER_TOPIC_NAME = "user";
    public static final String OTP_TOPIC_NAME = "otp";
//    public static final String TOPIC_NAME = "user";
    public static final String GROUP_ID = "user_group";
}