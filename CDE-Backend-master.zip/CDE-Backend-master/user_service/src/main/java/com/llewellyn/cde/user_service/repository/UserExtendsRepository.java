package com.llewellyn.cde.user_service.repository;

import com.llewellyn.cde.user_service.model.User;
import com.llewellyn.cde.user_service.model.UserExtends;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

public interface UserExtendsRepository extends JpaRepository<UserExtends, UUID> {

    void deleteAllByUser(User user);
    List<UserExtends> findUserExtendsByUser(User project);
    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "delete from user_extends where user_id=:userId")
    void deleteAllByUserId(@Param("userId") String userId);

}
