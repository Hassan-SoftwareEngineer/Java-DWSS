package com.llewellyn.cde.user_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDto {

    private UUID id;
    private String name;
    private String code;
    private String type;
    private String address;
    private String area;
    private String country;
    private String city;

    public ProjectDto(UUID id) {
        this.id = id;
    }

}
