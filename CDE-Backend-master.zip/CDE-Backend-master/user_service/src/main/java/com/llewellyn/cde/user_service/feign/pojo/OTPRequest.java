package com.llewellyn.cde.user_service.feign.pojo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OTPRequest {

    private String userId;
    private String mobile;

}

