package com.llewellyn.cde.user_service.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.user_service.authentication.JWTUtil;
import com.llewellyn.cde.user_service.authentication.PasswordAuthentication;
import com.llewellyn.cde.user_service.controller.pojo.LoginRequest;
import com.llewellyn.cde.user_service.controller.pojo.ResetPasswordRequest;
import com.llewellyn.cde.user_service.controller.pojo.VerifyOTPRequest;
import com.llewellyn.cde.user_service.dto.UserDetailsDto;
import com.llewellyn.cde.user_service.dto.UserDto;
import com.llewellyn.cde.user_service.dto.UserSettingsDto;
import com.llewellyn.cde.user_service.exception.Errors;
import com.llewellyn.cde.user_service.feign.AccessServiceFeignClient;
import com.llewellyn.cde.user_service.feign.OTPFeignClient;
import com.llewellyn.cde.user_service.feign.ProjectFeignClient;
import com.llewellyn.cde.user_service.feign.pojo.AccessPermission;
import com.llewellyn.cde.user_service.feign.pojo.OTPRequest;
import com.llewellyn.cde.user_service.feign.pojo.UserProjectResponse;
import com.llewellyn.cde.user_service.kafka.KafkaProducer;
import com.llewellyn.cde.user_service.kafka.OTPNotification;
import com.llewellyn.cde.user_service.kafka.UserNotification;
import com.llewellyn.cde.user_service.model.User;
import com.llewellyn.cde.user_service.model.UserDetailsEntity;
import com.llewellyn.cde.user_service.model.UserExtends;
import com.llewellyn.cde.user_service.model.UserSettings;
import com.llewellyn.cde.user_service.repository.UserDetailsRepository;
import com.llewellyn.cde.user_service.repository.UserExtendsRepository;
import com.llewellyn.cde.user_service.repository.UserRepository;
import com.llewellyn.cde.user_service.repository.UserSettingsRepository;
import com.llewellyn.cde.user_service.util.NullChecker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class UserServiceImp implements UserService {

    private final PasswordAuthentication passwordAuthentication = new PasswordAuthentication();
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private AuthenticationManager authManager;
    @Autowired
    private JWTUtil jwtUtil;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ProjectFeignClient.ProjectClient projectFeignClient;

    @Autowired
    private AccessServiceFeignClient.AccessClient accessFeignClient;

    @Autowired
    private OTPFeignClient.OTPClient otpFeignClient;

    @Autowired
    private UserExtendsRepository userExtendsRepository;

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Autowired
    private UserSettingsRepository userSettingsRepository;

    @Autowired
    private KafkaProducer kafkaProducer;

    @Override
    public UserDto creatUser(UserDto userDto) {
        // TODO Auto-generated method stub
        log.info("Create New User");

        User user = this.dtoToUser(userDto);
        user.setId(UUID.randomUUID());
        String encryptedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encryptedPassword);
        User existingEmailUser = userRepository.findUserByEmail(userDto.getEmail()).orElse(null);
        User existingUsernameUser = userRepository.findUserByUsername(userDto.getUsername()).orElse(null);
        if (Objects.nonNull(existingEmailUser)) {
            throw new CommonErrorException(Errors.USER_ALREADY_EXISTS_EMAIL);
        }
        if (Objects.nonNull(existingUsernameUser)) {
            throw new CommonErrorException(Errors.USER_ALREADY_EXISTS_USERNAME);
        }
        if (Objects.nonNull(userDto.getUserDetails()) && !NullChecker.allNull(userDto.getUserDetails())) {
            UserDetailsEntity userDetails = dtoToUserDetails(userDto.getUserDetails());
            user.setUserDetails(userDetails);
        }
        if (Objects.nonNull(userDto.getUserSettings()) && !NullChecker.allNull(userDto.getUserSettings())) {
            UserSettings userSettings = dtoToUserSettings(userDto.getUserSettings());
            user.setUserSettings(userSettings);
        }

        addUserInfo(userDto, user);
        user.setPasswordChanged(false);
        User newUser = userRepository.save(user);
        UserDto dto = this.userToDto(newUser);
        addExtendsFieldsToUserDto(dto, newUser.getUserExtends());
        sendSignupMessageOnKafka(userDto);
        return dto;
    }

    private void sendSignupMessageOnKafka(UserDto userDto) {
        sendMessageOnKafka(userDto, "signup");
    }

    private void sendOTPOnKafka(OTPNotification otpNotification) {
        sendMessageOnKafka(otpNotification, null);
    }

    private void sendMessageOnKafka(Object notification, String event) {
        Object obj = null;
        if (notification instanceof UserDto) {
            UserDto userDto = (UserDto) notification;
            UserNotification userNotification = new UserNotification();
            userNotification.setEvent(event);
            userNotification.setUsername(userDto.getUsername());
            userNotification.setEmail(userDto.getEmail());
            userNotification.setMobile(userDto.getMobile());
            obj = userNotification;
        }
        if (notification instanceof OTPNotification) {
            OTPNotification otpNotification = (OTPNotification) notification;
            obj = otpNotification;
        }

        try {
            kafkaProducer.sendMessage(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }


    }

    private void addExtendsFieldsToUserDto(UserDto userDto, List<UserExtends> lstUserExtends) {
        if (Objects.nonNull(lstUserExtends)) {
            userDto.setUserExtends(lstUserExtends.stream().collect(Collectors.toMap(UserExtends::getColumn, UserExtends::getValue)));
        }
    }

    private void addUserInfo(UserDto userDto, User user) {
        if (!CollectionUtils.isEmpty(userDto.getUserExtends())) {
            addExtendsFieldsToUser(user, userDto.getUserExtends());
        }
    }

    private void addExtendsFieldsToUser(User user, Map<String, String> userExtendsMap) {
        Set<UserExtends> setUserExtends = userExtendsMap.entrySet().stream().map(pe -> new UserExtends(null, pe.getKey(), pe.getValue(), user)).collect(Collectors.toSet());
        user.setUserExtends(setUserExtends.stream().collect(Collectors.toList()));
    }

    @Override
    public List<UserDto> getAllUsers() {
        // TODO Auto-generated method stub
        log.info("Get All Users");

        List<User> userList = userRepository.findAll();

        return userList.stream().map(this::userToDto).collect(Collectors.toList());
    }

    @Override
    public UserDto getOneUser(UUID user_id) {
        // TODO Auto-generated method stub
        log.info("Get One User with ID {}", user_id);

        Optional<User> optionalUser = userRepository.findById(user_id);
        if (!optionalUser.isPresent()) {
            throw new CommonErrorException(Errors.USER_NOT_FOUND);
        }
        return findUserByUsername(optionalUser.get().getUsername());
    }

    @Override
    public UserDto updateUser(UUID user_id, UserDto userDto, boolean isUpdateFromLoginFlow) {
        // TODO Auto-generated method stub
        log.info("Update User with ID {}", user_id);

        Optional<User> optionalUser = userRepository.findById(user_id);
        if (optionalUser.isEmpty()) {
            throw new CommonErrorException("User not found.");
        }
        User user = optionalUser.get();

        if (userDto.getUserExtends() != null && !userDto.getUserExtends().isEmpty()) {
            userExtendsRepository.deleteAllByUserId(user.getId().toString());
        }

        UserDetailsEntity ude = null;
        if (Objects.nonNull(userDto.getUserDetails()) && !NullChecker.allNull(userDto.getUserDetails())) {
            ude = assignUserDetailsToUser(user, userDto);
        } else {
            userDetailsRepository.deleteUserDetailsEntitiesByUser(user_id.toString());
        }

        UserSettings userSettings = null;
        if (Objects.nonNull(userDto.getUserSettings()) && !NullChecker.allNull(userDto.getUserSettings())) {
            userSettings = assignUserSettingsToUser(user, userDto);
        } else {
            userSettingsRepository.deleteUserByUserId(user_id.toString());
        }

        String encryptedPassword = null;
        if (StringUtils.isNotBlank(userDto.getPassword()) && !isUpdateFromLoginFlow) {
            encryptedPassword = passwordEncoder.encode(userDto.getPassword());
        } else {
            encryptedPassword = user.getPassword();
        }
        userDto.setPassword(encryptedPassword);

        user = dtoToUser(userDto);

        addNewUserExtendsToUser(userDto, user);

        user.setPassword(encryptedPassword);
        user.setId(user_id);

        User updatedUser = userRepository.save(user);
        UserSettings usettings = null;
        UserDetailsEntity userDetails = null;

        if (ude != null) {
            userDetails = userDetailsRepository.save(ude);
        }

        if (userSettings != null) {
            usettings = userSettingsRepository.save(userSettings);
        }


        UserDetailsDto dto = userDetailsToDto(userDetails);
        UserSettingsDto userSettingsDto = userSettingsToDto(usettings);
        UserDto userDto2 = this.userToDto(updatedUser);
        userDto2.setUserExtends(userDto.getUserExtends());
        userDto2.setUserDetails(dto);
        userDto2.setUserSettings(userSettingsDto);
        return userDto2;
    }

    private UserDetailsEntity getUserDetails(UserDto userDto, User user) {
        UserDetailsEntity entity = dtoToUserDetails(userDto.getUserDetails());
        return entity;
    }

    private UserDetailsDto userDetailsToDto(UserDetailsEntity userDetails) {
        return userDetails != null ? modelMapper.map(userDetails, UserDetailsDto.class) : null;
    }

    private UserSettingsDto userSettingsToDto(UserSettings userSettings) {
        return userSettings != null ? modelMapper.map(userSettings, UserSettingsDto.class) : null;
    }

    private void addNewUserExtendsToUser(UserDto userDto, User user) {
        Map<String, String> mapUserExtends = userDto.getUserExtends();
        if (mapUserExtends != null) {
            addExtendsFieldsToUser(user, mapUserExtends);
        }
    }

    private UserDetailsEntity assignUserDetailsToUser(User user, UserDto userDto) {
        UserDetailsEntity userDetailsEntity = new UserDetailsEntity();
        UserDetailsDto userDetailsDto = userDto.getUserDetails();

        Optional<UserDetailsEntity> optionalUserDetailsEntity = userDetailsRepository.getUserDetailsEntitiesByUser(user);
        UUID userDetailsId = null;
        if (optionalUserDetailsEntity.isPresent()) {
            userDetailsEntity = optionalUserDetailsEntity.get();
            userDetailsId = userDetailsEntity.getId();
            userDetailsEntity = this.modelMapper.map(userDetailsDto, UserDetailsEntity.class);
        } else {
            userDetailsEntity = dtoToUserDetails(userDetailsDto);
        }
        userDetailsEntity.setId(userDetailsId);
        userDetailsEntity.setUser(user);

        return userDetailsEntity;
    }

    private UserSettings assignUserSettingsToUser(User user, UserDto userDto) {
        UserSettings userSettings = new UserSettings();
        UserSettingsDto userSettingsDto = userDto.getUserSettings();

        Optional<UserSettings> optionalSettings = userSettingsRepository.getUserSettingsByUserHeader(user);
        UUID userSettingsId = null;
        if (optionalSettings.isPresent()) {
            userSettings = optionalSettings.get();
            userSettingsId = userSettings.getId();
            userSettings = this.modelMapper.map(userSettingsDto, UserSettings.class);
        } else {
            userSettings = dtoToUserSettings(userSettingsDto);
        }
        userSettings.setId(userSettingsId);
        userSettings.setUserHeader(user);

        return userSettings;
    }

    @Override
    public UserDetails loginUser(LoginRequest loginRequest) {
        Optional<User> optionalUserWithEmail = userRepository.findUserByUsername(loginRequest.getUsername());
        User emailUser = null;
        if (optionalUserWithEmail.isPresent()) {
            emailUser = optionalUserWithEmail.get();
            if (passwordAuthentication.authenticate(loginRequest.getPassword().toCharArray(), emailUser.getPassword())) {
                return new org.springframework.security.core.userdetails.User(emailUser.getEmail(), emailUser.getPassword(), Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")));
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    @Override
    public UserDto findUserByEmail(String email) {
        Optional<User> optionalUser = userRepository.findUserByEmail(email);
        UserDto userDto = null;
        if (optionalUser.isPresent()) {
            userDto = this.modelMapper.map(optionalUser.get(), UserDto.class);
        }
        return userDto;
    }

    @Override
    public UserDto findUserByUsername(String username) {
        Optional<User> optionalUser = userRepository.findUserByUsername(username);
        if (optionalUser.isEmpty()) {
            throw new CommonErrorException(Errors.USER_NOT_FOUND);
        }
        UserDto userDto = null;
        if (optionalUser.isPresent()) {
            userDto = this.modelMapper.map(optionalUser.get(), UserDto.class);
            UserDetailsEntity userDetailsEntity = null;
            List<UserExtends> lstUserExtends = userExtendsRepository.findUserExtendsByUser(optionalUser.get());
            if (lstUserExtends != null && !lstUserExtends.isEmpty()) {
                userDto.setUserExtends(lstUserExtends.stream()
                        .collect(Collectors.toMap(UserExtends::getColumn, UserExtends::getValue)));
            }
        }
        return userDto;
    }

    @Override
    public UserDetails loginUserWithJWT(LoginRequest loginRequest) {
        String password = loginRequest.getPassword();
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), password);
        authManager.authenticate(usernamePasswordAuthenticationToken);
        return null;
    }

    @Override
    public Map<String, String> generateOtp(String username, String email) {
        Optional<User> optionalUser = userRepository.findUserByUsernameAndEmail(username, email);
        if (optionalUser.isEmpty()) {
            throw new CommonErrorException(Errors.USER_NOT_FOUND_AGAINST_COMBINATION);
        }

        User user = optionalUser.get();
        OTPNotification request = new OTPNotification();
        request.setUserId(user.getId().toString());
        request.setMobile(user.getMobile());
        String transactionCode = generateTransactionCode();
        request.setTransactionCode(transactionCode);

//        String transactionCode = otpFeignClient.generateOTP(request);
        sendOTPOnKafka(request);

        Map<String, String> responseMap = new HashMap<>();
        responseMap.put("user_id", optionalUser.get().getId().toString());
        responseMap.put("transaction_code", transactionCode);

        return responseMap;
    }

    private String generateTransactionCode() {
        int n = 6;
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {
            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());
            sb.append(AlphaNumericString
                    .charAt(index));
        }
        return sb.toString();
    }

    @Override
    public boolean verifyOTP(VerifyOTPRequest verifyOTPRequest) {
        Optional<User> optionalUser = userRepository.findById(UUID.fromString(verifyOTPRequest.getUserId()));
        if (optionalUser.isEmpty()) {
            throw new CommonErrorException(Errors.USER_NOT_FOUND_AGAINST_COMBINATION);
        }

        User user = optionalUser.get();
        Map<String, String> verifyOtpResponse = otpFeignClient.verifyOtp(verifyOTPRequest);
        boolean isOTPVerified = Boolean.valueOf(verifyOtpResponse.get("isValidOTP"));
        if (!isOTPVerified) {
            throw new CommonErrorException(Errors.OTP_NOT_VALID);
        }
        return true;
    }

    @Override
    @Transactional
    public String resetPassword(ResetPasswordRequest resetPasswordRequest) {
        if (!StringUtils.equals(resetPasswordRequest.getPassword(), resetPasswordRequest.getConfirmPassword())) {
            throw new CommonErrorException(Errors.PASSWORD_NOT_MATCHED);
        }
        UserDto userDto = this.getOneUser(UUID.fromString(resetPasswordRequest.getUserId()));
        User user = null;
        if (Objects.isNull(userDto)) {
            throw new CommonErrorException(Errors.USER_NOT_FOUND);
        }
        user = this.modelMapper.map(userDto, User.class);

        user.setPassword(passwordEncoder.encode(resetPasswordRequest.getPassword()));
        user.setPasswordChanged(true);

        User user1 = userRepository.save(user);
        UserDto userDto1 = userToDto(user1);
        sendPasswordResetMessageOnKafka(userDto1);

        return "Password updated successfully.";

    }

    private void sendPasswordResetMessageOnKafka(UserDto userDto) {
        sendMessageOnKafka(userDto, "password-reset");
    }

    @Override
    public UserProjectResponse getUserProjects(String userId) {
        UserProjectResponse userProjectResponse = null;
        userProjectResponse = projectFeignClient.getUserProjects(userId);
        log.info("Body {} ", userProjectResponse);
        return userProjectResponse;
    }

    @Override
    public AccessPermission getPermissionsForUser(UUID userId) {
        AccessPermission accessPermission = new AccessPermission();
        accessPermission.setPermissions(accessFeignClient.getUserRolePermissions(userId));
        return accessPermission;
    }

    @Override
    public void updateUserDirectReport(UUID userId, String directReportUserId) {
        userRepository.updateUserDirectReport(directReportUserId, userId);
    }

    public User dtoToUser(UserDto userDto) {
        User user = this.modelMapper.map(userDto, User.class);
        return user;
    }

    public UserDto userToDto(User user) {
        UserDto userDto = this.modelMapper.map(user, UserDto.class);
        return userDto;
    }

    private UserDetailsEntity dtoToUserDetails(UserDetailsDto userDetailsDto) {
        return modelMapper.map(userDetailsDto, UserDetailsEntity.class);
    }

    private UserSettings dtoToUserSettings(UserSettingsDto userSettingsDto) {
        return modelMapper.map(userSettingsDto, UserSettings.class);
    }

}
