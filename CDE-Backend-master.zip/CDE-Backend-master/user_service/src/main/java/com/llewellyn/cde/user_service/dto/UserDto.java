package com.llewellyn.cde.user_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.llewellyn.cde.user_service.model.UserDetailsEntity;
import com.llewellyn.cde.user_service.model.UserExtends;
import lombok.Data;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
public class UserDto {
    private UUID id;
    private String email;
    private String username;
    private String firstname;
    private String lastname;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;
    private Date dob;
    private String gender;
    private Boolean isActive;
    private Integer fails;
    private Instant locked;
    private String mobile;
    private boolean isPasswordChanged;
    private UserDetailsDto userDetails;
    private Map<String, String> userExtends;
    private UserSettingsDto userSettings;
    private String directReport;
}
