package com.llewellyn.cde.user_service.feign;

import com.llewellyn.cde.user_service.config.ProjectServiceFallback;
import com.llewellyn.cde.user_service.feign.pojo.UserProjectResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public class ProjectFeignClient {
    @FeignClient(value = "project-service", name = "project-service", fallback = ProjectServiceFallback.class)
    public interface ProjectClient {
        @GetMapping("api/v1/project/user/{userId}")
        UserProjectResponse getUserProjects(@PathVariable("userId") String userId);
    }

}
