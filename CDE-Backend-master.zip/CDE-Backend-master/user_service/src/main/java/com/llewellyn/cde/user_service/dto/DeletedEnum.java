package com.llewellyn.cde.user_service.dto;

public enum DeletedEnum {
    ZERO(0), ONE(1);

    public final int Value;

    DeletedEnum(int i) {
        Value = i;
    }
}
