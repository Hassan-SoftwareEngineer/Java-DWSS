package com.llewellyn.cde.user_service.feign.pojo;

import lombok.Data;

import java.util.List;

@Data
public class AccessPermission {
    List<PermissionDto> permissions;
}
