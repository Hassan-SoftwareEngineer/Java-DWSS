package com.llewellyn.cde.user_service.controller.pojo;

import lombok.Data;

@Data
public class VerifyOTPRequest {
    private String transactionCode;
    private String otpCode;
    private String userId;
}
