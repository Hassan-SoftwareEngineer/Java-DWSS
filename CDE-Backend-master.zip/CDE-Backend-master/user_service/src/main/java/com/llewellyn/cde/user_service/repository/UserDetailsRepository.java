package com.llewellyn.cde.user_service.repository;

import com.llewellyn.cde.user_service.model.User;
import com.llewellyn.cde.user_service.model.UserDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

public interface UserDetailsRepository extends JpaRepository<UserDetailsEntity, UUID> {
    Optional<UserDetailsEntity> getUserDetailsEntitiesByUser(User user);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "delete from user_details where user_id=:userId")
    void deleteUserDetailsEntitiesByUser(@Param("userId") String userId);
}
