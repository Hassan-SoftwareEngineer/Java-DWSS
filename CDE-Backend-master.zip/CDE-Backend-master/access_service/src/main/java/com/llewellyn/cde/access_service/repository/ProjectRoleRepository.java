package com.llewellyn.cde.access_service.repository;

import com.llewellyn.cde.access_service.model.ProjectRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ProjectRoleRepository extends JpaRepository<ProjectRole, UUID> {

    List<ProjectRole> findAllByProjectId(UUID projectId);
}
