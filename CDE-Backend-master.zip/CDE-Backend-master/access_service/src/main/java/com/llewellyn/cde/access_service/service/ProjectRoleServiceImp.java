package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.ProjectRoleDto;
import com.llewellyn.cde.access_service.exception.Errors;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.repository.ProjectRoleRepository;
import com.llewellyn.cde.access_service.repository.RoleRepository;
import com.llewellyn.cde.commons.exception.CommonErrorException;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class ProjectRoleServiceImp implements ProjectRoleService {

    @Autowired
    private ProjectRoleRepository projectRoleRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public ProjectRoleDto createNewProjectRole(UUID projectId, UUID roleId) {
        // TODO Auto-generated method stub
        log.info("Create New Project Role");

        Optional<Role> optionalRole = roleRepository.findById(roleId);
        if (optionalRole.isEmpty()) {
            throw new CommonErrorException(Errors.ROLE_NOT_FOUND);
        }
        ProjectRole projectRole = new ProjectRole();
        projectRole.setProjectId(projectId);
        projectRole.setRoleName(optionalRole.get().getRoleName());
        ProjectRole newProjectRole = projectRoleRepository.save(projectRole);
        return projectRoleToDto(newProjectRole);
    }

    @Override
    public List<ProjectRoleDto> getAllProjectRoleByProject(UUID projectId) {
        // TODO Auto-generated method stub
        log.info("Get All Project Roles by Project ID {}", projectId);

        List<ProjectRole> projectRoles = projectRoleRepository.findAllByProjectId(projectId);

        return projectRoles.stream().map(this::projectRoleToDto).collect(Collectors.toList());
    }

    @Override
    public ProjectRole getOneProjectRole(UUID projectRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One Project Roles by ID {}", projectRoleId);

        Optional<ProjectRole> projectRoleOptional = projectRoleRepository.findById(projectRoleId);
        if (!projectRoleOptional.isPresent()) {

        }
        return projectRoleOptional.get();
    }

    @Override
    public ProjectRoleDto getOneProjectRoleDto(UUID projectRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One Project Role DTO by ID {}", projectRoleId);

        Optional<ProjectRole> projectRoleOptional = projectRoleRepository.findById(projectRoleId);
        if (!projectRoleOptional.isPresent()) {

        }
        return projectRoleToDto(projectRoleOptional.get());
    }

    @Override
    public ProjectRoleDto addPermissionToProjectRole(UUID projectRoleId, Permission permission) {
        // TODO Auto-generated method stub
        log.info("Add Permission {} to Project Role ID {}", permission.getFunctionKey(), projectRoleId);

        ProjectRole projectRole = this.getOneProjectRole(projectRoleId);

        projectRole.getPermissions().add(permission);
        ProjectRole updatedProjectRole = projectRoleRepository.save(projectRole);

        return projectRoleToDto(updatedProjectRole);
    }

    @Override
    public ProjectRoleDto removePermissionToProjectRole(UUID projectRoleId, Permission permission) {
        // TODO Auto-generated method stub
        log.info("Remove Permission {} to Project Role ID {}", permission.getFunctionKey(), projectRoleId);

        ProjectRole projectRole = this.getOneProjectRole(projectRoleId);

        Iterator<Permission> permissions = projectRole.getPermissions().iterator();
        while (permissions.hasNext()) {
            Permission currentItem = permissions.next();
            if (currentItem.equals(permission)) {
                projectRole.removePermission(currentItem);
            }
        }

        return projectRoleToDto(projectRole);
    }

    @Override
    public List<PermissionDto> getProjectRolePermissions(UUID projectId) {
        List<ProjectRole> lstProjectRole = projectRoleRepository.findAllByProjectId(projectId);
        Set<Set<Permission>> setPermission = new HashSet<>();
        lstProjectRole.stream().forEach(pr -> {
            setPermission.add(pr.getPermissions());
        });

        Set<Permission> flatPermissionSet = setPermission.stream().flatMap(Set::stream).collect(Collectors.toSet());

        if (flatPermissionSet.isEmpty()) {
            return null;
        }

        List<PermissionDto> lstPermissionDto = new ArrayList<>();
        flatPermissionSet.forEach(permission -> {
            lstPermissionDto.add(this.modelMapper.map(permission, PermissionDto.class));
        });

        return lstPermissionDto;

    }

    @Override
    public boolean deleteProjectRole(UUID projectRoleId) {
        // TODO Auto-generated method stub
        log.info("Delete One Project Roles by ID {}", projectRoleId);

        ProjectRole projectRole = this.getOneProjectRole(projectRoleId);

        Iterator<Permission> permissions = projectRole.getPermissions().iterator();
        while (permissions.hasNext()) {
            projectRole.removePermission(permissions.next());
        }

        projectRoleRepository.delete(projectRole);

        return true;
    }

    public ProjectRole dtoToProjectRole(ProjectRoleDto projectRoleDto) {
        ProjectRole projectRole = modelMapper.map(projectRoleDto, ProjectRole.class);
        return projectRole;
    }

    public ProjectRoleDto projectRoleToDto(ProjectRole projectRole) {
        ProjectRoleDto projectRoleDto = modelMapper.map(projectRole, ProjectRoleDto.class);
        return projectRoleDto;
    }

}
