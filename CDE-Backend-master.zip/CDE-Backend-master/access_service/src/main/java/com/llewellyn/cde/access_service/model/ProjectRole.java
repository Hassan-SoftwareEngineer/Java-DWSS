package com.llewellyn.cde.access_service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "cde_project_role")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectRole {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "project_role_id")
    private UUID projectRoleId;

    @Column(name = "role_name")
    private String roleName;

    @Column(name = "project_id")
    @Type(type = "uuid-char")
    private UUID projectId;

    @OneToMany(mappedBy = "projectRole", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<UserProjectRole> userProjectRoles;

    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "cde_project_role_permission", joinColumns = {
            @JoinColumn(name = "project_role_id", referencedColumnName = "project_role_id", nullable = false, updatable = false)}, inverseJoinColumns = {
            @JoinColumn(name = "permission_id", referencedColumnName = "permission_id", nullable = false, updatable = false)})
    private Set<Permission> permissions = new HashSet<>();

    public void addUserProjectRole(UserProjectRole userProjectRole) {
        userProjectRoles.add(userProjectRole);
        userProjectRole.setProjectRole(this);
    }

    public void removeUserProjectRole(UserProjectRole userProjectRole) {
        userProjectRoles.remove(userProjectRole);
        userProjectRole.setProjectRole(null);
    }

    public void addPermission(Permission permission) {
        permissions.add(permission);
        permission.getProjectRoles().add(this);
    }

    public void removePermission(Permission permission) {
        permissions.remove(permission);
        permission.getProjectRoles().remove(this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (!(o instanceof ProjectRole))
            return false;

        return projectRoleId != null && projectRoleId.equals(((ProjectRole) o).getProjectRoleId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
