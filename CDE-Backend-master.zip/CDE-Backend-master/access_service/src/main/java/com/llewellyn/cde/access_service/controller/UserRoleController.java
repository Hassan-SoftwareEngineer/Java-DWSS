package com.llewellyn.cde.access_service.controller;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.UserRoleDto;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.service.RoleServiceImp;
import com.llewellyn.cde.access_service.service.UserProjectRoleService;
import com.llewellyn.cde.access_service.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1/access")
public class UserRoleController {

    @Autowired
    private UserRoleService userRoleServiceImp;

    @Autowired
    private UserProjectRoleService userProjectRoleServiceImp;

    @Autowired
    private RoleServiceImp roleServiceImp;

    @PostMapping("/role/{roleId}/user/{userId}/add")
    public ResponseEntity<UserRoleDto> createNewUserRole(@PathVariable UUID roleId,
            @PathVariable UUID userId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        UserRoleDto newUserRoleDto = userRoleServiceImp.createNewUserRole(roleId, userId);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/role/{roleId}/user/{userId}")
                .buildAndExpand(roleId, newUserRoleDto.getUserRoleId()).toUri();

        return ResponseEntity.created(locationUri).body(newUserRoleDto);
    }

    @GetMapping("/role/{role_id}/users")
    public ResponseEntity<List<UserRoleDto>> getAllUserRoleByRole(@PathVariable UUID role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        Role role = roleServiceImp.getOneRole(role_id);

        List<UserRoleDto> userRoleDtos = userRoleServiceImp.getAllUsersByRole(role);

        return ResponseEntity.ok(userRoleDtos);
    }

    @PostMapping("/role/{role_id}/user/{user_role_id}/remove")
    public ResponseEntity<Object> deleteOneUserRole(@PathVariable UUID role_id, @PathVariable UUID user_role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = userRoleServiceImp.deleteOneUserRole(user_role_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/user/{user_id}")
    public ResponseEntity<Object> deleteOneUserRole(@PathVariable UUID user_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = userRoleServiceImp.deleteUserRolesByUser(user_id);
        boolean deleteResult2 = userProjectRoleServiceImp.deleteUserProjectRolesByUser(user_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult && deleteResult2);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/userrole/permission/user/{userId}")
    public ResponseEntity<?> getUserRolePermissions(@PathVariable UUID userId) {
        List<PermissionDto> lstPermissionDto = userRoleServiceImp.getUserRolePermissions(userId);
        // if (lstPermissionDto == null || lstPermissionDto.isEmpty()) {
        // return new ResponseEntity<>("No permssions are assigned to this user",
        // HttpStatus.NOT_FOUND);
        // } else {
        // Map<String, Object> response = new HashMap<>();
        // response.put("permissions", lstPermissionDto);
        // return ResponseEntity.ok(response);
        // }
        Map<String, Object> response = new HashMap<>();
        response.put("permissions", lstPermissionDto);
        return ResponseEntity.ok(response);
    }
}
