package com.llewellyn.cde.access_service.controller;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.service.PermissionServiceImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/api/v1/access")
public class PermissionController {

    @Autowired
    private PermissionServiceImp permissionServiceImp;

    @PostMapping("/permission")
    public ResponseEntity<PermissionDto> createNewPermission(@RequestBody PermissionDto permissionDto) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        PermissionDto newPermission = permissionServiceImp.createNewPermission(permissionDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("permission/{permission_id}")
                .buildAndExpand(newPermission.getPermissionId()).toUri();

        return ResponseEntity.created(locationUri).body(newPermission);
    }

    @GetMapping("/permissions/{permission_type}")
    public ResponseEntity<List<PermissionDto>> getPermissionListByType(@PathVariable String permission_type) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        List<PermissionDto> permissionDtos = permissionServiceImp.getAllPermissionDtosByPermissionType(permission_type);

        return ResponseEntity.ok(permissionDtos);
    }

    @DeleteMapping("/permission/{function_key}")
    public ResponseEntity<Object> deleteByFunctionKey(@PathVariable String function_key) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = permissionServiceImp.deletePermissionByFunctionKey(function_key);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

}
