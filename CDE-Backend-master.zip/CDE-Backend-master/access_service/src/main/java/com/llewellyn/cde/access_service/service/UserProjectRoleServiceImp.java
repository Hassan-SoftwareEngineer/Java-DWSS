package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.UserProjectRoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.model.UserProjectRole;
import com.llewellyn.cde.access_service.repository.UserProjectRoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class UserProjectRoleServiceImp implements UserProjectRoleService {

    @Autowired
    private UserProjectRoleRepository userProjectRoleRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public UserProjectRoleDto createNewUserProjectRole(ProjectRole projectRole, UUID userId) {
        // TODO Auto-generated method stub
        log.info("Create New User Project Role");

        UserProjectRole userProjectRole = new UserProjectRole();
        userProjectRole.setProjectId(projectRole.getProjectId());
        userProjectRole.setUserId(userId);
        userProjectRole.setProjectRole(projectRole);
        UserProjectRole newUserProjectRole = userProjectRoleRepository.save(userProjectRole);
        return userProjectRoleToDto(newUserProjectRole);
    }

    @Override
    public List<UserProjectRoleDto> getAllUsersByProjectRole(ProjectRole projectRole) {
        // TODO Auto-generated method stub
        log.info("Get All Users by Project Role Name {}", projectRole.getRoleName());

        List<UserProjectRole> userProjectRoles = userProjectRoleRepository.findAllByProjectRole(projectRole);
        return userProjectRoles.stream().map(this::userProjectRoleToDto).collect(Collectors.toList());
    }

    @Override
    public UserProjectRoleDto getOneUserProjectRoleDto(UUID userProjectRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One User Project Role Dto by ID {}", userProjectRoleId);

        Optional<UserProjectRole> userProjectRoleOptional = userProjectRoleRepository.findById(userProjectRoleId);
        if (!userProjectRoleOptional.isPresent()) {

        }
        return userProjectRoleToDto(userProjectRoleOptional.get());
    }

    @Override
    public UserProjectRole getOneUserProjectRole(UUID userProjectRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One User Project Role by ID {}", userProjectRoleId);

        Optional<UserProjectRole> userProjectRoleOptional = userProjectRoleRepository.findById(userProjectRoleId);
        if (!userProjectRoleOptional.isPresent()) {

        }
        return userProjectRoleOptional.get();
    }

    @Override
    public boolean deleteOneUserProjectRole(UUID userProjectRoleId) {
        // TODO Auto-generated method stub
        log.info("Delete One User Project Role by ID {}", userProjectRoleId);

        userProjectRoleRepository.deleteById(userProjectRoleId);

        return true;
    }

    @Override
    public boolean deleteUserProjectRolesByUser(UUID userId) {
        // TODO Auto-generated method stub
        log.info("Delete All User Roles by User ID {}", userId);

        long deleteResult = userProjectRoleRepository.deleteByUserId(userId);

        return (deleteResult >= 0);
    }

    @Override
    public boolean deleteUserProjectRolesByProject(UUID projectId) {
        // TODO Auto-generated method stub
        log.info("Delete All User Roles by Project ID {}", projectId);

        long deleteResult = userProjectRoleRepository.deleteByProjectId(projectId);

        return (deleteResult >= 0);
    }

    @Override
    public List<PermissionDto> getPermissionsAgainstUser(UUID userId) {
        List<UserProjectRole> lstUserProjectRole = userProjectRoleRepository.findByUserId(userId);
        Set<Set<Permission>> lstSetPermissions = new HashSet<>();
        lstUserProjectRole.stream().forEach(upr -> {
            lstSetPermissions.add(upr.getProjectRole().getPermissions());
        });

        Set<Permission> lstPermission = lstSetPermissions.stream().flatMap(Set::stream).collect(Collectors.toSet());

        if (lstPermission.isEmpty()) {
            return null;
        }

        List<PermissionDto> lstPermissionDto = new ArrayList<>();
        lstPermission.forEach(permission -> {
            lstPermissionDto.add(this.modelMapper.map(permission, PermissionDto.class));
        });

        return lstPermissionDto;
    }

    @Override
    public List<PermissionDto> getPermissionsAgainstProject(UUID projectId) {
        List<UserProjectRole> lstUserProjectRole = userProjectRoleRepository.findByProjectId(projectId);
        Set<Set<Permission>> lstSetPermissions = new HashSet<>();
        lstUserProjectRole.stream().forEach(upr -> {
            lstSetPermissions.add(upr.getProjectRole().getPermissions());
        });

        Set<Permission> lstPermission = lstSetPermissions.stream().flatMap(Set::stream).collect(Collectors.toSet());

        if (lstPermission.isEmpty()) {
            return null;
        }

        List<PermissionDto> lstPermissionDto = new ArrayList<>();
        lstPermission.forEach(permission -> {
            lstPermissionDto.add(this.modelMapper.map(permission, PermissionDto.class));
        });

        return lstPermissionDto;
    }


    @Override
    public List<PermissionDto> getPermissionsAgainstUserAndProject(UUID userId, UUID projectId) {
        List<UserProjectRole> lstUserProjectRole = userProjectRoleRepository.findByUserIdAndProjectId(userId, projectId);
        Set<Set<Permission>> lstSetPermissions = new HashSet<>();
        lstUserProjectRole.stream().forEach(upr -> {
            lstSetPermissions.add(upr.getProjectRole().getPermissions());
        });

        Set<Permission> lstPermission = lstSetPermissions.stream().flatMap(Set::stream).collect(Collectors.toSet());

        if (lstPermission.isEmpty()) {
            return null;
        }

        List<PermissionDto> lstPermissionDto = new ArrayList<>();
        lstPermission.forEach(permission -> {
            lstPermissionDto.add(this.modelMapper.map(permission, PermissionDto.class));
        });

        return lstPermissionDto;
    }

    public UserProjectRoleDto userProjectRoleToDto(UserProjectRole userProjectRole) {
        UserProjectRoleDto userProjectRoleDto = modelMapper.map(userProjectRole, UserProjectRoleDto.class);
        return userProjectRoleDto;
    }

}
