package com.llewellyn.cde.access_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class ProjectRoleDto {
    private UUID projectRoleId;
    private String roleName;
    private UUID projectId;
}
