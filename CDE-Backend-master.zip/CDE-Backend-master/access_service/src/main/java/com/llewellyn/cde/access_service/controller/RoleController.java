package com.llewellyn.cde.access_service.controller;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.RoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.service.PermissionServiceImp;
import com.llewellyn.cde.access_service.service.RoleServiceImp;
import com.llewellyn.cde.access_service.service.UserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1/access")
public class RoleController {

    @Autowired
    private RoleServiceImp roleServiceImp;

    @Autowired
    private PermissionServiceImp permissionServiceImp;
    @Autowired
    private UserRoleService userRoleServiceImp;

    @PostMapping("/role")
    public ResponseEntity<RoleDto> createNewRole(@RequestBody RoleDto roleDto) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        RoleDto newRole = roleServiceImp.createNewRole(roleDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("role/{role_id}")
                .buildAndExpand(newRole.getRoleId()).toUri();

        return ResponseEntity.created(locationUri).body(newRole);
    }

    @GetMapping("/roles")
    public ResponseEntity<List<RoleDto>> getRoleList() {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        List<RoleDto> roleDtos = roleServiceImp.getAllGlobalRole();

        return ResponseEntity.ok(roleDtos);
    }

    @GetMapping("/role/{role_id}")
    public ResponseEntity<RoleDto> getRole(@PathVariable UUID role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        RoleDto roleDto = roleServiceImp.getOneRoleDto(role_id);

        return ResponseEntity.ok(roleDto);
    }

    @PostMapping("/role/{role_id}/permission/{permission_id}/add")
    public ResponseEntity<RoleDto> addPermissionOnRole(@PathVariable UUID role_id,
                                                       @PathVariable UUID permission_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

//        Permission permission = permissionServiceImp.getOnePermissionByFunctionKey(permissionDto.getFunctionKey());
        PermissionDto permissionDto = permissionServiceImp.getPermissionById(permission_id);

        RoleDto roleDto = roleServiceImp.addPermissionToRole(role_id, permissionDto);

        return ResponseEntity.ok(roleDto);
    }

    @PostMapping("/role/{role_id}/permission/{permission_id}/remove")
    public ResponseEntity<RoleDto> removePermissionOnRole(@PathVariable UUID role_id,
                                                          @RequestBody PermissionDto permissionDto) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        Permission permission = permissionServiceImp.getOnePermissionByFunctionKey(permissionDto.getFunctionKey());

        RoleDto roleDto = roleServiceImp.removePermissionToRole(role_id, permission);

        return ResponseEntity.ok(roleDto);
    }

    @DeleteMapping("/role/{role_id}")
    public ResponseEntity<Object> deleteRole(@PathVariable UUID role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = roleServiceImp.deleteRole(role_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }
}
