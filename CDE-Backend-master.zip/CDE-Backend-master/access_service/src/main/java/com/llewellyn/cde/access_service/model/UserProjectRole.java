package com.llewellyn.cde.access_service.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "cde_user_project_role")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "projectRole")
@EqualsAndHashCode(exclude = "projectRole")

public class UserProjectRole {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "user_project_role_id")
    private UUID userProjectRoleId;

    @Column(name = "user_id")
    @Type(type = "uuid-char")
    private UUID userId;

    @Column(name = "project_id")
    @Type(type = "uuid-char")
    private UUID projectId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "project_role_id", nullable = false)
    private ProjectRole projectRole;

}
