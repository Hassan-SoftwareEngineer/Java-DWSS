package com.llewellyn.cde.access_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class PermissionDto {

    private UUID permissionId;
    private String functionKey;
    private String permissionType;

}
