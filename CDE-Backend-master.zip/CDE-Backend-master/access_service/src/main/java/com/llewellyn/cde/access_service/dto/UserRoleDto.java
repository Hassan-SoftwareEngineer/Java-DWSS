package com.llewellyn.cde.access_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class UserRoleDto {
    private UUID userRoleId;
    private UUID userId;
    private RoleDto role;
}
