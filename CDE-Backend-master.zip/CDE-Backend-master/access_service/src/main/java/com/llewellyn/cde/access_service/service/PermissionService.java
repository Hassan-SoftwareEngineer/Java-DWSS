package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.model.Permission;

import java.util.List;
import java.util.UUID;

public interface PermissionService {

    PermissionDto createNewPermission(PermissionDto permission);

    List<PermissionDto> getAllPermissionDtosByPermissionType(String type);

    PermissionDto getOnePermissionDtoByFunctionKey(String functionKey);

    Permission getOnePermission(UUID permissionId);

    Permission getOnePermissionByFunctionKey(String functionKey);

    boolean deletePermission(UUID permissionId);

    boolean deletePermissionByFunctionKey(String functionKey);

    PermissionDto getPermissionById(UUID permissionId);
}
