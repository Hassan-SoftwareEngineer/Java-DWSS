package com.llewellyn.cde.access_service.repository;

import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.model.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface UserRoleRepository extends JpaRepository<UserRole, UUID> {

    List<UserRole> findAllByRole(Role role);

    Long deleteByUserId(UUID userId);

    Long deleteByRole(Role role);

    List<UserRole> findAllByUserId(UUID userId);
}
