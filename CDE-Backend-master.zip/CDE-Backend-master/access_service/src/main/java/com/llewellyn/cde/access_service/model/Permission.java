package com.llewellyn.cde.access_service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "cde_permission")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Permission {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "permission_id")
    private UUID permissionId;

    @NaturalId
    @Column(name = "function_key", nullable = false)
    private String functionKey;

    @Column(name = "permission_type", nullable = false)
    private String permissionType;

    @ManyToMany(mappedBy = "permissions", fetch = FetchType.LAZY)
    private Set<Role> roles = new HashSet<>();

    @ManyToMany(mappedBy = "permissions", fetch = FetchType.LAZY)
    private Set<ProjectRole> projectRoles = new HashSet<>();

    public void removeProjectRolePermission(ProjectRole projectRole) {
        projectRoles.remove(projectRole);
        projectRole.getPermissions().remove(this);
    }

    public void removeRolePermission(Role role) {
        roles.remove(role);
        role.getPermissions().remove(this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (!(o instanceof Permission))
            return false;

        Permission permission = (Permission) o;
        return Objects.equals(functionKey, permission.functionKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(functionKey);
    }
}
