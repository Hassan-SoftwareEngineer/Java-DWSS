package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.UserRoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.model.UserRole;
import com.llewellyn.cde.access_service.repository.UserRoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class UserRoleServiceImp implements UserRoleService {

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private RoleService roleService;

    @Autowired
    private PermissionService permissionService;

    @Override
    public UserRoleDto createNewUserRole(UUID roleId, UUID userId) {
        // TODO Auto-generated method stub
        log.info("Create New User Role");

        Role role = roleService.getOneRole(roleId);

        UserRole userRole = new UserRole();
        userRole.setRole(role);
        userRole.setUserId(userId);
        UserRole newUserRole = userRoleRepository.save(userRole);
        return userRoleToDto(newUserRole);
    }

    @Override
    public List<UserRoleDto> getAllUsersByRole(Role role) {
        // TODO Auto-generated method stub
        log.info("Get All Users by Role Name {}", role.getRoleName());

        List<UserRole> userRoles = userRoleRepository.findAllByRole(role);
        return userRoles.stream().map(this::userRoleToDto).collect(Collectors.toList());
    }

    @Override
    public UserRoleDto getOneUserRoleDto(UUID userRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One User Role Dto by ID {}", userRoleId);

        Optional<UserRole> userRoleOptional = userRoleRepository.findById(userRoleId);
        if (!userRoleOptional.isPresent()) {

        }
        return userRoleToDto(userRoleOptional.get());
    }

    @Override
    public UserRole getOneUserRole(UUID userRoleId) {
        // TODO Auto-generated method stub
        log.info("Get One User Role by ID {}", userRoleId);

        Optional<UserRole> userRoleOptional = userRoleRepository.findById(userRoleId);
        if (!userRoleOptional.isPresent()) {

        }
        return userRoleOptional.get();
    }

    @Override
    public boolean deleteOneUserRole(UUID userRoleId) {
        // TODO Auto-generated method stub
        log.info("Delete One User Role by ID {}", userRoleId);

        userRoleRepository.deleteById(userRoleId);

        return true;
    }

    @Override
    public boolean deleteUserRolesByUser(UUID userId) {
        // TODO Auto-generated method stub
        log.info("Delete All User Roles by User ID {}", userId);

        long deleteResult = userRoleRepository.deleteByUserId(userId);

        return (deleteResult >= 0);
    }

    @Override
    public List<PermissionDto> getUserRolePermissions(UUID userId) {
        List<UserRole> lstUserRole = userRoleRepository.findAllByUserId(userId);
        List<Role> lstRole = new ArrayList<>();
        if (lstUserRole.isEmpty()) {
            return null;
        }

        lstUserRole.stream().forEach(userRole -> {
            lstRole.add(userRole.getRole());
        });

        if (lstRole.isEmpty()) {
            return null;
        }
        Set<Set<Permission>> lstSetPermissions = new HashSet();
        lstRole.forEach(role -> {
            lstSetPermissions.add(role.getPermissions());
        });

        Set<Permission> lstPermission = lstSetPermissions.stream().flatMap(Set::stream).collect(Collectors.toSet());

        if (lstPermission.isEmpty()) {
            return null;
        }

        List<PermissionDto> lstPermissionDto = new ArrayList<>();
        lstPermission.forEach(permission -> {
            lstPermissionDto.add(this.modelMapper.map(permission, PermissionDto.class));
        });

        return lstPermissionDto;
    }

    public UserRole dtoToUserRole(UserRoleDto userRoleDto) {
        UserRole userRole = modelMapper.map(userRoleDto, UserRole.class);
        return userRole;
    }

    public UserRoleDto userRoleToDto(UserRole userRole) {
        UserRoleDto userRoleDto = modelMapper.map(userRole, UserRoleDto.class);
        return userRoleDto;
    }

}
