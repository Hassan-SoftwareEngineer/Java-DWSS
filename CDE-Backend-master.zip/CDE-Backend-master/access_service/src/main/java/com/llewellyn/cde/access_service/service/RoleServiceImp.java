package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.RoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.repository.RoleRepository;
import com.llewellyn.cde.access_service.repository.UserRoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class RoleServiceImp implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public RoleDto createNewRole(RoleDto roleDto) {
        // TODO Auto-generated method stub
        log.info("Create New Role");

        Role role = dtoToRole(roleDto);
        Role newRole = roleRepository.save(role);
        return roleToDto(newRole);
    }

    @Override
    public List<RoleDto> getAllGlobalRole() {
        // TODO Auto-generated method stub
        log.info("Get All Global Roles");

        List<Role> roles = roleRepository.findAll();

        return roles.stream().map(this::roleToDto).collect(Collectors.toList());
    }

    @Override
    public Role getOneRole(UUID roleId) {
        // TODO Auto-generated method stub
        log.info("Get One Global Role by ID {}", roleId);

        Optional<Role> roleOptional = roleRepository.findById(roleId);
        if (!roleOptional.isPresent()) {

        }
        return roleOptional.get();
    }

    @Override
    public RoleDto getOneRoleDto(UUID roleId) {
        // TODO Auto-generated method stub
        log.info("Get One Global Role DTO by ID {}", roleId);

        Optional<Role> roleOptional = roleRepository.findById(roleId);
        if (!roleOptional.isPresent()) {

        }
        return roleToDto(roleOptional.get());
    }

    @Override
    public RoleDto addPermissionToRole(UUID roleId, PermissionDto permissionDto) {
        // TODO Auto-generated method stub
        log.info("Add Permission {} to Role ID {}", permissionDto.getFunctionKey(), roleId);

        Role role = this.getOneRole(roleId);

        role.getPermissions().add(this.modelMapper.map(permissionDto, Permission.class));
        Role updatedRole = roleRepository.save(role);

        return roleToDto(updatedRole);
    }

    @Override
    public RoleDto removePermissionToRole(UUID roleId, Permission permission) {
        // TODO Auto-generated method stub
        log.info("Remove Permission {} to Role ID {}", permission.getFunctionKey(), roleId);

        Role role = this.getOneRole(roleId);
        Iterator<Permission> permissions = role.getPermissions().iterator();
        while (permissions.hasNext()) {
            Permission currentItem = permissions.next();
            if (currentItem.equals(permission)) {
                role.removePermission(currentItem);
            }
        }

        return roleToDto(role);
    }

    @Override
    public boolean deleteRole(UUID roleId) {
        // TODO Auto-generated method stub
        log.info("Delete One Global Roles by ID {}", roleId);

        Role role = this.getOneRole(roleId);

        Iterator<Permission> permissions = role.getPermissions().iterator();
        while (permissions.hasNext()) {
            role.removePermission(permissions.next());
        }

        userRoleRepository.deleteByRole(role);

        roleRepository.delete(role);

        return true;
    }

    public Role dtoToRole(RoleDto roleDto) {
        Role role = modelMapper.map(roleDto, Role.class);
        return role;
    }

    public RoleDto roleToDto(Role role) {
        RoleDto roleDto = modelMapper.map(role, RoleDto.class);
        return roleDto;
    }

}
