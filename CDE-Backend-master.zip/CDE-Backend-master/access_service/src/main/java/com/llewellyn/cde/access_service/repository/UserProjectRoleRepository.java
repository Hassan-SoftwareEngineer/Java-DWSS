package com.llewellyn.cde.access_service.repository;

import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.model.UserProjectRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface UserProjectRoleRepository extends JpaRepository<UserProjectRole, UUID> {

    List<UserProjectRole> findAllByProjectRole(ProjectRole projectRole);

    Long deleteByUserId(UUID userId);

    Long deleteByProjectId(UUID projectId);

    List<UserProjectRole> findByUserId(UUID userId);

    List<UserProjectRole> findByUserIdAndProjectId(UUID userId, UUID projectId);

    List<UserProjectRole> findByProjectId(UUID projectId);
}
