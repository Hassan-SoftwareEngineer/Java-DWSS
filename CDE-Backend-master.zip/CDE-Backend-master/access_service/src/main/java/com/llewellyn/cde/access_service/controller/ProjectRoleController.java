package com.llewellyn.cde.access_service.controller;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.ProjectRoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.service.PermissionServiceImp;
import com.llewellyn.cde.access_service.service.ProjectRoleServiceImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1/access")
public class ProjectRoleController {

    @Autowired
    private ProjectRoleServiceImp projectRoleServiceImp;

    @Autowired
    private PermissionServiceImp permissionServiceImp;

    @PostMapping("/project/{projectId}/role/{roleId}")
    public ResponseEntity<ProjectRoleDto> createNewRole(@PathVariable UUID projectId,
                                                        @PathVariable UUID roleId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectRoleDto newProjectRole = projectRoleServiceImp.createNewProjectRole(projectId, roleId);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("project/{projectId}/role/{project_role_id}")
                .buildAndExpand(projectId, newProjectRole.getProjectRoleId()).toUri();

        return ResponseEntity.created(locationUri).body(newProjectRole);
    }

    @GetMapping("/project/{project_id}/roles")
    public ResponseEntity<List<ProjectRoleDto>> getProjectRoleList(@PathVariable UUID project_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        List<ProjectRoleDto> projectRoleDtos = projectRoleServiceImp.getAllProjectRoleByProject(project_id);

        return ResponseEntity.ok(projectRoleDtos);
    }

    @GetMapping("/project/{project_id}/role/{project_role_id}")
    public ResponseEntity<ProjectRoleDto> getRole(@PathVariable UUID project_id,
                                                  @PathVariable UUID project_role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectRoleDto projectRoleDtos = projectRoleServiceImp.getOneProjectRoleDto(project_role_id);

        return ResponseEntity.ok(projectRoleDtos);
    }

    @PostMapping("/projectrole/{projectRoleId}/permission/{permissionId}/add")
    public ResponseEntity<ProjectRoleDto> addPermissionOnRole(
            @PathVariable UUID projectRoleId,
            @PathVariable UUID permissionId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        Permission permission = permissionServiceImp.getOnePermission(permissionId);

        ProjectRoleDto projectRoleDtos = projectRoleServiceImp.addPermissionToProjectRole(projectRoleId, permission);

        return ResponseEntity.ok(projectRoleDtos);
    }

    @PostMapping("/project/{project_id}/role/{project_role_id}/permission/remove")
    public ResponseEntity<ProjectRoleDto> removePermissionOnRole(@PathVariable UUID project_id,
                                                                 @PathVariable UUID project_role_id,
                                                                 @RequestBody PermissionDto permissionDto) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        Permission permission = permissionServiceImp.getOnePermissionByFunctionKey(permissionDto.getFunctionKey());

        ProjectRoleDto projectRoleDtos = projectRoleServiceImp.removePermissionToProjectRole(project_role_id,
                permission);

        return ResponseEntity.ok(projectRoleDtos);
    }

    @DeleteMapping("/project/{project_id}/role/{project_role_id}")
    public ResponseEntity<Object> deleteRole(@PathVariable UUID project_id, @PathVariable UUID project_role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = projectRoleServiceImp.deleteProjectRole(project_role_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/projectrole/permission/project/{projectId}")
    public ResponseEntity<Object> getPermissionsAgainstProject(@PathVariable UUID projectId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        return new ResponseEntity<>(projectRoleServiceImp.getProjectRolePermissions(projectId), HttpStatus.OK);
    }
}
