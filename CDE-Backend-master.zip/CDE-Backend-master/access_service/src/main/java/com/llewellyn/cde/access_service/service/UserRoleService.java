package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.UserRoleDto;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.model.UserRole;

import java.util.List;
import java.util.UUID;

public interface UserRoleService {

    UserRoleDto createNewUserRole(UUID roleId, UUID userId);

    List<UserRoleDto> getAllUsersByRole(Role role);

    UserRoleDto getOneUserRoleDto(UUID userRoleId);

    UserRole getOneUserRole(UUID userRoleId);

    boolean deleteOneUserRole(UUID userRoleId);

    boolean deleteUserRolesByUser(UUID userId);

    List<PermissionDto> getUserRolePermissions(UUID userId);
}
