package com.llewellyn.cde.access_service.exception;

import com.llewellyn.cde.commons.exception.ErrorPrinter;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

public enum Errors implements ErrorPrinter {

    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "000", null, "internal server error {0}"),

    ROLE_NOT_FOUND(HttpStatus.NOT_FOUND, "404", null, "Role not found");


    private HttpStatus httpStatus;
    private String description;
    private String externalErrorCode;
    private String errorCode;

    private Errors(HttpStatus httpStatus, String errorCode, String externalErrorCode,
                   String description) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.externalErrorCode = externalErrorCode;
        this.description = description;
    }

    public static Errors fromString(String text) {
        for (Errors e : Errors.values()) {
            if (StringUtils.isNotBlank(e.getExternalErrorCode())) {
                if (e.externalErrorCode.equalsIgnoreCase(text)) {
                    return e;
                }
            }
        }
        return null;
    }

    @Override
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getExternalErrorCode() {
        return externalErrorCode;
    }
}