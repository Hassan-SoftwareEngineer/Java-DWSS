package com.llewellyn.cde.access_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class UserProjectRoleDto {
    private UUID userProjectRoleId;
    private UUID userId;
    private UUID projectId;
    private ProjectRoleDto projectRole;
}
