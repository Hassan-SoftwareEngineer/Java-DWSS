package com.llewellyn.cde.access_service.repository;

import com.llewellyn.cde.access_service.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RoleRepository extends JpaRepository<Role, UUID> {

}
