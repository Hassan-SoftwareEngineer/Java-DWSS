package com.llewellyn.cde.access_service.repository;

import com.llewellyn.cde.access_service.model.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface PermissionRepository extends JpaRepository<Permission, UUID> {

    List<Permission> findAllByPermissionType(String permissionType);

    Permission findByFunctionKey(String functionKey);

    Long deleteByFunctionKey(String functionKey);
}
