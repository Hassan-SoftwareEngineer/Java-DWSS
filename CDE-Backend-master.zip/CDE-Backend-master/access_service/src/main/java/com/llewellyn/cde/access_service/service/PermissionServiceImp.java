package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.model.Role;
import com.llewellyn.cde.access_service.repository.PermissionRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class PermissionServiceImp implements PermissionService {

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public PermissionDto createNewPermission(PermissionDto permissionDto) {
        // TODO Auto-generated method stub
        log.info("Create New Permission");

        Permission permission = dtoToPermission(permissionDto);
        Permission newPermission = permissionRepository.save(permission);
        return permissionToDto(newPermission);
    }

    @Override
    public List<PermissionDto> getAllPermissionDtosByPermissionType(String permissionType) {
        // TODO Auto-generated method stub
        log.info("Get All Permissions by Permission Type {}", permissionType);

        List<Permission> permissions = permissionRepository.findAllByPermissionType(permissionType);

        return permissions.stream().map(this::permissionToDto).collect(Collectors.toList());
    }

    @Override
    public PermissionDto getOnePermissionDtoByFunctionKey(String functionKey) {
        // TODO Auto-generated method stub
        log.info("Get One Permission DTO with Function Key {}", functionKey);

        Permission permission = permissionRepository.findByFunctionKey(functionKey);

        return permissionToDto(permission);
    }

    @Override
    public Permission getOnePermission(UUID permissionId) {
        // TODO Auto-generated method stub
        log.info("Get One Permission with ID {}", permissionId);

        Optional<Permission> permissionOptional = permissionRepository.findById(permissionId);
        if (!permissionOptional.isPresent()) {

        }
        return permissionOptional.get();
    }

    @Override
    public Permission getOnePermissionByFunctionKey(String functionKey) {
        // TODO Auto-generated method stub
        log.info("Get One Permission with Function Key {}", functionKey);

        Permission permission = permissionRepository.findByFunctionKey(functionKey);
        return permission;
    }

    @Override
    public boolean deletePermission(UUID permissionId) {
        // TODO Auto-generated method stub
        log.info("Delete One Permission with ID {}", permissionId);

        Permission permission = this.getOnePermission(permissionId);
        Iterator<Role> roles = permission.getRoles().iterator();
        while (roles.hasNext()) {
            permission.removeRolePermission(roles.next());
        }

        Iterator<ProjectRole> projectRoles = permission.getProjectRoles().iterator();
        while (projectRoles.hasNext()) {
            permission.removeProjectRolePermission(projectRoles.next());
        }

        permissionRepository.delete(permission);
        return true;
    }

    @Override
    public boolean deletePermissionByFunctionKey(String functionKey) {
        // TODO Auto-generated method stub
        log.info("Delete One Permission with Function Key {}", functionKey);

        Permission permission = this.getOnePermissionByFunctionKey(functionKey);

        Iterator<Role> roles = permission.getRoles().iterator();
        while (roles.hasNext()) {
            permission.removeRolePermission(roles.next());
        }

        Iterator<ProjectRole> projectRoles = permission.getProjectRoles().iterator();
        while (projectRoles.hasNext()) {
            permission.removeProjectRolePermission(projectRoles.next());
        }

        long deleteResult = permissionRepository.deleteByFunctionKey(functionKey);

        return (deleteResult >= 0);
    }

    @Override
    public PermissionDto getPermissionById(UUID permissionId) {
        Optional<Permission> optionalPermission = permissionRepository.findById(permissionId);
        return optionalPermission.isPresent() ? this.modelMapper.map(optionalPermission.get(), PermissionDto.class) : null;
    }

    public Permission dtoToPermission(PermissionDto permissionDto) {
        Permission permission = modelMapper.map(permissionDto, Permission.class);
        return permission;
    }

    public PermissionDto permissionToDto(Permission permission) {
        PermissionDto permissionDto = modelMapper.map(permission, PermissionDto.class);
        return permissionDto;
    }

}
