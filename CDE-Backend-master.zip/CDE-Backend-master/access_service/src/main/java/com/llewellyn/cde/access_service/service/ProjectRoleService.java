package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.ProjectRoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.ProjectRole;

import java.util.List;
import java.util.UUID;

public interface ProjectRoleService {

    ProjectRoleDto createNewProjectRole(UUID projectId, UUID roleId);

    List<ProjectRoleDto> getAllProjectRoleByProject(UUID projectId);

    ProjectRole getOneProjectRole(UUID projectRoleId);

    ProjectRoleDto getOneProjectRoleDto(UUID projectRoleId);

    ProjectRoleDto addPermissionToProjectRole(UUID projectRoleId, Permission permission);

    ProjectRoleDto removePermissionToProjectRole(UUID projectRoleId, Permission permission);

    boolean deleteProjectRole(UUID projectRoleId);
    List<PermissionDto> getProjectRolePermissions(UUID projectId);

}
