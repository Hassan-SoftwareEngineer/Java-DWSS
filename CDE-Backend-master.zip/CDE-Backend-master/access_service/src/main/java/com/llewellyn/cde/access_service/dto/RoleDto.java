package com.llewellyn.cde.access_service.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class RoleDto {
    private UUID roleId;
    private String roleName;
}
