package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.UserProjectRoleDto;
import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.model.UserProjectRole;

import java.util.List;
import java.util.UUID;

public interface UserProjectRoleService {

    UserProjectRoleDto createNewUserProjectRole(ProjectRole projectRole, UUID userId);

    List<UserProjectRoleDto> getAllUsersByProjectRole(ProjectRole projectRole);

    UserProjectRoleDto getOneUserProjectRoleDto(UUID userProjectRoleId);

    UserProjectRole getOneUserProjectRole(UUID userProjectRoleId);

    boolean deleteOneUserProjectRole(UUID userProjectRoleId);

    boolean deleteUserProjectRolesByUser(UUID userId);

    boolean deleteUserProjectRolesByProject(UUID projectId);

    List<PermissionDto> getPermissionsAgainstUser(UUID userId);

    List<PermissionDto> getPermissionsAgainstProject(UUID projectId);

    List<PermissionDto> getPermissionsAgainstUserAndProject(UUID userId, UUID projectId);
}
