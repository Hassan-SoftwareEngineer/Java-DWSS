package com.llewellyn.cde.access_service.service;

import com.llewellyn.cde.access_service.dto.PermissionDto;
import com.llewellyn.cde.access_service.dto.RoleDto;
import com.llewellyn.cde.access_service.model.Permission;
import com.llewellyn.cde.access_service.model.Role;

import java.util.List;
import java.util.UUID;

public interface RoleService {

    RoleDto createNewRole(RoleDto roleDto);

    List<RoleDto> getAllGlobalRole();

    Role getOneRole(UUID roleId);

    RoleDto getOneRoleDto(UUID roleId);

    RoleDto addPermissionToRole(UUID roleId, PermissionDto permission);

    RoleDto removePermissionToRole(UUID roleId, Permission permission);

    boolean deleteRole(UUID roleId);
}
