package com.llewellyn.cde.access_service.controller;

import com.llewellyn.cde.access_service.dto.UserProjectRoleDto;
import com.llewellyn.cde.access_service.model.ProjectRole;
import com.llewellyn.cde.access_service.service.ProjectRoleServiceImp;
import com.llewellyn.cde.access_service.service.UserProjectRoleServiceImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1/access")
public class UserProjectRoleController {

    @Autowired
    private UserProjectRoleServiceImp userProjectRoleServiceImp;

    @Autowired
    private ProjectRoleServiceImp projectRoleServiceImp;

    @PostMapping("/projectrole/{projectRoleId}/user/{userId}")
    public ResponseEntity<UserProjectRoleDto> createNewUserProjectRole(@PathVariable UUID projectRoleId,
                                                                       @PathVariable UUID userId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectRole projectRole = projectRoleServiceImp.getOneProjectRole(projectRoleId);

        UserProjectRoleDto newUserRoleDto = userProjectRoleServiceImp.createNewUserProjectRole(projectRole,
                userId);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/projectrole/{projectRoleId}/user/{userId}")
                .buildAndExpand(projectRoleId, userId, newUserRoleDto.getUserProjectRoleId()).toUri();

        return ResponseEntity.created(locationUri).body(newUserRoleDto);
    }

    @GetMapping("/project/{project_id}/role/{role_id}/users")
    public ResponseEntity<List<UserProjectRoleDto>> getAllUserProjectRoleByProjectRole(@PathVariable UUID project_id,
                                                                                       @PathVariable UUID role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProjectRole projectRole = projectRoleServiceImp.getOneProjectRole(role_id);

        List<UserProjectRoleDto> userProjectRoleDtos = userProjectRoleServiceImp.getAllUsersByProjectRole(projectRole);

        return ResponseEntity.ok(userProjectRoleDtos);
    }

    @PostMapping("/project/{project_id}/role/{role_id}/user/{user_project_role_id}/remove")
    public ResponseEntity<Object> deleteOneUserProjectRole(@PathVariable UUID project_id,
                                                           @PathVariable UUID role_id, @PathVariable UUID user_project_role_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = userProjectRoleServiceImp.deleteOneUserProjectRole(user_project_role_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/project/{project_id}")
    public ResponseEntity<Object> deleteOneUserRole(@PathVariable UUID project_id) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        boolean deleteResult = userProjectRoleServiceImp.deleteUserProjectRolesByProject(project_id);

        Map<String, Object> response = new HashMap<>();
        response.put("delete_result", deleteResult);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/userprojectrole/permission/user/{userId}")
    public ResponseEntity<Object> getPermissionsAgainstProjectRoleUser(@PathVariable UUID userId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        return new ResponseEntity<>(userProjectRoleServiceImp.getPermissionsAgainstUser(userId), HttpStatus.OK);
    }

    @GetMapping("/userprojectrole/permission/user/{userId}/project/{projectId}")
    public ResponseEntity<Object> getPermissionsAgainstProjectRoleUser(@PathVariable UUID userId, @PathVariable UUID projectId) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        return new ResponseEntity<>(userProjectRoleServiceImp.getPermissionsAgainstUserAndProject(userId, projectId), HttpStatus.OK);
    }
}
