package com.llewellyn.cde.access_service.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "cde_user_role")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "role")
@EqualsAndHashCode(exclude = "role")

public class UserRole {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    @Column(name = "user_role_id")
    private UUID userRoleId;

    @Column(name = "user_id")
    @Type(type = "uuid-char")
    private UUID userId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "role_id", nullable = false)
    private Role role;

}
