package com.llewellyn.cde.access_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
