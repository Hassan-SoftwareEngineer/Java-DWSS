package com.llewellyn.cde.pojo.header;

import java.time.Instant;
import java.util.UUID;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.llewellyn.cde.service.entity.FormStatusEnum;
import com.llewellyn.cde.service.entity.mysql.FormList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormRecordHeaderDto {
    
    private UUID id;

    private FormList formList;

    private String formName;

    private String formType;

    private String formSubType;
    
    private String formSchemaId;
    
    private String formReferenceCode;

    private UUID projectId;

    private String block;

    private String floor;

    private Instant submittedAt;

    private String submittedBy;

    @Enumerated(EnumType.STRING)
    private FormStatusEnum status;
}
