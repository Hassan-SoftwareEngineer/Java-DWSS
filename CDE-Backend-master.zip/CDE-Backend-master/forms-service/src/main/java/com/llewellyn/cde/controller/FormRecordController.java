package com.llewellyn.cde.controller;

import com.llewellyn.cde.config.RequestValuesContainer;
import com.llewellyn.cde.pojo.FormRecordPojo;
import com.llewellyn.cde.pojo.request.ApprovalProcessSubmitDto;
import com.llewellyn.cde.service.FormRecordService;
import com.llewellyn.cde.specification.FilterRequest;
import com.llewellyn.cde.utils.AppConstants;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.UUID;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/form-record")
@Slf4j
public class FormRecordController {

    private final FormRecordService formRecordService;
    private final RequestValuesContainer requestValuesContainer;

    public FormRecordController(FormRecordService formRecordService, RequestValuesContainer requestValuesContainer) {
        this.formRecordService = formRecordService;
        this.requestValuesContainer = requestValuesContainer;
    }

    @PostMapping("/form/{form_schema_id}/submit")
    public ResponseEntity<?> submitFormAnswer(@PathVariable String form_schema_id,
            @Valid @RequestBody FormRecordPojo formRecordPojo,
            @RequestHeader String userId, @RequestHeader String username) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        log.info("Submit Form Record Pojo {} ", formRecordPojo);

        requestValuesContainer.getRequestValues().put("userId", userId);
        requestValuesContainer.getRequestValues().put("username", username);
        log.info("user ID {}", userId);
        return ResponseEntity.ok(formRecordService.submitForm(form_schema_id, formRecordPojo));
    }

    @PostMapping("/form/{form_schema_id}/save")
    public ResponseEntity<?> saveFormAnswer(@PathVariable String form_schema_id,
            @Valid @RequestBody FormRecordPojo formRecordPojo,
            @RequestHeader String userId, @RequestHeader String username) {

        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        log.info("Save Form Record Pojo {} ", formRecordPojo);

        requestValuesContainer.getRequestValues().put("userId", userId);
        requestValuesContainer.getRequestValues().put("username", username);
        log.info("user ID {}", userId);
        return ResponseEntity.ok(formRecordService.saveDraftForm(form_schema_id, formRecordPojo));
    }

    @GetMapping("/schema/{form_schema_id}")
    public ResponseEntity<?> getAnswersByFormSchemaId(@PathVariable String form_schema_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        return ResponseEntity.ok(formRecordService.getAnswersOfForm(form_schema_id));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getAnswersOfUsers(@PathVariable String userId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        return ResponseEntity.ok(formRecordService.getAnswersOfFormAgainstUserId(userId));
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllAnswers() {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        return ResponseEntity.ok(formRecordService.getAllAnswers());
    }

    @DeleteMapping("/{formRecordId}")
    public ResponseEntity<?> deleteFormRecord(@PathVariable String formRecordId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        formRecordService.deleteFormRecord(formRecordId);
        return ResponseEntity.accepted().build();
    }

    @GetMapping("/{formRecordId}")
    public ResponseEntity<?> getFormRecordAgainstId(@PathVariable String formRecordId, @RequestHeader String userId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());
        requestValuesContainer.getRequestValues().put("userId", userId);
        return ResponseEntity.ok(formRecordService.getOneFormRecord(formRecordId));
    }

    @PostMapping("/filter")
    public ResponseEntity<?> getAllFormsByProjectFilter(@RequestBody(required = false) FilterRequest filterRequest,
            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = AppConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = AppConstants.DEFAULT_RECORD_SORT_BY, required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = AppConstants.DEFAULT_SORT_DIRECTION, required = false) String sortDir) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        return ResponseEntity
                .ok(formRecordService.getFilteredFormRecord(filterRequest, pageNo, pageSize, sortBy, sortDir));
    }

    @GetMapping("/approval")
    public ResponseEntity<?> getApprovalFormListByUser(
            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestHeader String userId) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        requestValuesContainer.getRequestValues().put("userId", userId);

        return ResponseEntity.ok(formRecordService.getApprovalFormList(pageNo));
    }

    @PutMapping("/header/{formRecordHeaderId}")
    public ResponseEntity<?> updateFormRecordStatusByReferenceCode(
            @PathVariable UUID formRecordHeaderId, @Valid @RequestBody ApprovalProcessSubmitDto approvalProcessSubmitDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        return ResponseEntity.ok(formRecordService.updateFormStatus(formRecordHeaderId, approvalProcessSubmitDto));
    }
}
