package com.llewellyn.cde.service.repository.mysql;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.service.entity.mysql.FormRecordIdSeq;

public interface FormRecordIdSeqMySQLRepository extends JpaRepository<FormRecordIdSeq, UUID> {

    Optional<FormRecordIdSeq> findByFormCode(String formCode);

}
