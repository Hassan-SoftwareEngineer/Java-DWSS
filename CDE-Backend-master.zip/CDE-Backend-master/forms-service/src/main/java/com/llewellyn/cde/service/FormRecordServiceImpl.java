package com.llewellyn.cde.service;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.config.RequestValuesContainer;
import com.llewellyn.cde.exception.Errors;
import com.llewellyn.cde.pojo.FormPagePojo;
import com.llewellyn.cde.pojo.FormRecordPojo;
import com.llewellyn.cde.pojo.FormsPojo;
import com.llewellyn.cde.pojo.PropertiesPojo;
import com.llewellyn.cde.pojo.request.ApprovalProcessSubmitDto;
import com.llewellyn.cde.service.data.FormRecordDataService;
import com.llewellyn.cde.service.entity.FormStatusEnum;
import com.llewellyn.cde.service.entity.mysql.FormRecord;
import com.llewellyn.cde.specification.Filter;
import com.llewellyn.cde.specification.FilterRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

@Service
@Slf4j
public class FormRecordServiceImpl implements FormRecordService {

    private final FormService formService;
    private final RequestValuesContainer requestValuesContainer;

    private final FormRecordDataService formRecordDataService;

    public FormRecordServiceImpl(FormService formService,
            FormRecordDataService formRecordDataService, RequestValuesContainer requestValuesContainer) {
        this.formService = formService;
        this.formRecordDataService = formRecordDataService;
        this.requestValuesContainer = requestValuesContainer;
    }

    @Override
    public FormRecordPojo submitForm(String formSchemaId, FormRecordPojo formRecordPojo) {

        log.info("Save form in open mode");

        String username = requestValuesContainer.getRequestValues().get("username");

        // Fetch Form schema
        FormsPojo formsPojo = formService.getFormBySchemaId(formSchemaId);

        // Create form record object
        FormRecordPojo saveFormRecordObj = new FormRecordPojo();

        if (Objects.nonNull(formRecordPojo.getId())) {
            // Has form reference code and get existing form
            saveFormRecordObj = this.getOneFormRecord(formRecordPojo.getId());
            if (Objects.nonNull(saveFormRecordObj)) {
                if (saveFormRecordObj.getStatus().equals(FormStatusEnum.Draft)) {
                    saveFormRecordObj.setAnswers(formRecordPojo.getAnswers());
                } else {
                    throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form ID has been submitted");
                }
            } else {
                throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form Record ID does not exist");
            }
        } else {
            // Create new draft form
            if (Objects.isNull(formsPojo)) {
                throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form ID is not correct");
            }
            fillFormRecordPojoFromForms(formRecordPojo, formsPojo);
            formRecordPojo.setSubmittedBy(username);
            saveFormRecordObj = formRecordPojo;
        }

        if (Objects.isNull(saveFormRecordObj.getAnswers())) {
            throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Answers cannot be null");
        }

        // Validate Form answers
        if (Objects.nonNull(formsPojo)) {
            List<String> wrongQuestions = new ArrayList<>();
            List<PropertiesPojo> lstQuestions = getQuestionsCountFromForm(formsPojo);
            List<String> lstQuestionNames = new ArrayList<>();
            // getAllQuestions(formRecordPojo.getAnswers(), lstQuestionNames);
            getAllQuestionsFromMap(formRecordPojo.getAnswers(), lstQuestionNames);
            for (String _question : lstQuestionNames) {
                boolean questionFound = false;
                for (PropertiesPojo propertiesPojo : lstQuestions) {
                    if (propertiesPojo.getName().equals(_question)) {
                        questionFound = true;
                        break;
                    }
                }
                if (!questionFound) {
                    wrongQuestions.add(_question);
                }

            }
            if (!wrongQuestions.isEmpty()) {
                throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC,
                        "These Questions are not in the form " + wrongQuestions);
            }

            if (lstQuestions.size() == lstQuestionNames.size()) {
                log.info("Questions and Answers are of same size.");

            } else {
                long requiredQuestionsCount = lstQuestions.stream()
                        .filter(propertiesPojo -> propertiesPojo.getRequired()).count();
                AtomicLong requiredAnswersCount = new AtomicLong();
                lstQuestions.stream().forEach(propertiesPojo -> {
                    if (propertiesPojo.getRequired()) {
                        // Question is required so check if the answer is given against it.
                        requiredAnswersCount.set(lstQuestionNames.stream()
                                .filter(question -> question.equals(propertiesPojo.getName())).count());
                    }
                });
                if (requiredQuestionsCount != requiredAnswersCount.get()) {
                    throw new CommonErrorException(Errors.BAD_REQUEST_COUNT_NOT_MATCH);
                }
            }
            FormRecordPojo pojo = formRecordDataService.saveFormRecordService(formRecordPojo, FormStatusEnum.Open);
            return pojo;

        } else {
            throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form record cannot be empty");
        }
    }

    @Override
    public FormRecordPojo saveDraftForm(String formSchemaId, FormRecordPojo formRecordPojo) {

        log.info("Save form in draft mode");

        FormRecordPojo saveFormRecordObj = new FormRecordPojo();

        if (Objects.nonNull(formRecordPojo.getId())) {
            // Has form reference code and get existing form
            saveFormRecordObj = this.getOneFormRecord(formRecordPojo.getId());
            if (Objects.nonNull(saveFormRecordObj)) {
                if (saveFormRecordObj.getStatus().equals(FormStatusEnum.Draft)) {
                    saveFormRecordObj.setAnswers(formRecordPojo.getAnswers());
                } else {
                    throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form ID has been submitted");
                }
            } else {
                throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form Record ID does not exist");
            }
        } else {
            // Create new draft form
            FormsPojo formsPojo = formService.getFormBySchemaId(formSchemaId);
            if (Objects.isNull(formsPojo)) {
                throw new CommonErrorException(Errors.BAD_REQUEST_ERROR_WITH_DESC, "Form ID is not correct");
            }
            fillFormRecordPojoFromForms(formRecordPojo, formsPojo);
            saveFormRecordObj = formRecordPojo;
        }

        FormRecordPojo pojo = formRecordDataService.saveFormRecordService(saveFormRecordObj, FormStatusEnum.Draft);
        return pojo;
    }

    @Override
    public List<FormRecordPojo> getAnswersOfForm(String formId) {
        return formRecordDataService.getFormForFormId(formId);
    }

    @Override
    public List<FormRecordPojo> getAnswersOfFormAgainstUserId(String userId) {
        return formRecordDataService.getFormForUserId(userId);
    }

    @Override
    public List<FormRecordPojo> getAllAnswers() {
        return formRecordDataService.getAllAnswers();
    }

    @Override
    public FormRecordPojo getOneFormRecord(String formRecordId) {
        return formRecordDataService.getOneFormRecordAgainstId(formRecordId);
    }

    @Override
    public void deleteFormRecord(String formRecordId) {
        formRecordDataService.deleteFormRecord(formRecordId);
    }

    @Override
    public Map<String, Object> getFilteredFormRecord(FilterRequest filterRequest, int pageNo, int pageSize,
            String sortBy, String sortDir) {

        log.info("Get all filtered form record");

        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        // create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

        Page<FormRecord> formRecordPage = formRecordDataService.getALlRecordsByFilter(filterRequest, pageable);

        Map<String, Object> response = new HashMap<>();
        response.put("content", formRecordPage.getContent());
        response.put("pageNo", formRecordPage.getNumber());
        response.put("pageSize", formRecordPage.getSize());
        response.put("totalItems", formRecordPage.getTotalElements());
        response.put("totalPage", formRecordPage.getTotalPages());

        return response;
    }

    @Override
    public List<FormRecord> getApprovalFormList(int pageNo) {
        // TODO Auto-generated method stub
        log.info("Get all filtered form record");
        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        Sort sort = Sort.by("createdAt").descending();

        // create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, 20, sort);

        List<FormRecord> formRecordList = formRecordDataService.getAllApprovalFormByUser(pageable);

        return formRecordList;
    }

    @Override
    public FormRecordPojo updateFormStatus(UUID formRecordHeaderId, ApprovalProcessSubmitDto approvalProcessSubmitDto) {
        // TODO Auto-generated method stub
        log.info("updateFormStatus with form record ref.: {}", formRecordHeaderId);

        return formRecordDataService.updateFormRecordByRefereceCode(formRecordHeaderId, approvalProcessSubmitDto);
    }

    private List<PropertiesPojo> getQuestionsCountFromForm(FormsPojo forms) {
        List<PropertiesPojo> lstStringQuestions;
        lstStringQuestions = new ArrayList<>();

        List<FormPagePojo> listPage = forms.getFormPage();
        for (FormPagePojo formPage : listPage) {
            if (Objects.nonNull(formPage.getQuestions())) {
                for (PropertiesPojo propertiesPojo : formPage.getQuestions().getProperties()) {
                    lstStringQuestions.add(propertiesPojo);
                }
            }
        }
        return lstStringQuestions;
    }

    // private void getAllQuestions(JsonNode jsonNode, List<String> keys) {
    // if (jsonNode.isObject()) {
    // Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
    // fields.forEachRemaining(field -> {
    // keys.add(field.getKey());
    // getAllQuestions((JsonNode) field.getValue(), keys);
    // });
    // } else if (jsonNode.isArray()) {
    // ArrayNode arrayField = (ArrayNode) jsonNode;
    // arrayField.forEach(node -> {
    // getAllQuestions(node, keys);
    // });
    // }
    // }

    private void getAllQuestionsFromMap(Map<Object, String> jsonNode, List<String> keys) {
        jsonNode.forEach((k, v) -> {
            keys.add(k.toString());
        });
        // if (jsonNode.isObject()) {
        // Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
        // fields.forEachRemaining(field -> {
        // keys.add(field.getKey());
        // getAllQuestions((JsonNode) field.getValue(), keys);
        // });
        // } else if (jsonNode.isArray()) {
        // ArrayNode arrayField = (ArrayNode) jsonNode;
        // arrayField.forEach(node -> {
        // getAllQuestions(node, keys);
        // });
        // }
    }

    private void fillFormRecordPojoFromForms(FormRecordPojo pojo, FormsPojo forms) {

        pojo.setFormName(forms.getFormName());
        pojo.setFormCode(forms.getFormCode());
        pojo.setFormType(forms.getFormType());
        pojo.setFormTypeName(forms.getFormTypeName());
        pojo.setFormSubType(forms.getFormSubType());
        pojo.setFormSubTypeName(forms.getFormSubTypeName());
        pojo.setQuestionFormId(forms.getId());
        pojo.setProjectId(forms.getProjectId().toString());
        pojo.setProjectCode("NOT Defined");
        pojo.setProjectName("NOT Defined");
    }

    // private boolean areMainAnswersValid() {
    // return false;
    // }

    // private Integer getNumberOfQuestionsInMain() {
    // return null;
    // }

    // private Integer getNumberOfQuestionsFromPage(String pageNme) {
    // return null;
    // }
}
