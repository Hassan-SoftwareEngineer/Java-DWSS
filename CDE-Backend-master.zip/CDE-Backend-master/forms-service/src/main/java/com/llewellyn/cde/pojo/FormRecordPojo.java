package com.llewellyn.cde.pojo;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.llewellyn.cde.feign.responseDto.ActionFormRequestDto;
import com.llewellyn.cde.service.entity.FormStatusEnum;

@Data
public class FormRecordPojo {
    private String id;
    private String formName;
    private String formCode;
    private String formType;
    private String formTypeName;
    private String formSubType;
    private String formSubTypeName;
    private String questionFormId;
    private String projectId;
    private String projectCode;
    private String projectName;
    private String block;
    private String floor;
    private String part;
    private String parentForm;
    private FormStatusEnum status;
    private String submittedBy;
    private Map<Object, String> answers;
    private FormsPojo formSchema;
    private List<ActionFormRequestDto> actions = new ArrayList<>();
    private List<FormApprovalProcessDto> formApprovalProcess = new ArrayList<>();
}
