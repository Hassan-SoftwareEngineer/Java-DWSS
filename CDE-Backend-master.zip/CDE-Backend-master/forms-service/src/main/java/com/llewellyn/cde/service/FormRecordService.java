package com.llewellyn.cde.service;

import com.llewellyn.cde.pojo.FormRecordPojo;
import com.llewellyn.cde.pojo.request.ApprovalProcessSubmitDto;
import com.llewellyn.cde.service.entity.mysql.FormRecord;
import com.llewellyn.cde.specification.FilterRequest;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface FormRecordService {

    FormRecordPojo submitForm(String formId, FormRecordPojo formRecordPojo);

    FormRecordPojo saveDraftForm(String formId, FormRecordPojo formRecordPojo);

    List<FormRecordPojo> getAnswersOfForm(String formId);

    List<FormRecordPojo> getAnswersOfFormAgainstUserId(String userId);

    List<FormRecordPojo> getAllAnswers();

    FormRecordPojo getOneFormRecord(String formId);

    void deleteFormRecord(String formRecordId);

    Map<String, Object> getFilteredFormRecord(FilterRequest filterRequest, int pageNo, int pageSize, String sortBy,
            String sortDir);

    List<FormRecord> getApprovalFormList(int pageNo);

    FormRecordPojo updateFormStatus(UUID formRecordHeaderId, ApprovalProcessSubmitDto approvalProcessSubmitDto);
    
}
