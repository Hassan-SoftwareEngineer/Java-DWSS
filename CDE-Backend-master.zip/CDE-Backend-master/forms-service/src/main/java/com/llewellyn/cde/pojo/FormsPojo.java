package com.llewellyn.cde.pojo;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class FormsPojo {
    private String id;
    @NotBlank
    private String formName;
    @NotBlank
    private String formCode;
    @NotBlank
    private String formType;
    private String formTypeName;
    private String formSubType;
    private String formSubTypeName;
    private String projectId;
    private Boolean isActive;
    private String versionNo;
    @NotNull
    private Integer mobilePages;
    private List<FormPagePojo> formPage;
}
