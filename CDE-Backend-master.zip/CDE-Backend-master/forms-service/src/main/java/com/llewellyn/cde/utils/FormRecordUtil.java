package com.llewellyn.cde.utils;

public class FormRecordUtil {

    private static final char[] ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    public static String revisionFormRecordIdGenerate(String parentFormId, int parentlistCount) {

        String newFormRecordId = parentFormId;
        if (parentlistCount <= 26) {
            newFormRecordId = newFormRecordId.concat("-").concat(String.valueOf(ALPHABET[parentlistCount - 1]));
        } else {
            int firstCharInt = parentlistCount / 26;
            int secondCharInt = parentlistCount % 26;
            newFormRecordId = newFormRecordId.concat("-").concat(String.valueOf(ALPHABET[firstCharInt - 1]))
                    .concat(String.valueOf(ALPHABET[secondCharInt - 1]));
        }
        return newFormRecordId;
    }
}
