package com.llewellyn.cde.pojo;

import lombok.Data;

@Data
public class Answers {
    private String question;
    private String answer;
}
