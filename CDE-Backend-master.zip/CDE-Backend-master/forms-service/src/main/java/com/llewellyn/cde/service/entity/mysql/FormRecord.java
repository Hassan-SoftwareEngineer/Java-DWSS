package com.llewellyn.cde.service.entity.mysql;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "form_record_header")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormRecord extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Type(type = "uuid-char")
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private FormList formList;

    private String formName;

    private String formType;

    private String formSubType;

    private String formSchemaId;

    private String formReferenceCode;

    @Type(type = "uuid-char")
    private UUID projectId;

    private String block;

    private String floor;

    private LocalDateTime submittedAt;

    private String submittedBy;

    private String parentForm;

    // @Enumerated(EnumType.STRING)
    private String status;
}
