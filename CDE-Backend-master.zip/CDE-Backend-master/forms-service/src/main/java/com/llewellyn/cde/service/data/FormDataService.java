package com.llewellyn.cde.service.data;

import com.llewellyn.cde.service.entity.Forms;
import com.llewellyn.cde.service.entity.mysql.FormList;
import com.llewellyn.cde.specification.FilterRequest;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FormDataService {
    Forms saveForm(Forms forms);

    Forms updateForm(Forms forms, String id);

    Forms updateFormWithVersion(Forms forms, String id, String version);

    void deleteForm(String id);

    Forms getForm(String id);

    FormList getFormList(String formSchemaId);

    List<Forms> getAllForms();

    Page<FormList> getALlFormsByFilter(FilterRequest filterRequest, Pageable pageable);

    FormList getMySQLForm(String formId);

    void deleteFormByFormId(UUID formId);

    Forms saveFormWithProjectId(Forms forms, String projectId);
}
