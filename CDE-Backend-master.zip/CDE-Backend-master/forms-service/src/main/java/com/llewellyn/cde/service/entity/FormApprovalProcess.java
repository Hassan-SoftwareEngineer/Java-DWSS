package com.llewellyn.cde.service.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document
public class FormApprovalProcess {

    private UUID userId;
    private String username;
    private String result;
    private LocalDateTime submitedAt;
    
}
