package com.llewellyn.cde.feign.responseDto;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestDto {
    
    private UUID approvalRequestId;
    private UUID requestId;
    private UUID formId;
    
}
