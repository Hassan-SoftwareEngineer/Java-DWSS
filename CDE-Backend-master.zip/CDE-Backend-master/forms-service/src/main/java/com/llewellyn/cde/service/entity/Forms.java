package com.llewellyn.cde.service.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.List;

@Data
public class Forms {
    @Id
    @JsonProperty(value = "formSchemaId")
    private String id;
    private String formName;
    private String formCode;
    private String formType;
    private String formTypeName;
    private String formSubType;
    private String formSubTypeName;
    private String projectId;
    private Boolean isActive;
    private String versionNo;
    private String mobilePages;
    private List<FormPage> formPage;

}
