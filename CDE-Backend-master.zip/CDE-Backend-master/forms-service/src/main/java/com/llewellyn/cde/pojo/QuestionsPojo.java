package com.llewellyn.cde.pojo;

import lombok.Data;

import java.util.List;

@Data
public class QuestionsPojo {
    private List<String> headers;
    private List<PropertiesPojo> properties;
}
