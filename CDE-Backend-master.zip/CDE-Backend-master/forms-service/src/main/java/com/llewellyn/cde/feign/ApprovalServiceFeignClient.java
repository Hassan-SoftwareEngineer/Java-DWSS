package com.llewellyn.cde.feign;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.llewellyn.cde.feign.requestDto.ApprovalRequestCreateDto;
import com.llewellyn.cde.feign.responseDto.ActionFormRequestDto;
import com.llewellyn.cde.feign.responseDto.ApprovalRequestDto;

@FeignClient(name = "approval-service", value = "approval-service")
public interface ApprovalServiceFeignClient {

    @PostMapping("/api/v1/approval/request/{request_id}")
    List<ApprovalRequestDto> createNewApprovalRequest(
            @PathVariable("request_id") UUID request_id,
            @Valid @RequestBody ApprovalRequestCreateDto approvalRequestCreateDto);

    @GetMapping("/api/v1/approval/request/{request_id}/user/{user_id}")
    List<ActionFormRequestDto> getRequestUserAction(@PathVariable("request_id") UUID request_id,
            @PathVariable("user_id") UUID user_id);

    @GetMapping("/api/v1/approval/user/{user_id}/pending")
    List<UUID> getPendingRequestIdList(@PathVariable("user_id") UUID user_id, @RequestParam int pageNo,
            @RequestParam int pageSize);

}
