package com.llewellyn.cde.service.data;

import com.llewellyn.cde.config.RequestValuesContainer;
import com.llewellyn.cde.feign.ApprovalServiceFeignClient;
import com.llewellyn.cde.feign.requestDto.ApprovalRequestCreateDto;
import com.llewellyn.cde.feign.responseDto.ActionFormRequestDto;
import com.llewellyn.cde.pojo.FormRecordPojo;
import com.llewellyn.cde.pojo.header.FormRecordHeaderDto;
import com.llewellyn.cde.pojo.request.ApprovalProcessSubmitDto;
import com.llewellyn.cde.service.entity.FormApprovalProcess;
import com.llewellyn.cde.service.entity.FormRecordDocument;
import com.llewellyn.cde.service.entity.FormStatusEnum;
import com.llewellyn.cde.service.entity.Forms;
import com.llewellyn.cde.service.entity.mysql.FormList;
import com.llewellyn.cde.service.entity.mysql.FormRecord;
import com.llewellyn.cde.service.entity.mysql.FormRecordIdSeq;
import com.llewellyn.cde.service.repository.FormRecordServiceRepository;
import com.llewellyn.cde.service.repository.mysql.FormRecordIdSeqMySQLRepository;
import com.llewellyn.cde.service.repository.mysql.FormRecordMySQLRepository;
import com.llewellyn.cde.specification.Filter;
import com.llewellyn.cde.specification.FilterRequest;
import com.llewellyn.cde.specification.FormRecordSpecification;
import com.llewellyn.cde.utils.FormRecordUtil;

import lombok.extern.slf4j.Slf4j;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
@Transactional
public class FormRecordDataServiceImpl implements FormRecordDataService {

    private final FormRecordServiceRepository formRecordServiceRepository;
    private final ModelMapper mapper;
    private final FormRecordMySQLRepository formRecordMySQLRepository;

    @Autowired
    private FormRecordIdSeqMySQLRepository formRecordIdSeqMySQLRepository;

    private final FormDataService formDataService;
    private final RequestValuesContainer requestValuesContainer;

    @Autowired
    private ApprovalServiceFeignClient approvalServiceFeignClient;

    public FormRecordDataServiceImpl(FormRecordServiceRepository formRecordServiceRepository, ModelMapper mapper,
            FormRecordMySQLRepository formRecordMySQLRepository, FormDataService formDataService,
            RequestValuesContainer requestValuesContainer) {
        this.formRecordServiceRepository = formRecordServiceRepository;
        this.mapper = mapper;
        this.formRecordMySQLRepository = formRecordMySQLRepository;
        this.formDataService = formDataService;
        this.requestValuesContainer = requestValuesContainer;
    }

    @Override
    public FormRecordPojo saveFormRecordService(FormRecordPojo formRecordPojo, FormStatusEnum formStatus) {

        String username = requestValuesContainer.getRequestValues().get("username");
        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        // Assign form record ID if Id is null
        if (Objects.isNull(formRecordPojo.getId()) && Objects.isNull(formRecordPojo.getParentForm())) {
            Optional<FormRecordIdSeq> formRecordIdSeqOptional = formRecordIdSeqMySQLRepository
                    .findByFormCode(formRecordPojo.getFormCode());
            FormRecordIdSeq formRecordIdSeq = new FormRecordIdSeq();
            log.info("findByFormCode with {}", formRecordPojo.getFormCode());
            if (formRecordIdSeqOptional.isPresent()) {
                log.info("formRecordIdSeq is {}", formRecordIdSeq.getFormSequenceNo());
                formRecordIdSeq = formRecordIdSeqOptional.get();
                formRecordIdSeq.setFormSequenceNo(formRecordIdSeq.getFormSequenceNo() + 1);
            } else {
                log.info("New Form Sequence");
                formRecordIdSeq.setFormCode(formRecordPojo.getFormCode());
                formRecordIdSeq.setFormSequenceNo(1);
            }

            // Creat and set Form Record ID
            String formRecordId = formRecordPojo.getFormCode().replace("/", "-")
                    .concat("-")
                    .concat(String.format("%05d", formRecordIdSeq.getFormSequenceNo()));
            formRecordPojo.setId(formRecordId);
            formRecordPojo.setParentForm(formRecordId);
            formRecordIdSeqMySQLRepository.save(formRecordIdSeq);

        } else if (Objects.isNull(formRecordPojo.getId()) && Objects.nonNull(formRecordPojo.getParentForm())) {
            log.info("Resubmit a new form ID");
            int parentFormsCount = (int) formRecordMySQLRepository.countByParentForm(formRecordPojo.getParentForm());
            log.info("Previous Form Count: {}", parentFormsCount);
            formRecordPojo.setId(
                    FormRecordUtil.revisionFormRecordIdGenerate(formRecordPojo.getParentForm(), parentFormsCount));
            log.info("New ID: {}", formRecordPojo.getId());
        }

        // Save Form Record to MongoDB
        FormRecordDocument formRecordDocument = this.mapper.map(formRecordPojo, FormRecordDocument.class);
        formRecordDocument.setStatus(formStatus);

        if (formStatus.equals(FormStatusEnum.Open)) {
            formRecordDocument.setSubmittedBy(username);
        }
        formRecordDocument = formRecordServiceRepository.save(formRecordDocument);

        formRecordPojo = this.mapper.map(formRecordDocument, FormRecordPojo.class);

        // Fetch form from MySQL form_list db
        FormList formList = formDataService.getFormList(formRecordPojo.getQuestionFormId());

        FormRecord formRecord = new FormRecord();
        // Check and fetch form exist by form reference code
        Optional<FormRecord> formRecordOptional = formRecordMySQLRepository
                .findByFormReferenceCode(formRecordPojo.getId());
        if (formRecordOptional.isPresent()) {
            formRecord = formRecordOptional.get();
        } else {
            formRecord.setFormReferenceCode(formRecordPojo.getId());
            formRecord.setFormList(formList);
            formRecord.setFormName(formRecordPojo.getFormName());
            formRecord.setFormType(formRecordPojo.getFormType());
            formRecord.setFormSubType(formRecordPojo.getFormSubType());
            formRecord.setFormSchemaId(formRecordPojo.getQuestionFormId());
            formRecord.setProjectId(UUID.fromString(formRecordPojo.getProjectId()));
            formRecord.setBlock(formRecordPojo.getBlock());
            formRecord.setFloor(formRecordPojo.getFloor());
            formRecord.setParentForm(formRecordPojo.getParentForm());
            formRecord.setCreatedBy(username);
        }

        formRecord.setStatus(formStatus.toString());
        formRecord.setModifiedBy(username);
        formRecord.setUpdatedAt(LocalDateTime.now());

        if (formStatus.equals(FormStatusEnum.Open)) {
            formRecord.setSubmittedBy(username);
            formRecord.setSubmittedAt(LocalDateTime.now());
        }

        formRecord = formRecordMySQLRepository.save(formRecord);

        if (formStatus.equals(FormStatusEnum.Open)) {
            ApprovalRequestCreateDto approvalRequestCreateDto = new ApprovalRequestCreateDto("Form", formList.getId(), userId);
            approvalServiceFeignClient.createNewApprovalRequest(formRecord.getId(), approvalRequestCreateDto);
        }

        return formRecordPojo;
    }

    @Override
    public List<FormRecordPojo> getFormForFormId(String formId) {

        List<FormRecordDocument> listFormRecordDocument = formRecordServiceRepository
                .getFormRecordDocumentByQuestionFormId(formId);
        List<FormRecordPojo> lstFormRecordPojo = new ArrayList<>();
        for (FormRecordDocument formRecordDocument : listFormRecordDocument) {
            lstFormRecordPojo.add(this.mapper.map(formRecordDocument, FormRecordPojo.class));
        }
        return lstFormRecordPojo;
    }

    @Override
    public List<FormRecordPojo> getFormForUserId(String userId) {
        List<FormRecordDocument> listFormRecordDocument = formRecordServiceRepository
                .getFormRecordDocumentBySubmittedBy(userId);
        List<FormRecordPojo> lstFormRecordPojo = new ArrayList<>();
        for (FormRecordDocument formRecordDocument : listFormRecordDocument) {
            lstFormRecordPojo.add(this.mapper.map(formRecordDocument, FormRecordPojo.class));
        }
        return lstFormRecordPojo;
    }

    @Override
    public List<FormRecordPojo> getAllAnswers() {
        List<FormRecordDocument> listFormRecordDocument = formRecordServiceRepository.findAll();
        List<FormRecordPojo> lstFormRecordPojo = new ArrayList<>();
        for (FormRecordDocument formRecordDocument : listFormRecordDocument) {
            lstFormRecordPojo.add(this.mapper.map(formRecordDocument, FormRecordPojo.class));
        }
        return lstFormRecordPojo;
    }

    @Override
    public FormRecordPojo getOneFormRecordAgainstId(String formRecordReferenceCode) {

        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        Optional<FormRecordDocument> formRecordDocumentOptional = Optional.empty();
        formRecordDocumentOptional = formRecordServiceRepository.findById(formRecordReferenceCode);

        Optional<FormRecord> formRecordHeaderOptional = formRecordMySQLRepository
                .findByFormReferenceCode(formRecordReferenceCode);

        if (formRecordDocumentOptional.isPresent()) {

            // Get form schema and add in formRecordDocument
            Forms formSchema = formDataService.getForm(formRecordDocumentOptional.get().getQuestionFormId());
            FormRecordDocument formRecordDocument = formRecordDocumentOptional.get();
            formRecordDocument.setFormSchema(formSchema);

            // DTO mapping from formRecordDocument to FormRecordPojo
            FormRecordPojo formRecordPojo = this.mapper.map(formRecordDocumentOptional.get(), FormRecordPojo.class);

            // Add User Action in response
            UUID formRecordId = formRecordHeaderOptional.get().getId();
            List<ActionFormRequestDto> actionFormRequestDtos = approvalServiceFeignClient
                    .getRequestUserAction(formRecordId, userId);
            formRecordPojo.setActions(actionFormRequestDtos);
            return formRecordPojo;
        } else {
            return null;
        }

    }

    @Override
    public FormRecordHeaderDto getOneFormRecordHeaderByReferenceCode(String formRecordId) {
        log.info("Get One Form Record Header By Reference Code: {}", formRecordId);

        Optional<FormRecord> formRecordOptional = formRecordMySQLRepository.findByFormReferenceCode(formRecordId);
        if (formRecordOptional.isPresent()) {
            return this.mapper.map(formRecordOptional.get(), FormRecordHeaderDto.class);
        } else {
            return null;
        }
    }

    @Override
    @Transactional
    public void deleteFormRecord(String id) {
        formRecordServiceRepository.deleteById(id);
        formRecordMySQLRepository.deleteByFormReferenceCode(id);
    }

    @Override
    public Page<FormRecord> getALlRecordsByFilter(FilterRequest filterRequest, Pageable pageable) {
        log.info("getALlRecordsByFilter");

        Page<FormRecord> formRecordPage;
        if (filterRequest != null && filterRequest.getFilters().size() > 0) {
            FormRecordSpecification recordSpecification = new FormRecordSpecification();
            for (Filter filterCriteria : filterRequest.getFilters()) {
                recordSpecification.add(filterCriteria);
            }
            formRecordPage = formRecordMySQLRepository.findAll(recordSpecification, pageable);
        } else {
            formRecordPage = formRecordMySQLRepository.findAll(pageable);
        }

        return formRecordPage;
    }

    @Override
    public List<FormRecord> getAllApprovalFormByUser(Pageable pageable) {
        // TODO Auto-generated method stub
        log.info("getAllApprovalFormByUser");

        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        List<UUID> approvalFormList = approvalServiceFeignClient.getPendingRequestIdList(userId,
                pageable.getPageNumber(), 20);

        log.info(approvalFormList.toString());
        if(approvalFormList.size() == 0) {
            return new ArrayList<>();
        }

        FilterRequest filterRequest = new FilterRequest();
        Filter approvalFilter = new Filter("id", "in", approvalFormList);
        filterRequest.getFilters().add(approvalFilter);

        Page<FormRecord> formRecordPage = this.getALlRecordsByFilter(filterRequest, pageable);

        return formRecordPage.getContent();

    }

    @Override
    public FormRecordPojo updateFormRecordByRefereceCode(UUID formRecordHeaderId,
            ApprovalProcessSubmitDto approvalProcessSubmitDto) {
        // TODO Auto-generated method stub
        log.info("updateFormRecordByRefereceCode with form record id: {}", formRecordHeaderId);

        // Find form record header by Reference Code
        Optional<FormRecord> formRecordHeaderOptional = formRecordMySQLRepository
                .findById(formRecordHeaderId);

        // Find form record document by Reference Code
        Optional<FormRecordDocument> formRecordDocumentOptional = Optional.empty();
        formRecordDocumentOptional = formRecordServiceRepository
                .findById(formRecordHeaderOptional.get().getFormReferenceCode());

        // Update form record document status
        FormRecordDocument formRecordDocument = formRecordDocumentOptional.get();
        FormRecord formRecord = formRecordHeaderOptional.get();

        if (approvalProcessSubmitDto.getFormStatus().equalsIgnoreCase("approved")) {
            formRecordDocument.setStatus(FormStatusEnum.Approved);
            formRecord.setStatus(FormStatusEnum.Approved.toString());
        } else if (approvalProcessSubmitDto.getFormStatus().equalsIgnoreCase("rejected")) {
            formRecordDocument.setStatus(FormStatusEnum.Rejected);
            formRecord.setStatus(FormStatusEnum.Rejected.toString());
        } else {
            formRecordDocument.setStatus(FormStatusEnum.Open);
            formRecord.setStatus(FormStatusEnum.Open.toString());
        }

        // Add approval process action on form record document
        FormApprovalProcess newFormApprovalProcess = new FormApprovalProcess();
        newFormApprovalProcess.setUserId(approvalProcessSubmitDto.getUserId());
        newFormApprovalProcess.setUsername(approvalProcessSubmitDto.getUsername());
        newFormApprovalProcess.setResult(approvalProcessSubmitDto.getResult());
        newFormApprovalProcess.setSubmitedAt(LocalDateTime.now());
        formRecordDocument.getFormApprovalProcess().add(newFormApprovalProcess);

        // Save form approval document
        formRecordServiceRepository.save(formRecordDocument);

        // Save form record header
        formRecordMySQLRepository.save(formRecord);

        // DTO mapping from formRecordDocument to FormRecordPojo
        FormRecordPojo formRecordPojo = this.mapper.map(formRecordDocument, FormRecordPojo.class);

        return formRecordPojo;

    }
}
