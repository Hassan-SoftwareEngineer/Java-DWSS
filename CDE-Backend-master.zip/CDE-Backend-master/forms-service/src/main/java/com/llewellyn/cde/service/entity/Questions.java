package com.llewellyn.cde.service.entity;

import lombok.Data;

import java.util.List;

@Data
public class Questions {
    private List<String> headers;
    private List<Properties> properties;
}
