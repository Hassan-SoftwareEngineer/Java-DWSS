package com.llewellyn.cde.service;

import com.llewellyn.cde.pojo.FormsPojo;
import com.llewellyn.cde.specification.FilterRequest;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface FormService {

    List<FormsPojo> getAllForms();

    Map<String, Object> getFilteredFormList(FilterRequest filterRequest, int pageNo, int pageSize, String sortBy,
    String sortDir);

    FormsPojo getFormBySchemaId(String formSchemaId);

    FormsPojo getForm(String formId);

    FormsPojo saveForm(FormsPojo form);

    FormsPojo updateForm(FormsPojo form, String id);

    FormsPojo updateFormWithNewVersion(FormsPojo form, String id, String versionNumber);

    void deleteForm(String formSchemaId);

    void deleteFormByFormId(UUID formId);

    FormsPojo saveFormWithProjectId(FormsPojo form, String projectId);

}
