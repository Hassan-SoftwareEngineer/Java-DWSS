package com.llewellyn.cde.service.entity;

import lombok.Data;

import java.util.List;

@Data
public class Properties {
    private String name;
    private String type;
    private String label;
    private Boolean required;
    private List<PropertiesOptions> options;

}
