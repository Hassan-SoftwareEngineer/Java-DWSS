package com.llewellyn.cde.pojo;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document
public class FormPagePojo {
    private String name;
    private String title;
    private String subtitle;
    private QuestionsPojo questions;
}
