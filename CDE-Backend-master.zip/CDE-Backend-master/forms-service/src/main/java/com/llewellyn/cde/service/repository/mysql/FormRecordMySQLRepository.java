package com.llewellyn.cde.service.repository.mysql;

import com.llewellyn.cde.service.entity.mysql.FormRecord;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;
import java.util.UUID;

public interface FormRecordMySQLRepository
        extends JpaRepository<FormRecord, UUID>, JpaSpecificationExecutor<FormRecord> {

    void deleteByFormReferenceCode(String formReferenceCode);

    Optional<FormRecord> findByFormReferenceCode(String formReferenceCode);

    long countByParentForm(String parentForm);

}
