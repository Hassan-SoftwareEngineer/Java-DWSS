package com.llewellyn.cde.service.entity;

public enum FormStatusEnum {
    Draft, Open, Approved, Rejected
}
