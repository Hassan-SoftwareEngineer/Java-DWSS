package com.llewellyn.cde.service.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

import java.util.List;
import java.util.Map;

@Document
@Data
@NoArgsConstructor
public class FormRecordDocument {
    @Id
    @JsonProperty(value = "formRecordSchemaId")
    private String id;
    private String formName;
    private String formCode;
    private String formReferenceCode;
    private String formType;
    private String formTypeName;
    private String formSubType;
    private String formSubTypeName;
    private String questionFormId;
    private String projectId;
    private String projectCode;
    private String projectName;
    private String block;
    private String floor;
    private String parentForm;
    private String submittedBy;
    private FormStatusEnum status;
    private Map<Object, String> answers;
    private Forms formSchema;
    private List<FormApprovalProcess> formApprovalProcess;
    // private List<Answers> answers;
}
