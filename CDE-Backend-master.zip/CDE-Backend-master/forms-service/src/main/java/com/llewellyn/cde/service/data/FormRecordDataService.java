package com.llewellyn.cde.service.data;

import com.llewellyn.cde.pojo.FormRecordPojo;
import com.llewellyn.cde.pojo.header.FormRecordHeaderDto;
import com.llewellyn.cde.pojo.request.ApprovalProcessSubmitDto;
import com.llewellyn.cde.service.entity.FormStatusEnum;
import com.llewellyn.cde.service.entity.mysql.FormRecord;
import com.llewellyn.cde.specification.FilterRequest;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FormRecordDataService {
    FormRecordPojo saveFormRecordService(FormRecordPojo formRecordPojo, FormStatusEnum formStatus);

    List<FormRecordPojo> getFormForFormId(String formId);

    List<FormRecordPojo> getFormForUserId(String userId);

    List<FormRecordPojo> getAllAnswers();

    Page<FormRecord> getALlRecordsByFilter(FilterRequest filterRequest, Pageable pageable);

    FormRecordPojo getOneFormRecordAgainstId(String formRecordReferenceCode);

    FormRecordHeaderDto getOneFormRecordHeaderByReferenceCode(String formRecordId);

    void deleteFormRecord(String id);

    List<FormRecord> getAllApprovalFormByUser(Pageable pageable);

    FormRecordPojo updateFormRecordByRefereceCode(UUID formRecordHeaderId, ApprovalProcessSubmitDto approvalProcessSubmitDto);

}
