package com.llewellyn.cde.service.repository;

import com.llewellyn.cde.service.entity.Forms;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Optional;

public interface FormMongoRepository extends MongoRepository<Forms, String> {

    @Query("{_id: new ObjectId('?0')}")
    Optional<Forms> findFormById(String _id);
}
