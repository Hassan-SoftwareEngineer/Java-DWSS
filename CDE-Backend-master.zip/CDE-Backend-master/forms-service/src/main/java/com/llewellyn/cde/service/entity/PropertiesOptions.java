package com.llewellyn.cde.service.entity;

import lombok.Data;

@Data
public class PropertiesOptions {
    private String label;
    private String value;
}
