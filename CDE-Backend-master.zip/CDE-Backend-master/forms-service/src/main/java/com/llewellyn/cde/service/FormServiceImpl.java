package com.llewellyn.cde.service;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.pojo.FormsPojo;
import com.llewellyn.cde.service.data.FormDataService;
import com.llewellyn.cde.service.entity.Forms;
import com.llewellyn.cde.service.entity.mysql.FormList;
import com.llewellyn.cde.specification.FilterRequest;

import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class FormServiceImpl implements FormService {

    private final FormDataService formDataService;
    private final ModelMapper modelMapper;

    public FormServiceImpl(FormDataService formDataService, ModelMapper modelMapper) {
        this.formDataService = formDataService;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<FormsPojo> getAllForms() {
        List<Forms> lstForms = formDataService.getAllForms();
        List<FormsPojo> lstFormsPojo = new ArrayList<>();
        lstForms.stream().forEach(formEntity -> {
            lstFormsPojo.add(modelMapper.map(formEntity, FormsPojo.class));
        });
        return lstFormsPojo;
    }

    @Override
    public FormsPojo getFormBySchemaId(String formSchemaId) {
        List<Forms> lstForms = formDataService.getAllForms();
        Optional<Forms> forms = lstForms.stream().filter(form -> form.getId().equals(formSchemaId
        )).findFirst();
        Forms _forms = forms.get();
        FormsPojo formsPojo = this.modelMapper.map(_forms, FormsPojo.class);
        return formsPojo;
    }

    @Override
    public FormsPojo getForm(String formId) {
        FormList formList = formDataService.getMySQLForm(formId);
        if (Objects.isNull(formList)) {
            throw new CommonErrorException("Form not found");
        }
        return getFormBySchemaId(formList.getSchemaId());
    }

    @Override
    public FormsPojo saveForm(FormsPojo form) {
        Forms entity = modelMapper.map(form, Forms.class);
        Forms formsEntity = formDataService.saveForm(entity);
        return modelMapper.map(formsEntity, FormsPojo.class);
    }

    @Override
    public FormsPojo saveFormWithProjectId(FormsPojo form, String projectId) {
        Forms entity = modelMapper.map(form, Forms.class);
        entity.setProjectId(projectId);
        Forms formsEntity = formDataService.saveFormWithProjectId(entity, projectId);
        return modelMapper.map(formsEntity, FormsPojo.class);
    }

    @Override
    public FormsPojo updateForm(FormsPojo form, String id) {
        Forms formsEntity = formDataService.updateForm(modelMapper.map(form, Forms.class), id);
        return modelMapper.map(formsEntity, FormsPojo.class);
    }

    @Override
    public FormsPojo updateFormWithNewVersion(FormsPojo form, String id, String version) {
        Forms formsEntity = formDataService.updateFormWithVersion(modelMapper.map(form, Forms.class), id, version);
        return modelMapper.map(formsEntity, FormsPojo.class);
    }

    @Override
    public void deleteForm(String formSchemaId) {
        formDataService.deleteForm(formSchemaId);
    }

    @Override
    public void deleteFormByFormId(UUID formId) {
        formDataService.deleteFormByFormId(formId);
    }

    @Override
    public Map<String, Object> getFilteredFormList(FilterRequest filterRequest, int pageNo, int pageSize,
            String sortBy, String sortDir) {
        log.info("Get all filtered form list");

        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        // create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

        Page<FormList> formListPage = formDataService.getALlFormsByFilter(filterRequest, pageable);

        Map<String, Object> response = new HashMap<>();
        response.put("content", formListPage.getContent());
        response.put("pageNo", formListPage.getNumber());
        response.put("pageSize", formListPage.getSize());
        response.put("totalItems", formListPage.getTotalElements());
        response.put("totalPage", formListPage.getTotalPages());

        return response;
    }
}
