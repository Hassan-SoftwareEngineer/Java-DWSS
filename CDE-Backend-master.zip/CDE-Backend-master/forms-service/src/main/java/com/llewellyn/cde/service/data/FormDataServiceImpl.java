package com.llewellyn.cde.service.data;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.service.entity.Forms;
import com.llewellyn.cde.service.entity.mysql.FormList;
import com.llewellyn.cde.service.repository.FormMongoRepository;
import com.llewellyn.cde.service.repository.mysql.FormsMySQLRepository;
import com.llewellyn.cde.specification.Filter;
import com.llewellyn.cde.specification.FilterRequest;
import com.llewellyn.cde.specification.FormListSpecification;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class FormDataServiceImpl implements FormDataService {

    private final FormMongoRepository formMongoRepository;
    private final FormsMySQLRepository formsMySQLRepository;

    public FormDataServiceImpl(FormMongoRepository formMongoRepository, FormsMySQLRepository formsMySQLRepository) {
        this.formMongoRepository = formMongoRepository;
        this.formsMySQLRepository = formsMySQLRepository;
    }

    @Override
    public Forms saveForm(Forms forms) {
        Forms _forms = formMongoRepository.save(forms);

        if (Objects.nonNull(_forms)) {
            FormList formList = new FormList();
            formList.setProjectId(null);
            formList.setFormName(_forms.getFormName());
            formList.setFormCode(_forms.getFormCode());
            formList.setFormType(_forms.getFormType());
            formList.setFormTypeName(_forms.getFormTypeName());
            formList.setFormSubType(_forms.getFormSubType());
            formList.setFormSubTypeName(_forms.getFormSubTypeName());
            formList.setSchemaId(_forms.getId());
            formList.setVersionNo(_forms.getVersionNo());
            formsMySQLRepository.save(formList);
        }
        return _forms;
    }

    @Override
    public Forms saveFormWithProjectId(Forms forms, String projectId) {
        Forms _forms = formMongoRepository.save(forms);

        if (Objects.nonNull(_forms)) {
            FormList formList = new FormList();
            formList.setProjectId(projectId);
            formList.setFormName(_forms.getFormName());
            formList.setFormCode(_forms.getFormCode());
            formList.setFormType(_forms.getFormType());
            formList.setFormTypeName(_forms.getFormTypeName());
            formList.setFormSubType(_forms.getFormSubType());
            formList.setFormSubTypeName(_forms.getFormSubTypeName());
            formList.setSchemaId(_forms.getId());
            formList.setVersionNo(_forms.getVersionNo());
            formsMySQLRepository.save(formList);
        }
        return _forms;
    }

    @Override
    @Transactional
    public Forms updateForm(Forms forms, String id) {
        formMongoRepository.deleteById(id);
        formsMySQLRepository.deleteBySchemaId(id);
        forms.setId(id);
        return saveForm(forms);
    }

    @Override
    @Transactional
    public Forms updateFormWithVersion(Forms forms, String id, String version) {
        Optional<FormList> optionalFormList = formsMySQLRepository.findBySchemaId(id);
        if (optionalFormList.isEmpty()) {

        }
        FormList formList = optionalFormList.get();
        Optional<Forms> optionalForm = formMongoRepository.findFormById(formList.getSchemaId());
        Forms form = optionalForm.get();
        form.setIsActive(false);
        formMongoRepository.save(form);
        forms.setIsActive(true);

        Forms _forms = formMongoRepository.save(forms);
        formList.setSchemaId(_forms.getId());
        formsMySQLRepository.save(formList);
        return _forms;
    }

    @Override
    @Transactional
    public void deleteForm(String id) {
        formMongoRepository.deleteById(id);
        formsMySQLRepository.deleteBySchemaId(id);
    }

    @Override
    @Transactional
    public void deleteFormByFormId(UUID formId) {
        Optional<FormList> optionalFormList = formsMySQLRepository.findById(formId);
        if (optionalFormList.isEmpty()) {
            throw new CommonErrorException("Form not found");
        }
        String schemaId = optionalFormList.get().getSchemaId();
        deleteForm(schemaId);
    }

    @Override
    @Transactional
    public Forms getForm(String id) {
        return formMongoRepository.findFormById(id).isEmpty() ? null : formMongoRepository.findFormById(id).get();
    }

    @Override
    public FormList getMySQLForm(String formId) {
        return formsMySQLRepository.findById(UUID.fromString(formId)).isPresent()
                ? formsMySQLRepository.findById(UUID.fromString(formId)).get()
                : null;
    }

    @Override
    public FormList getFormList(String formSchemaId) {
        Optional<FormList> formListOptional = formsMySQLRepository.findBySchemaId(formSchemaId);
        return formListOptional.isPresent() ? formListOptional.get() : null;
    }

    @Override
    public List<Forms> getAllForms() {
        return formMongoRepository.findAll();
    }

    @Override
    public Page<FormList> getALlFormsByFilter(FilterRequest filterRequest, Pageable pageable) {
        log.info("getALlFormsByFilter");

        Page<FormList> formListPage;
        if (filterRequest != null && filterRequest.getFilters().size() > 0) {
            FormListSpecification formSpecification = new FormListSpecification();
            for (Filter filterCriteria : filterRequest.getFilters()) {
                formSpecification.add(filterCriteria);
            }
            formListPage = formsMySQLRepository.findAll(formSpecification, pageable);
        } else {
            formListPage = formsMySQLRepository.findAll(pageable);
        }

        return formListPage;
    }
}
