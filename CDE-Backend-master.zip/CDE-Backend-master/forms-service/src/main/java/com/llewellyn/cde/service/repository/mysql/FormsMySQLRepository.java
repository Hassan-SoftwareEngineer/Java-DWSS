package com.llewellyn.cde.service.repository.mysql;

import com.llewellyn.cde.service.entity.mysql.FormList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;
import java.util.UUID;

public interface FormsMySQLRepository extends JpaRepository<FormList, UUID>, JpaSpecificationExecutor<FormList> {

    void deleteBySchemaId(String schemaId);

    Optional<FormList> findBySchemaId(String schemaId);
}
