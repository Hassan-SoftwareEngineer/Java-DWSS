package com.llewellyn.cde.pojo;

import lombok.Data;

@Data
public class PropertiesOptionsPojo {
    private String label;
    private String value;
}
