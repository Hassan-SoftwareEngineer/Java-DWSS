package com.llewellyn.cde.pojo;

import lombok.Data;

import java.util.List;

@Data
public class PageAnswers {
    private String pageName;
    private List<Answers> answersList;
}
