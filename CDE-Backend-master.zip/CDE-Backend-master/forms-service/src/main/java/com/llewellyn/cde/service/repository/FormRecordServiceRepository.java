package com.llewellyn.cde.service.repository;

import com.llewellyn.cde.service.entity.FormRecordDocument;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface FormRecordServiceRepository extends MongoRepository<FormRecordDocument, String> {

    List<FormRecordDocument> getFormRecordDocumentByQuestionFormId(String formId);

    List<FormRecordDocument> getFormRecordDocumentBySubmittedBy(String userId);

}
