package com.llewellyn.cde.specification;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.llewellyn.cde.service.entity.mysql.FormRecord;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormRecordSpecification implements Specification<FormRecord> {

    private List<Filter> filterList;

    public FormRecordSpecification() {
        this.filterList = new ArrayList<>();
    }

    public void add(Filter criteria) {
        filterList.add(criteria);
    }

    @Override
    public Predicate toPredicate(Root<FormRecord> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        // TODO Auto-generated method stub
        List<Predicate> predicates = new ArrayList<>();

        for (Filter criteria : filterList) {
            switch (criteria.getOperator()) {
                case "greater": {
                    predicates.add(criteriaBuilder.greaterThan(
                            root.get(criteria.getField()), criteria.getValue().toString()));
                    break;
                }
                case "less": {
                    predicates.add(criteriaBuilder.lessThan(
                            root.get(criteria.getField()), criteria.getValue().toString()));
                    break;
                }
                case "greater equal": {
                    predicates.add(criteriaBuilder.greaterThanOrEqualTo(
                            root.get(criteria.getField()), criteria.getValue().toString()));
                    break;
                }
                case "less equal": {
                    predicates.add(criteriaBuilder.lessThanOrEqualTo(
                            root.get(criteria.getField()), criteria.getValue().toString()));
                    break;
                }
                case "equal": {
                    predicates.add(criteriaBuilder.equal(
                            root.get(criteria.getField()), criteria.getValue()));
                    break;
                }
                case "not equal": {
                    predicates.add(criteriaBuilder.notEqual(
                            root.get(criteria.getField()), criteria.getValue()));
                    break;
                }
                case "match": {
                    predicates.add(criteriaBuilder.like(
                            criteriaBuilder.lower(root.get(criteria.getField())),
                            "%" + criteria.getValue().toString().toLowerCase() + "%"));
                    break;
                }
                case "match end": {
                    predicates.add(criteriaBuilder.like(
                            criteriaBuilder.lower(root.get(criteria.getField())),
                            criteria.getValue().toString().toLowerCase() + "%"));
                    break;
                }
                case "match start": {
                    predicates.add(criteriaBuilder.like(
                            criteriaBuilder.lower(root.get(criteria.getField())),
                            "%" + criteria.getValue().toString().toLowerCase()));
                    break;
                }
                case "in": {
                    if (criteria.getField().equals("id") || criteria.getField().equals("projectId")) {
                        List<UUID> tmpUUIDValue = new ArrayList<>();
                        String[] list = String.valueOf(criteria.getValue())
                                .replace("[", "")
                                .replace("]", "")
                                .split(", ");
                        log.info(list.toString());
                        for (String valueString : list) {
                            log.info(valueString);
                            tmpUUIDValue.add(UUID.fromString(valueString));
                        }
                        predicates.add(criteriaBuilder.in(root.get(criteria.getField())).value(tmpUUIDValue));
                    } else {
                        predicates.add(criteriaBuilder.in(root.get(criteria.getField())).value(criteria.getValue()));
                    }
                    break;
                }
                case "not in": {
                    predicates.add(criteriaBuilder.not(root.get(criteria.getField())).in(criteria.getValue()));
                    break;
                }
                default:
                    break;
            }
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

}
