package com.llewellyn.cde.controller;

import com.llewellyn.cde.commons.exception.CommonErrorException;
import com.llewellyn.cde.config.RequestValuesContainer;
import com.llewellyn.cde.exception.Errors;
import com.llewellyn.cde.pojo.FormsPojo;
import com.llewellyn.cde.service.FormService;
import com.llewellyn.cde.specification.FilterRequest;
import com.llewellyn.cde.utils.AppConstants;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/forms")
public class FormsController {

    private final FormService formService;
    private final RequestValuesContainer requestValuesContainer;

    public FormsController(FormService formService, RequestValuesContainer requestValuesContainer) {
        this.formService = formService;
        this.requestValuesContainer = requestValuesContainer;
    }

    @GetMapping()
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(formService.getAllForms());
    }

    @GetMapping("/{formId}")
    public ResponseEntity<?> getOneForm(@PathVariable String formId) {
        return ResponseEntity.ok(formService.getForm(formId));
    }

    @GetMapping("/formschema/{formSchemaId}")
    public ResponseEntity<?> getOneFormBySchemaId(@PathVariable String formSchemaId) {
        return ResponseEntity.ok(formService.getFormBySchemaId(formSchemaId));
    }

    @PostMapping("/filter")
    public ResponseEntity<?> getAllFormsByProjectFilter(@RequestBody(required = false) FilterRequest filterRequest,
            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize", defaultValue = AppConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = AppConstants.DEFAULT_SORT_BY, required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = AppConstants.DEFAULT_SORT_DIRECTION, required = false) String sortDir) {
        return ResponseEntity.ok(formService.getFilteredFormList(filterRequest, pageNo, pageSize, sortBy, sortDir));
    }

    @PutMapping("/{formId}")
    public ResponseEntity<?> updateForm(@PathVariable String formId, @Valid @RequestBody FormsPojo formsPojo) {
        return ResponseEntity.ok(formService.updateForm(formsPojo, formId));
    }

    @PutMapping("/{formId}/version/{versionId}")
    public ResponseEntity<?> updateFormVersion(@PathVariable String formId, @Valid @RequestBody FormsPojo formsPojo,
            @PathVariable String versionId) {
        return ResponseEntity.ok(formService.updateFormWithNewVersion(formsPojo, formId, versionId));
    }

    @DeleteMapping("/formschema/{formSchemaId}")
    public ResponseEntity<?> deleteFormBySchemaId(@PathVariable String formSchemaId) {
        formService.deleteForm(formSchemaId);
        return ResponseEntity.accepted().build();
    }

    @DeleteMapping("/form/{formId}")
    public ResponseEntity<?> deleteForm(@PathVariable UUID formId) {
        formService.deleteFormByFormId(formId);
        return ResponseEntity.accepted().build();
    }

    @PostMapping()
    public ResponseEntity<?> addForm(@Valid @RequestBody FormsPojo forms) {
        validateForm(forms);
        FormsPojo _forms = formService.saveForm(forms);
        return ResponseEntity.ok(_forms);
    }

    @PostMapping("/project/{projectId}")
    public ResponseEntity<?> addForm(@Valid @RequestBody FormsPojo forms, @PathVariable String projectId,
            @RequestHeader String userId, @RequestHeader String username) {
        validateForm(forms);
        requestValuesContainer.getRequestValues().put("userId", userId);
        requestValuesContainer.getRequestValues().put("username", username);
        if (StringUtils.isBlank((forms.getVersionNo()))) {
            forms.setVersionNo("1.0");
            forms.setIsActive(true);
        }
        FormsPojo _forms = formService.saveFormWithProjectId(forms, projectId);
        return ResponseEntity.ok(_forms);
    }

    private void validateForm(FormsPojo formsPojo) {
        if (formsPojo.getMobilePages() != formsPojo.getFormPage().size()) {
            throw new CommonErrorException(Errors.BAD_REQUEST_ON_PAGES);
        }
    }
}
