package com.llewellyn.cde.exception;

import com.llewellyn.cde.commons.exception.ErrorPrinter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

public enum Errors implements ErrorPrinter {

    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR, "000", null, "internal server error"),

    BAD_REQUEST_ON_PAGES(HttpStatus.BAD_REQUEST, "004", null, "Number of pages should be equal to pages available in list"),
    BAD_REQUEST_COUNT_NOT_MATCH(HttpStatus.BAD_REQUEST, "005", null, "Number of required questions and answers does not match."),

    INTERNAL_SERVER_ERROR_WITH_DESC(HttpStatus.INTERNAL_SERVER_ERROR, "000", null, "{0}"),
    BAD_REQUEST_ERROR_WITH_DESC(HttpStatus.BAD_REQUEST, "000", null, "{0}"),

    INVALID_REQUEST_PARAM(HttpStatus.BAD_REQUEST, "001", "400",
            "invalid/missing mandatory request parameter");

    private final HttpStatus httpStatus;
    private final String description;
    private final String externalErrorCode;
    private final String errorCode;

    Errors(HttpStatus httpStatus, String errorCode, String externalErrorCode,
           String description) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.externalErrorCode = externalErrorCode;
        this.description = description;
    }

    public static Errors fromString(String text) {
        for (Errors e : Errors.values()) {
            if (StringUtils.isNotBlank(e.getExternalErrorCode())) {
                if (e.externalErrorCode.equalsIgnoreCase(text)) {
                    return e;
                }
            }
        }
        return null;
    }

    @Override
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Override
    public String getErrorCode() {
        return errorCode;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getExternalErrorCode() {
        return externalErrorCode;
    }
}