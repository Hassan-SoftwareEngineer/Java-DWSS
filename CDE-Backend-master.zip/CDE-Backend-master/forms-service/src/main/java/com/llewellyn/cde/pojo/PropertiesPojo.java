package com.llewellyn.cde.pojo;

import lombok.Data;

import java.util.List;

@Data
public class PropertiesPojo {
    private String name;
    private String type;
    private String label;
    private Boolean required;
    private List<PropertiesOptionsPojo> options;

}
