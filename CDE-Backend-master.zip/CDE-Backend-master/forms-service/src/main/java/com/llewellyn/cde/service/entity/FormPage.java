package com.llewellyn.cde.service.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document
public class FormPage {
    private String name;
    private String title;
    private String subtitle;
    private Questions questions;
}
