package com.llewellyn.cde.approvalservice.dto.request;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.TargetTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivityTargetRequestDto {

    private UUID activityTargetId;
    private TargetTypeEnum targetType;
    private UUID targetUserId;
    private UUID targetGroupId;
    private UUID targetRoleId;
    
}
