package com.llewellyn.cde.approvalservice.model;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.llewellyn.cde.approvalservice.dto.TargetTypeEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cde_approval_request_user")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestUser {
    
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "approval_request_user_id")
    private UUID approvalRequestUserId;

    @Column(name = "request_id")
    private UUID requestId;

    @Column(name = "target_type")
    @Enumerated(EnumType.STRING)
    private TargetTypeEnum targetType;

    @Column(name = "user_group_id")
    private UUID user_group_id;

    @Column(name = "user")
    private UUID userId;

    @Column(name = "active")
    private boolean isActive;

    @Column(name = "completed")
    private boolean isCompleted;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "approval_request", nullable = false)
    private ApprovalRequest approvalRequest;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
