package com.llewellyn.cde.approvalservice.service;

import java.util.Optional;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.llewellyn.cde.approvalservice.dto.request.ActionRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ActionTargetRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ActivityRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ActivityTargetRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ProcessRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.StateRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.TransitionRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ProcessDto;
// import com.llewellyn.cde.approvalservice.dto.response.StateDto;
// import com.llewellyn.cde.approvalservice.dto.response.TransitionDto;
import com.llewellyn.cde.approvalservice.model.Action;
import com.llewellyn.cde.approvalservice.model.ActionTarget;
import com.llewellyn.cde.approvalservice.model.Activity;
import com.llewellyn.cde.approvalservice.model.ActivityTarget;
import com.llewellyn.cde.approvalservice.model.Process;
import com.llewellyn.cde.approvalservice.model.State;
import com.llewellyn.cde.approvalservice.model.Transition;
import com.llewellyn.cde.approvalservice.repository.ProcessRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessServiceImp implements ProcessService {

    @Autowired
    private ProcessRepository processRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ProcessDto createNewProcess(ProcessRequestDto processRequestDto) {
        // TODO Auto-generated method stub
        log.info("Create New Process");

        Process newProcess = this.dtoToProcess(processRequestDto);

        newProcess = processRepository.save(newProcess);

        return this.processToDto(newProcess);
    }

    @Override
    public ProcessDto getProcessDtoById(UUID processId) {
        // TODO Auto-generated method stub
        log.info("Get One Process DTO By ID: {}", processId.toString());

        Optional<Process> optionalProcess = processRepository.findById(processId);
        if (!optionalProcess.isPresent()) {
            // throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        return this.processToDto(optionalProcess.get());
    }

    @Override
    public Process getProcessById(UUID processId) {
        // TODO Auto-generated method stub
        log.info("Get One Process By ID: {}", processId.toString());

        Optional<Process> optionalProcess = processRepository.findById(processId);
        if (!optionalProcess.isPresent()) {
            // throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        return optionalProcess.get();
    }

    
    @Override
    public ProcessDto getProcessDtoByFormId(UUID formId) {
        // TODO Auto-generated method stub
        log.info("Get One Process DTO By Form ID: {}", formId.toString());

        Optional<Process> optionalProcess = processRepository.findByFormId(formId);
        if (!optionalProcess.isPresent()) {
            // throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        return this.processToDto(optionalProcess.get());
    }

    @Override
    public Process getProcessByFormId(UUID formId) {
        // TODO Auto-generated method stub
        log.info("Get One Process By Form ID: {}", formId.toString());

        Optional<Process> optionalProcess = processRepository.findByFormId(formId);
        if (!optionalProcess.isPresent()) {
            // throw new CommonErrorException(Errors.INVALID_PROJECT);
        }

        return optionalProcess.get();
    }

    @Override
    public State findStateById(UUID stateId) {
        // TODO Auto-generated method stub
        log.info("Get One State By ID: {}", stateId.toString());

        Optional<Process> optionalProcess = processRepository.findById(stateId);
        if (!optionalProcess.isPresent()) {
            // throw new CommonErrorException(Errors.INVALID_PROJECT);
        }
        return null;
    }

    @Override
    public ProcessDto addStateInProcess(UUID processId, StateRequestDto stateRequestDto) {
        // TODO Auto-generated method stub
        log.info("Add State in Process ID {}", processId.toString());
        Process targetProcess = this.getProcessById(processId);

        State newState = this.dtoToState(stateRequestDto);
        targetProcess.addState(newState);

        processRepository.save(targetProcess);

        return this.getProcessDtoById(processId);
    }

    @Override
    public ProcessDto removeStateInProcess(UUID processId, UUID stateId) {
        // TODO Auto-generated method stub
        log.info("Remove State ({}) in Process ID {}", stateId.toString(), processId.toString());
        throw new UnsupportedOperationException("Unimplemented method 'removeStateInProcess'");
    }

    @Override
    public Transition findTransitionById(UUID transitionId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findTransitionById'");
    }

    @Override
    public ProcessDto addTransitionInProcess(UUID processId, TransitionRequestDto transitionRequestDto) {
        // TODO Auto-generated method stub
        log.info("Add Transition in Process ID {}", processId.toString());
        Process targetProcess = this.getProcessById(processId);

        Transition newTransition = this.dtoToTransition(transitionRequestDto);

        for (int i = 0; i < targetProcess.getStates().size(); i++) {
            State currentItem = targetProcess.getStates().get(i);
            if (currentItem.getStateId().equals(transitionRequestDto.getCurrentStateId())) {
                newTransition.setCurrentState(currentItem);
            }

            if (currentItem.getStateId().equals(transitionRequestDto.getNextStateId())) {
                newTransition.setNextState(currentItem);
            }
        }

        targetProcess.addTransition(newTransition);

        processRepository.save(targetProcess);

        return this.getProcessDtoById(processId);
    }

    @Override
    public ProcessDto removeTransitionInProcess(UUID processId, UUID transitionId) {
        // TODO Auto-generated method stub
        log.info("Remove Transition ({}) in Process ID {}", transitionId.toString(), processId.toString());
        throw new UnsupportedOperationException("Unimplemented method 'removeTransitionInProcess'");
    }

    @Override
    public ProcessDto addActionInTransition(UUID processId, UUID transitionId, ActionRequestDto actionRequestDto) {
        // TODO Auto-generated method stub
        log.info("Add Action in Transaction ID {}", transitionId.toString());
        Process targetProcess = this.getProcessById(processId);

        Action newAction = this.dtoToAction(actionRequestDto);
        newAction.setProcess(targetProcess);

        for (int i = 0; i < actionRequestDto.getActionTargets().size(); i++) {
            log.info("Add item {}", i);
            ActionTarget actionTarget = this.dtoToActionTarget(actionRequestDto.getActionTargets().get(i));
            log.info("Action target {}", actionTarget.getTargetType());
            log.info("Action target size {}", newAction.getActionTargets().size());
            newAction.addActionTarget(actionTarget);
        }

        for (int i = 0; i < targetProcess.getTransitions().size(); i++) {
            Transition currentItem = targetProcess.getTransitions().get(i);
            if (currentItem.getTransitionId().equals(transitionId)) {
                currentItem.addAction(newAction);
                break;
            }
        }

        processRepository.save(targetProcess);

        return this.getProcessDtoById(processId);
    }

    @Override
    public ProcessDto removeActionInTransition(UUID processId, UUID transitionId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'removeActionInTransition'");
    }

    @Override
    public ProcessDto addActivityInTransition(UUID processId, UUID transitionId,
            ActivityRequestDto activityRequestDto) {
        // TODO Auto-generated method stub
        log.info("Add Activity in Transaction ID {}", transitionId.toString());
        Process targetProcess = this.getProcessById(processId);
        
        Activity newActivity = this.dtoToActivity(activityRequestDto);
        newActivity.setProcess(targetProcess);

        for (int i = 0; i < activityRequestDto.getActivityTargets().size(); i++) {
            log.info("Add item {}", i);
            ActivityTarget activityTarget = this.dtoToActivityTarget(activityRequestDto.getActivityTargets().get(i));
            newActivity.addActivityTarget(activityTarget);
        }

        for (int i = 0; i < targetProcess.getTransitions().size(); i++) {
            Transition currentItem = targetProcess.getTransitions().get(i);
            if (currentItem.getTransitionId().equals(transitionId)) {
                currentItem.addActivity(newActivity);
                break;
            }
        }

        processRepository.save(targetProcess);

        return this.getProcessDtoById(processId);
    }

    @Override
    public ProcessDto removeActivityInTransition(UUID processId, UUID transitionId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'removeActivityInTransition'");
    }

    private Process dtoToProcess(ProcessRequestDto processRequestDto) {
        Process process = modelMapper.map(processRequestDto, Process.class);
        return process;
    }

    private ProcessDto processToDto(Process process) {
        ProcessDto processDto = modelMapper.map(process, ProcessDto.class);
        return processDto;
    }

    private State dtoToState(StateRequestDto stateRequestDto) {
        State state = modelMapper.map(stateRequestDto, State.class);
        return state;
    }

    // private StateDto stateToDto(State state) {
    //     StateDto stateDto = modelMapper.map(state, StateDto.class);
    //     return stateDto;
    // }

    private Transition dtoToTransition(TransitionRequestDto transitionRequestDto) {
        // Transition transition = modelMapper.map(transitionRequestDto,
        // Transition.class);
        Transition transition = new Transition();
        transition.setName(transitionRequestDto.getName());
        transition.setDescription(transitionRequestDto.getDescription());
        return transition;
    }

    // private TransitionDto transitionToDto(Transition transition) {
    //     TransitionDto transitionDto = modelMapper.map(transition, TransitionDto.class);
    //     return transitionDto;
    // }

    private Action dtoToAction(ActionRequestDto actionRequestDto) {
        Action action = new Action();
        action.setName(actionRequestDto.getName());
        action.setDescription(actionRequestDto.getDescription());
        action.setActionType(actionRequestDto.getActionType());
        return action;
    }

    private ActionTarget dtoToActionTarget(ActionTargetRequestDto actionTargetRequestDto) {
        ActionTarget actionTarget = new ActionTarget();
        actionTarget.setTargetType(actionTargetRequestDto.getTargetType());
        actionTarget.setTargetUserId(actionTargetRequestDto.getTargetUserId());
        actionTarget.setTargetGroupId(actionTargetRequestDto.getTargetGroupId());
        actionTarget.setTargetRoleId(actionTargetRequestDto.getTargetRoleId());
        actionTarget.setOr(actionTargetRequestDto.isOr());
        return actionTarget;
    }

    private Activity dtoToActivity(ActivityRequestDto activityRequestDto) {
        Activity activity = new Activity();
        activity.setName(activityRequestDto.getName());
        activity.setDescription(activityRequestDto.getDescription());
        activity.setActivityType(activityRequestDto.getActivityType());
        return activity;
    }

    private ActivityTarget dtoToActivityTarget(ActivityTargetRequestDto activityTargetRequestDto) {
        ActivityTarget activityTarget = new ActivityTarget();
        activityTarget.setTargetType(activityTargetRequestDto.getTargetType());
        activityTarget.setTargetUserId(activityTargetRequestDto.getTargetUserId());
        activityTarget.setTargetGroupId(activityTargetRequestDto.getTargetGroupId());
        activityTarget.setTargetRoleId(activityTargetRequestDto.getTargetRoleId());
        return activityTarget;
    }

}
