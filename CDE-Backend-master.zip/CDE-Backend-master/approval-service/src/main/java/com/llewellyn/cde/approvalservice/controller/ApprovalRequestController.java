package com.llewellyn.cde.approvalservice.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.llewellyn.cde.approvalservice.config.RequestValuesContainer;
import com.llewellyn.cde.approvalservice.dto.request.ApprovalRequestCreateDto;
import com.llewellyn.cde.approvalservice.dto.request.ApprovalRequestSubmitDto;
import com.llewellyn.cde.approvalservice.dto.response.ActionFormRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ApprovalRequestDto;
import com.llewellyn.cde.approvalservice.model.Process;
import com.llewellyn.cde.approvalservice.service.ApprovalRequestServiceImp;
import com.llewellyn.cde.approvalservice.service.ProcessServiceImp;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/v1/approval")
public class ApprovalRequestController {

        @Autowired
        private ProcessServiceImp processServiceImp;

        @Autowired
        private ApprovalRequestServiceImp approvalRequestServiceImp;

        @Autowired
        private RequestValuesContainer requestValuesContainer;

        @PostMapping("/request/{request_id}")
        public ResponseEntity<List<ApprovalRequestDto>> createNewApprovalRequest(
                        @PathVariable UUID request_id,
                        @Valid @RequestBody ApprovalRequestCreateDto approvalRequestCreateDto) {
                log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

                requestValuesContainer.getRequestValues().put("userId",
                                approvalRequestCreateDto.getSubmittedByUserId().toString());

                Process process = processServiceImp.getProcessByFormId(approvalRequestCreateDto.getFormId());

                List<ApprovalRequestDto> approvalRequestList = approvalRequestServiceImp.createNewApprovalRequest(
                                request_id,
                                process);

                return ResponseEntity.ok(approvalRequestList);
        }

        @GetMapping("/request/{request_id}")
        public ResponseEntity<List<ApprovalRequestDto>> getApprovalRequestListByRequestId(
                        @PathVariable UUID request_id) {
                log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

                List<ApprovalRequestDto> approvalRequestDtos = approvalRequestServiceImp
                                .getAllApprovalRequestByRequestId(request_id);

                return ResponseEntity.ok(approvalRequestDtos);
        }

        @PostMapping("/request/{request_id}/submit")
        public ResponseEntity<List<ApprovalRequestDto>> submitApprovalRequest(
                        @PathVariable UUID request_id,
                        @Valid @RequestBody ApprovalRequestSubmitDto approvalRequestSubmitDto,
                        @RequestHeader String userId, @RequestHeader String username) {
                log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

                requestValuesContainer.getRequestValues().put("userId", userId);
                requestValuesContainer.getRequestValues().put("username", username);

                Process process = processServiceImp.getProcessByFormId(approvalRequestSubmitDto.getFormId());

                List<ApprovalRequestDto> approvalRequestList = approvalRequestServiceImp.submitApprovalAction(
                                request_id,
                                process, approvalRequestSubmitDto.getActionId());

                return ResponseEntity.ok(approvalRequestList);
        }

        @GetMapping("/user/{user_id}/pending")
        public ResponseEntity<List<UUID>> getPendingRequestIdList(
                        @RequestParam(value = "pageNo", defaultValue = "0", required = false) int pageNo,
                        @RequestParam(value = "pageSize", defaultValue = "20", required = false) int pageSize,
                        @PathVariable UUID user_id) {
                log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

                List<UUID> actionFormRequestList = approvalRequestServiceImp.getAllPendingApprovalRequestId(user_id,
                                pageNo,
                                pageSize);

                return ResponseEntity.ok(actionFormRequestList);
        }

        @GetMapping("/request/{request_id}/user/{user_id}")
        public ResponseEntity<List<ActionFormRequestDto>> getRequestUserAction(@PathVariable UUID request_id,
                        @PathVariable UUID user_id) {
                log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

                List<ActionFormRequestDto> actionFormRequestList = approvalRequestServiceImp
                                .getAllPendingApprovalActionByUser(user_id, request_id);

                return ResponseEntity.ok(actionFormRequestList);
        }

}
