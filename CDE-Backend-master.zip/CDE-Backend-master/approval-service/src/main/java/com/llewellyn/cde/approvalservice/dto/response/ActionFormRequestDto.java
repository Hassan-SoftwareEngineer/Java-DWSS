package com.llewellyn.cde.approvalservice.dto.response;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.ActionTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActionFormRequestDto {

    private UUID requestId;
    private UUID formId;
    private UUID actionId;
    private ActionTypeEnum actionType;

}
