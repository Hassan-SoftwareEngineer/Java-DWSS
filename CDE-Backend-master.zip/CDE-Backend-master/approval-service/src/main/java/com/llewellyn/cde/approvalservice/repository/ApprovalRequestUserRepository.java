package com.llewellyn.cde.approvalservice.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.approvalservice.model.ApprovalRequestUser;

public interface ApprovalRequestUserRepository extends JpaRepository<ApprovalRequestUser, UUID> {

    List<ApprovalRequestUser> findAllByUserIdAndRequestIdAndIsActive(UUID userId, UUID requestId, boolean isActive);

    Page<ApprovalRequestUser> findAllByUserIdAndIsActive(UUID userId, boolean isActive, Pageable pageable);
}
