package com.llewellyn.cde.approvalservice.dto.request;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransitionRequestDto {
    
    private UUID currentStateId;
    private UUID nextStateId;
    private String name;
    private String description;

}
