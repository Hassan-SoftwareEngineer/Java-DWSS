package com.llewellyn.cde.approvalservice.model;

import java.util.UUID;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.llewellyn.cde.approvalservice.dto.TargetTypeEnum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cde_action_target")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActionTarget {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "action_target_id")
    private UUID actionTargetId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "action", nullable = false)
    private Action action;

    @Column(name = "target_type")
    @Enumerated(EnumType.STRING)
    private TargetTypeEnum targetType;

    @Column(name = "target_user_id")
    private UUID targetUserId;

    @Column(name = "target_group_id")
    private UUID targetGroupId;

    @Column(name = "target_role_id")
    private UUID targetRoleId;

    @Column(name = "isOr")
    private boolean isOr;
    
}
