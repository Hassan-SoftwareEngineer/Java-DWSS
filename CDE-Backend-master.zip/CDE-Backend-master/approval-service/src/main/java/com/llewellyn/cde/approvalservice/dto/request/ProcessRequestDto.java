package com.llewellyn.cde.approvalservice.dto.request;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.ProcessTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessRequestDto {

    private String name;
    private UUID formId;
    private ProcessTypeEnum processType;
    
}
