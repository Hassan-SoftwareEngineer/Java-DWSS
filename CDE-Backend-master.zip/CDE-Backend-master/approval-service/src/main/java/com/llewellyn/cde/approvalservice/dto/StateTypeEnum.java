package com.llewellyn.cde.approvalservice.dto;

public enum StateTypeEnum {
    START, PROGRESS, APPROVED, REJECTED
}
