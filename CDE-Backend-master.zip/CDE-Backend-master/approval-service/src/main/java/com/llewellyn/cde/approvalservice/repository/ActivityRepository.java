package com.llewellyn.cde.approvalservice.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.approvalservice.model.Activity;

public interface ActivityRepository extends JpaRepository<Activity, UUID> {

}
