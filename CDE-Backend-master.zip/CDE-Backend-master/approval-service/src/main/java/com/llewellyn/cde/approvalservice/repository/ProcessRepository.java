package com.llewellyn.cde.approvalservice.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.approvalservice.model.Process;

public interface ProcessRepository extends JpaRepository<Process, UUID> {

    Optional<Process> findByFormId(UUID formId);

}
