package com.llewellyn.cde.approvalservice.feign.form;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.llewellyn.cde.approvalservice.feign.form.requestDto.ApprovalProcessSubmitDto;
import com.llewellyn.cde.approvalservice.feign.form.responseDto.FormRecordDto;


@FeignClient(name = "form-service", value = "form-service")
public interface FormServiceFeignClient {

    @PutMapping("/api/v1/form-record/header/{formRecordId}")
    FormRecordDto updateFormRecordStatusByReferenceCode(
            @PathVariable("formRecordId") UUID formRecordId,
            @RequestBody ApprovalProcessSubmitDto approvalProcessSubmitDto);

}
