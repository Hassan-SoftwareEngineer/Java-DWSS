package com.llewellyn.cde.approvalservice.dto.request;

import java.util.List;

import com.llewellyn.cde.approvalservice.dto.ActionTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActionRequestDto {
    
    private ActionTypeEnum actionType;
    private String name;
    private String description;
    private List<ActionTargetRequestDto> actionTargets;

}
