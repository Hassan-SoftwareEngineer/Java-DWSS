package com.llewellyn.cde.approvalservice.feign.form.responseDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormRecordDto {
    private String id;
    private String formName;
    private String formCode;
}
