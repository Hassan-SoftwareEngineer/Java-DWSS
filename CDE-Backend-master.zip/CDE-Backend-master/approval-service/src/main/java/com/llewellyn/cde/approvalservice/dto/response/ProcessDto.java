package com.llewellyn.cde.approvalservice.dto.response;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.ProcessTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessDto {
    
    private UUID processId;
    private String name;
    private ProcessTypeEnum processType;
    private UUID formId;
    private List<StateDto> states;
    private List<TransitionDto> transitions;
    private LocalDateTime createdDate;
    private LocalDateTime updatedAt;
    
}
