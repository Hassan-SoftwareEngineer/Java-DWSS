package com.llewellyn.cde.approvalservice.dto;

public enum ProcessTypeEnum {
    Form,
}
