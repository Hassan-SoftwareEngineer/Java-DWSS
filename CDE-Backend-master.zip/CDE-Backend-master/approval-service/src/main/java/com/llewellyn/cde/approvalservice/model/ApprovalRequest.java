package com.llewellyn.cde.approvalservice.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cde_approval_request")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequest {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "approval_request_id")
    private UUID approvalRequestId;

    @Column(name = "request_id")
    private UUID requestId;

    @Column(name = "form_id")
    private UUID formId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "action")
    private Action action;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "transition", nullable = false)
    private Transition transition;

    @OneToMany(mappedBy = "approvalRequest", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ApprovalRequestUser> approvalRequestUsers = new ArrayList<>();
    
    @Column(name = "active")
    private boolean isActive;

    @Column(name = "completed")
    private boolean isCompleted;

    @Column(name = "form_submitted_by")
    private UUID formSubmittedby;

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    @OrderBy("createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public void addApprovalRequestUser(ApprovalRequestUser item) {
        approvalRequestUsers.add(item);
        item.setApprovalRequest(this);
    }

    public void removeApprovalRequestUser(ApprovalRequestUser item) {
        approvalRequestUsers.remove(item);
        item.setApprovalRequest(null);
    }
    
}
