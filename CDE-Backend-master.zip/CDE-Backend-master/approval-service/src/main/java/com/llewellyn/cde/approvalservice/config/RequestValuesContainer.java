package com.llewellyn.cde.approvalservice.config;

import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.common.collect.Maps;

import jakarta.annotation.PostConstruct;
import lombok.Getter;

@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestValuesContainer {

    @Getter
    private Map<String, String> requestValues;

    @PostConstruct
    public void init() {
        requestValues = Maps.newHashMap();
    }
}
