package com.llewellyn.cde.approvalservice.dto;

public enum ActivityTypeEnum {
    EMAIL, SMS, PUSH_NOTIFICATION,
}
