package com.llewellyn.cde.approvalservice.controller;

import java.net.URI;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.llewellyn.cde.approvalservice.dto.request.ActionRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ActivityRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ProcessRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.StateRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.TransitionRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ProcessDto;
import com.llewellyn.cde.approvalservice.service.ProcessServiceImp;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/v1/process")
public class ProcessController {

    @Autowired
    private ProcessServiceImp processServiceImp;

    @PostMapping()
    public ResponseEntity<ProcessDto> createNewProcess(@Valid @RequestBody ProcessRequestDto processRequestDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto newProcess = processServiceImp.createNewProcess(processRequestDto);

        URI locationUri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(newProcess.getProcessId()).toUri();

        return ResponseEntity.created(locationUri).body(newProcess);
    }

    @GetMapping("/{process_id}")
    public ResponseEntity<ProcessDto> getOneProcessById(@PathVariable UUID process_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.getProcessDtoById(process_id);

        return ResponseEntity.ok(processDto);
    }

    @GetMapping("/form/{form_id}")
    public ResponseEntity<ProcessDto> getOneProcessByFormId(@PathVariable UUID form_id) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.getProcessDtoByFormId(form_id);

        return ResponseEntity.ok(processDto);
    }

    @PostMapping("/{process_id}/state")
    public ResponseEntity<ProcessDto> addNewState(@PathVariable UUID process_id,
            @Valid @RequestBody StateRequestDto stateRequestDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.addStateInProcess(process_id, stateRequestDto);

        return ResponseEntity.ok(processDto);
    }

    @PostMapping("/{process_id}/transition")
    public ResponseEntity<ProcessDto> addNewTransition(@PathVariable UUID process_id,
            @Valid @RequestBody TransitionRequestDto transitionRequestDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.addTransitionInProcess(process_id, transitionRequestDto);

        return ResponseEntity.ok(processDto);
    }

    @PostMapping("/{process_id}/transition/{transition_id}/action")
    public ResponseEntity<ProcessDto> addNewAction(@PathVariable UUID process_id,
            @PathVariable UUID transition_id,
            @Valid @RequestBody ActionRequestDto actionRequestDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.addActionInTransition(process_id, transition_id, actionRequestDto);

        return ResponseEntity.ok(processDto);
    }

    @PostMapping("/{process_id}/transition/{transition_id}/activity")
    public ResponseEntity<ProcessDto> addNewActivity(@PathVariable UUID process_id,
            @PathVariable UUID transition_id,
            @Valid @RequestBody ActivityRequestDto activityRequestDto) {
        log.info(ServletUriComponentsBuilder.fromCurrentRequest().toUriString());

        ProcessDto processDto = processServiceImp.addActivityInTransition(process_id, transition_id, activityRequestDto);

        return ResponseEntity.ok(processDto);
    }
}
