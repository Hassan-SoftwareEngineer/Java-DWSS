package com.llewellyn.cde.approvalservice.dto.response;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.StateTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StateDto {
    
    private UUID stateId;
    private StateTypeEnum stateType;
    private String name;
    private String description;

}
