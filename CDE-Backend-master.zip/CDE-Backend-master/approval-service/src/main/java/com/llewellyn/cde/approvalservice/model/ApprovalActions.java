package com.llewellyn.cde.approvalservice.model;

public class ApprovalActions {
    
}
