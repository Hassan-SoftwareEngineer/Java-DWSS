package com.llewellyn.cde.approvalservice.dto.request;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.ProcessTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestSubmitDto {

    private ProcessTypeEnum processType;
    private UUID formId;
    private UUID actionId;
    
}
