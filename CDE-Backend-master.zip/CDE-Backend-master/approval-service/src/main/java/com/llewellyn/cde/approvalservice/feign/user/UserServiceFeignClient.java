package com.llewellyn.cde.approvalservice.feign.user;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.llewellyn.cde.approvalservice.feign.user.responseDto.UserDto;

@FeignClient(name = "user-service", value = "user-service")
public interface UserServiceFeignClient {

    @GetMapping("api/v1/user/{user_id}")
    UserDto getOneUserDetails(@PathVariable("user_id") UUID user_id);
    
}
