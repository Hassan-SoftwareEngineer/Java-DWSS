package com.llewellyn.cde.approvalservice.dto.response;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.llewellyn.cde.approvalservice.model.ApprovalRequestUser;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestDto {
    
    private UUID approvalRequestId;
    private UUID requestId;
    private UUID formId;
    private ActionDto action;
    private TransitionDto transition;
    private List<ApprovalRequestUser> approvalRequestUsers = new ArrayList<>();
    private boolean isActive;
    private boolean isCompleted;
    
}
