package com.llewellyn.cde.approvalservice.dto;

public enum ActionTypeEnum {
    APPROVE, REJECT
}
