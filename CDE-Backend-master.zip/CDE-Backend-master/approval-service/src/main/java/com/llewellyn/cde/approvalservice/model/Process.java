package com.llewellyn.cde.approvalservice.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import com.llewellyn.cde.approvalservice.dto.ProcessTypeEnum;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cde_process")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Process {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "process_id")
    private UUID processId;

    @Column(name = "name")
    private String name;

    @Column(name = "process_type")
    @Enumerated(EnumType.STRING)
    private ProcessTypeEnum processType;

    @Column(name = "form_id")
    private UUID formId;

    @OneToMany(mappedBy = "process", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<State> states = new ArrayList<>();

    @OneToMany(mappedBy = "process", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Transition> transitions = new ArrayList<>();

    @Column(name = "created_at", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public void addState(State item) {
        states.add(item);
        item.setProcess(this);
    }

    public void removeState(State item) {
        states.remove(item);
        item.setProcess(null);
    }

    public void addTransition(Transition item) {
        transitions.add(item);
        item.setProcess(this);
    }

    public void removeTransition(Transition item) {
        transitions.remove(item);
        item.setProcess(null);
    }
    
}
