package com.llewellyn.cde.approvalservice.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.approvalservice.model.Action;
import com.llewellyn.cde.approvalservice.model.ApprovalRequest;

public interface ApprovalRequestRepository extends JpaRepository<ApprovalRequest, UUID> {

    List<ApprovalRequest> findAllByRequestIdOrderByCreatedAtDesc(UUID requestId);

    ApprovalRequest findByRequestIdAndAction(UUID requestId, Action action);

    Optional<ApprovalRequest> findTopByRequestIdOrderByCreatedAtAsc(UUID requestId);

}
