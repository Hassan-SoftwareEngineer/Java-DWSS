package com.llewellyn.cde.approvalservice.dto;

public enum TargetTypeEnum {
    // Approval Requester
    REQ,
    // Direct Manager
    DM, 
    // Target User
    U, 
    // Group Manager
    GM,
}
