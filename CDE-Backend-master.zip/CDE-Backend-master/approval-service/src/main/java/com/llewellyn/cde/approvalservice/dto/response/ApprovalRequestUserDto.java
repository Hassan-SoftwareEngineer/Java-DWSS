package com.llewellyn.cde.approvalservice.dto.response;

import java.time.LocalDateTime;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalRequestUserDto {
    
    private UUID approvalRequestUserId;
    private UUID requestId;
    private UUID userId;
    private ApprovalRequestDto approvalRequest;
    private boolean isActive;
    private boolean isCompleted;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

}
