package com.llewellyn.cde.approvalservice.service;

import java.util.List;
import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.response.ActionFormRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ApprovalRequestDto;
import com.llewellyn.cde.approvalservice.model.Process;

public interface ApprovalRequestService {

    List<ApprovalRequestDto> createNewApprovalRequest(UUID requestId, Process process);

    List<ApprovalRequestDto> getAllApprovalRequestByRequestId(UUID requestId);

    List<ApprovalRequestDto> submitApprovalAction(UUID requestId, Process process, UUID actionId);

    List<ActionFormRequestDto> getAllPendingApprovalActionByUser(UUID userId, UUID requestId);

    List<UUID> getAllPendingApprovalRequestId(UUID userId, int pageNo, int pageSize);

}
