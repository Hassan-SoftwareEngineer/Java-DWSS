package com.llewellyn.cde.approvalservice.dto.request;

import com.llewellyn.cde.approvalservice.dto.StateTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StateRequestDto {
    
    private StateTypeEnum stateType;
    private String name;
    private String description;
}
