package com.llewellyn.cde.approvalservice.service;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.request.ActionRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ActivityRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.ProcessRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.StateRequestDto;
import com.llewellyn.cde.approvalservice.dto.request.TransitionRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ProcessDto;
import com.llewellyn.cde.approvalservice.model.Process;
import com.llewellyn.cde.approvalservice.model.State;
import com.llewellyn.cde.approvalservice.model.Transition;

public interface ProcessService {

    ProcessDto createNewProcess(ProcessRequestDto processRequestDto);

    ProcessDto getProcessDtoById(UUID processId);

    Process getProcessById(UUID processId);

    ProcessDto getProcessDtoByFormId(UUID formId);

    Process getProcessByFormId(UUID formId);

    State findStateById(UUID stateId);

    ProcessDto addStateInProcess(UUID processId, StateRequestDto stateRequestDto);

    ProcessDto removeStateInProcess(UUID processId, UUID stateId);

    Transition findTransitionById(UUID transitionId);

    ProcessDto addTransitionInProcess(UUID processId, TransitionRequestDto transitionRequestDto);

    ProcessDto removeTransitionInProcess(UUID processId, UUID transitionId);

    ProcessDto addActionInTransition(UUID processId, UUID transitionId, ActionRequestDto actionRequestDto);

    ProcessDto removeActionInTransition(UUID processId, UUID transitionId);

    ProcessDto addActivityInTransition(UUID processId, UUID transitionId, ActivityRequestDto activityRequestDto);

    ProcessDto removeActivityInTransition(UUID processId, UUID transitionId);
    
}
