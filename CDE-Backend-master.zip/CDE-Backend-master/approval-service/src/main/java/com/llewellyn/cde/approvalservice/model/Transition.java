package com.llewellyn.cde.approvalservice.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cde_transition")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transition {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "transition_id")
    private UUID transitionId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "process", nullable = false)
    private Process process;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "current_state", nullable = false)
    private State currentState;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "next_state", nullable = false)
    private State nextState;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "transition", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Action> actions = new ArrayList<>();;

    @OneToMany(mappedBy = "transition", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Activity> activities = new ArrayList<>();;

    public void addAction(Action item) {
        actions.add(item);
        item.setTransition(this);
    }

    public void removeAction(Action item) {
        actions.remove(item);
        item.setTransition(null);
    }

    public void addActivity(Activity item) {
        activities.add(item);
        item.setTransition(this);
    }

    public void removeActivity(Activity item) {
        activities.remove(item);
        item.setTransition(null);
    }
}
