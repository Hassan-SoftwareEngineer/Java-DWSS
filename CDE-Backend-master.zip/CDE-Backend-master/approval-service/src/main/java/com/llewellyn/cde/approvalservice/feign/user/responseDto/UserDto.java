package com.llewellyn.cde.approvalservice.feign.user.responseDto;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private UUID id;
    private String email;
    private String username;
    private String firstname;
    private String lastname;
    private String directReport;

}
