package com.llewellyn.cde.approvalservice.dto.response;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivityDto {
    
    private UUID activityId;
    private String name;
    private String description;
    private List<ActivityTargetDto> activityTargets = new ArrayList<>();

}
