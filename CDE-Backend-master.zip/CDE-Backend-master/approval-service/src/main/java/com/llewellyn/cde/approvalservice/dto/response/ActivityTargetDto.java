package com.llewellyn.cde.approvalservice.dto.response;

import java.util.UUID;

import com.llewellyn.cde.approvalservice.dto.TargetTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivityTargetDto {

    private UUID activityTargetId;
    private TargetTypeEnum targetType;
    private UUID targetUserId;
    private UUID targetGroupId;
    private UUID targetRoleId;

}
