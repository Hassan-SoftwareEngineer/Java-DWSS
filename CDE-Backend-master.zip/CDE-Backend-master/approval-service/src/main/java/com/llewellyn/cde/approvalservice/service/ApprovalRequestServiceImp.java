package com.llewellyn.cde.approvalservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.llewellyn.cde.approvalservice.config.RequestValuesContainer;
import com.llewellyn.cde.approvalservice.dto.StateTypeEnum;
import com.llewellyn.cde.approvalservice.dto.TargetTypeEnum;
import com.llewellyn.cde.approvalservice.dto.response.ActionFormRequestDto;
import com.llewellyn.cde.approvalservice.dto.response.ApprovalRequestDto;
import com.llewellyn.cde.approvalservice.feign.form.FormServiceFeignClient;
import com.llewellyn.cde.approvalservice.feign.form.requestDto.ApprovalProcessSubmitDto;
import com.llewellyn.cde.approvalservice.feign.user.UserServiceFeignClient;
import com.llewellyn.cde.approvalservice.feign.user.responseDto.UserDto;
import com.llewellyn.cde.approvalservice.model.Action;
import com.llewellyn.cde.approvalservice.model.ActionTarget;
import com.llewellyn.cde.approvalservice.model.ApprovalRequest;
import com.llewellyn.cde.approvalservice.model.ApprovalRequestUser;
import com.llewellyn.cde.approvalservice.model.Process;
import com.llewellyn.cde.approvalservice.model.State;
import com.llewellyn.cde.approvalservice.model.Transition;
import com.llewellyn.cde.approvalservice.repository.ActionRepository;
import com.llewellyn.cde.approvalservice.repository.ApprovalRequestRepository;
import com.llewellyn.cde.approvalservice.repository.ApprovalRequestUserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ApprovalRequestServiceImp implements ApprovalRequestService {

    @Autowired
    private ApprovalRequestRepository approvalRequestRepository;

    @Autowired
    private ApprovalRequestUserRepository approvalRequestUserRepository;

    @Autowired
    private ActionRepository actionRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private FormServiceFeignClient formServiceFeignClient;

    @Autowired
    private UserServiceFeignClient userServiceFeignClient;

    @Autowired
    private RequestValuesContainer requestValuesContainer;

    @Override
    public List<ApprovalRequestDto> createNewApprovalRequest(UUID requestId, Process process) {
        // TODO Auto-generated method stub
        log.info("Create New Approval Request");

        UUID forSubmittedUserId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        // Get Starting Transition
        State startState = process.getStates().stream()
                .filter(state -> StateTypeEnum.START.equals(state.getStateType()))
                .findAny()
                .orElse(null);

        for (int i = 0; i < process.getTransitions().size(); i++) {
            // Find current state is START
            Transition currentTransition = process.getTransitions().get(i);
            if (currentTransition.getCurrentState().equals(startState)) {
                ApprovalRequest approvalRequest = new ApprovalRequest();
                approvalRequest.setRequestId(requestId);
                approvalRequest.setFormId(process.getFormId());
                approvalRequest.setTransition(currentTransition);
                approvalRequest.setFormSubmittedby(forSubmittedUserId);
                if (currentTransition.getActions().size() > 0) {
                    for (Action action : currentTransition.getActions()) {
                        approvalRequest.setAction(action);
                        approvalRequest.setActive(true);
                        approvalRequest.setCompleted(false);
                        this.addTargetUserToApprovalRequest(approvalRequest, action, forSubmittedUserId);
                        approvalRequestRepository.save(approvalRequest);
                    }
                } else {
                    approvalRequest.setAction(null);
                    approvalRequest.setActive(false);
                    approvalRequest.setCompleted(true);
                    approvalRequestRepository.save(approvalRequest);
                }
            }
        }

        State nextState = null;
        do {
            nextState = this.hasNextState(requestId);
            if (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.PROGRESS)) {
                log.info("Has Next Action");
                this.createNextApprovalRequest(nextState, requestId, process);
            }
        } while (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.PROGRESS));

        log.info("Does not has Next Action");

        return this.getAllApprovalRequestByRequestId(requestId);
    }

    @Override
    public List<ApprovalRequestDto> getAllApprovalRequestByRequestId(UUID requestId) {
        // TODO Auto-generated method stub
        log.info("Get All Approval Request by {}", requestId);

        List<ApprovalRequest> approvalRequests = approvalRequestRepository
                .findAllByRequestIdOrderByCreatedAtDesc(requestId);

        return approvalRequests.stream().map(this::approvalRequestToDto).collect(Collectors.toList());
    }

    @Override
    public List<ApprovalRequestDto> submitApprovalAction(UUID requestId, Process process, UUID actionId) {
        // TODO Auto-generated method stub
        log.info("Submit Approval Request");

        String username = requestValuesContainer.getRequestValues().get("username");

        UUID userId = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        Optional<Action> optionalTargetAction = actionRepository.findById(actionId);

        ApprovalRequest updateRequest = approvalRequestRepository.findByRequestIdAndAction(requestId,
                optionalTargetAction.get());
        // Update target user's approval request user satus
        for (ApprovalRequestUser approvalRequestUser : updateRequest.getApprovalRequestUsers()) {
            if (approvalRequestUser.getUserId().equals(userId)) {
                approvalRequestUser.setActive(false);
                approvalRequestUser.setCompleted(true);
            }
        }

        // Set Aproval Request status as completed and inactive
        updateRequest.setActive(false);
        updateRequest.setCompleted(true);

        // Set All other approval request user satus to inactive
        for (ApprovalRequestUser approvalRequestUser : updateRequest.getApprovalRequestUsers()) {
            if (approvalRequestUser.isActive()) {
                updateRequest.setActive(false);
                updateRequest.setCompleted(false);
                break;
            }
        }
        approvalRequestRepository.save(updateRequest);

        if (this.checkSameTransitionApprovalRequestCompleted(requestId, updateRequest.getTransition())) {
            this.deactiveOtherTansitionApprovalRequest(requestId);
        }

        State nextState = null;
        do {
            nextState = this.hasNextState(requestId);
            if (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.PROGRESS)) {
                log.info("Has Next Action");
                this.createNextApprovalRequest(nextState, requestId, process);
            }
        } while (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.PROGRESS));

        // Update Form Record Status
        ApprovalProcessSubmitDto approvalProcessSubmitDto = new ApprovalProcessSubmitDto();
        approvalProcessSubmitDto.setUserId(userId);
        approvalProcessSubmitDto.setUsername(username);
        approvalProcessSubmitDto.setResult(optionalTargetAction.get().getActionType().toString());
        if (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.APPROVED)) {
            log.info("Form is on approved");
            approvalProcessSubmitDto.setFormStatus(StateTypeEnum.APPROVED.toString());
        } else if (Objects.nonNull(nextState) && nextState.getStateType().equals(StateTypeEnum.REJECTED)) {
            log.info("Form is on rejected");
            approvalProcessSubmitDto.setFormStatus(StateTypeEnum.REJECTED.toString());
        } else {
            log.info("Form is on open");
            approvalProcessSubmitDto.setFormStatus("Open");
        }

        formServiceFeignClient.updateFormRecordStatusByReferenceCode(requestId, approvalProcessSubmitDto);

        log.info("Does not has Next Action");

        return this.getAllApprovalRequestByRequestId(requestId);
    }

    @Override
    public List<ActionFormRequestDto> getAllPendingApprovalActionByUser(UUID userId, UUID requestId) {
        log.info("getAllPendingApprovalActionByUser by user ID: {} and request ID: {}", userId, requestId);

        List<ApprovalRequestUser> approvalRequestUserList = approvalRequestUserRepository
                .findAllByUserIdAndRequestIdAndIsActive(userId, requestId, true);

        return approvalRequestUserList.stream().map(this::approvalFormRequestToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<UUID> getAllPendingApprovalRequestId(UUID userId, int pageNo, int pageSize) {
        log.info("getAllPendingApprovalRequestId by user ID: {}", userId);

        Sort sort = Sort.by("createdAt").descending();

        // create Pageable instance
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

        Page<ApprovalRequestUser> approvalRequestUserPage = approvalRequestUserRepository.findAllByUserIdAndIsActive(
                userId,
                true, pageable);

        List<UUID> approvalFormList = new ArrayList<>();

        for (ApprovalRequestUser approvalRequestUser : approvalRequestUserPage.getContent()) {
            if (!approvalFormList.contains(approvalRequestUser.getRequestId())) {
                // Add form id which is not exist on form list to avoid duplication
                approvalFormList.add(approvalRequestUser.getRequestId());
            }
        }

        return approvalFormList;
    }

    private ApprovalRequest addTargetUserToApprovalRequest(ApprovalRequest approvalRequest, Action action,
            UUID forSubmittedUserId) {
        
        UUID submittedUser = UUID.fromString(requestValuesContainer.getRequestValues().get("userId"));

        for (ActionTarget actionTarget : action.getActionTargets()) {

            ApprovalRequestUser approvalRequestUser = new ApprovalRequestUser();
            approvalRequestUser.setRequestId(approvalRequest.getRequestId());
            approvalRequestUser.setActive(true);
            approvalRequestUser.setCompleted(false);
            approvalRequestUser.setTargetType(actionTarget.getTargetType());

            if (actionTarget.getTargetType().equals(TargetTypeEnum.DM)) {
                UserDto userDto = userServiceFeignClient.getOneUserDetails(submittedUser);
                approvalRequestUser.setUser_group_id(null);
                approvalRequestUser.setUserId(UUID.fromString(userDto.getDirectReport()));
            } else if (actionTarget.getTargetType().equals(TargetTypeEnum.U)) {
                approvalRequestUser.setUser_group_id(null);
                approvalRequestUser.setUserId(actionTarget.getTargetUserId());
            } else if (actionTarget.getTargetType().equals(TargetTypeEnum.GM)) {
                approvalRequestUser.setUser_group_id(null);
                approvalRequestUser.setUserId(UUID.fromString("fc9370f7-8908-4b1c-ad1d-4d2cde80e8b6"));
            } else if (actionTarget.getTargetType().equals(TargetTypeEnum.REQ)) {
                approvalRequestUser.setUser_group_id(null);
                approvalRequestUser.setUserId(forSubmittedUserId);
            }

            approvalRequest.addApprovalRequestUser(approvalRequestUser);
        }

        return approvalRequest;
    }

    private State hasNextState(UUID requestId) {

        log.info("Check has next actions");

        List<ApprovalRequest> approvalRequests = approvalRequestRepository
                .findAllByRequestIdOrderByCreatedAtDesc(requestId);

        State lastNextState = null;
        for (ApprovalRequest approvalRequest : approvalRequests) {
            if (approvalRequest.isActive()) {
                // Found One Action request is still active
                return null;
            } else {
                if (approvalRequest.isCompleted()) {
                    // Get Latest Next State and inactive request
                    lastNextState = approvalRequest.getTransition().getNextState();
                    break;
                }
            }
        }

        return lastNextState;
    }

    private boolean checkSameTransitionApprovalRequestCompleted(UUID requestId, Transition selectedTransition) {

        List<ApprovalRequest> approvalRequests = approvalRequestRepository
                .findAllByRequestIdOrderByCreatedAtDesc(requestId);

        for (ApprovalRequest approvalRequest : approvalRequests) {
            if (approvalRequest.getTransition().equals(selectedTransition)
                    && approvalRequest.isActive()
                    && !approvalRequest.isCompleted()) {
                return false;
            }
        }

        return true;
    }

    private void deactiveOtherTansitionApprovalRequest(UUID requestId) {

        List<ApprovalRequest> approvalRequests = approvalRequestRepository
                .findAllByRequestIdOrderByCreatedAtDesc(requestId);

        for (ApprovalRequest approvalRequest : approvalRequests) {
            if (approvalRequest.isActive()) {
                for (ApprovalRequestUser approvalRequestUser : approvalRequest.getApprovalRequestUsers()) {
                    approvalRequestUser.setActive(false);
                }
                approvalRequest.setActive(false);
                approvalRequest.setCompleted(false);
                approvalRequestRepository.save(approvalRequest);
            }
        }
    }

    private void createNextApprovalRequest(State nextState, UUID requestId, Process process) {

        Optional<ApprovalRequest> startApprovalRequest = approvalRequestRepository
                .findTopByRequestIdOrderByCreatedAtAsc(requestId);

        log.info("Create Next Action Request");

        for (int i = 0; i < process.getTransitions().size(); i++) {
            // Find current state is START
            Transition currentTransition = process.getTransitions().get(i);
            if (currentTransition.getCurrentState().equals(nextState)) {
                ApprovalRequest approvalRequest = new ApprovalRequest();
                approvalRequest.setRequestId(requestId);
                approvalRequest.setFormId(process.getFormId());
                approvalRequest.setTransition(currentTransition);
                approvalRequest.setFormSubmittedby(startApprovalRequest.get().getFormSubmittedby());
                if (currentTransition.getActions().size() > 0) {
                    for (Action action : currentTransition.getActions()) {
                        approvalRequest.setAction(action);
                        approvalRequest.setActive(true);
                        approvalRequest.setCompleted(false);
                        this.addTargetUserToApprovalRequest(approvalRequest, action,
                                startApprovalRequest.get().getFormSubmittedby());
                        approvalRequestRepository.save(approvalRequest);
                    }
                } else {
                    approvalRequest.setAction(null);
                    approvalRequest.setActive(false);
                    approvalRequest.setCompleted(true);
                    approvalRequestRepository.save(approvalRequest);
                }
            }
        }
    }

    private ApprovalRequestDto approvalRequestToDto(ApprovalRequest approvalRequest) {
        ApprovalRequestDto approvalRequestDto = modelMapper.map(approvalRequest, ApprovalRequestDto.class);
        return approvalRequestDto;
    }

    private ActionFormRequestDto approvalFormRequestToDto(ApprovalRequestUser approvalRequestUser) {
        Action approvalAction = approvalRequestUser.getApprovalRequest().getAction();
        ActionFormRequestDto actionFormRequestDto = new ActionFormRequestDto(approvalRequestUser.getRequestId(),
                approvalRequestUser.getApprovalRequest().getFormId(), approvalAction.getActionId(),
                approvalAction.getActionType());
        return actionFormRequestDto;
    }
}
