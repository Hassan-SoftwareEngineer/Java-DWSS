package com.llewellyn.cde.approvalservice.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.llewellyn.cde.approvalservice.model.State;

public interface StateRepository extends JpaRepository<State, UUID> {
    
}
